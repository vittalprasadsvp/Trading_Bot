@echo off
REM Professional Trading Strategy - Complete Setup Script for Windows

echo ==============================================================================
echo PROFESSIONAL TRADING STRATEGY - SETUP AND EXECUTION
echo ==============================================================================
echo.

REM Step 1: Download multi-timeframe historical data
echo [STEP 1/4] Downloading multi-timeframe historical data...
echo This will fetch 15m, 1h, and 4h data for BTC/USDT (120 days)
echo.
python data_fetcher.py
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to download data
    echo Make sure you have internet connection and ccxt is installed
    pause
    exit /b 1
)
echo.
echo Data download complete
echo.

REM Step 2: Train XGBoost model
echo [STEP 2/4] Training XGBoost model with temporal cross-validation...
echo This may take 2-5 minutes...
echo.
python train_xgboost_model.py --symbol BTC/USDT --confidence 0.55
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Failed to train model
    echo Check that all dependencies are installed:
    echo   pip install xgboost scikit-learn pandas numpy talib
    pause
    exit /b 1
)
echo.
echo Model training complete
echo.

REM Step 3: Run dry-run test
echo [STEP 3/4] Starting dry-run test...
echo Bot will run in simulation mode. Press Ctrl+C to stop.
echo.
echo Recommended: Monitor for at least 48 hours before going live
echo.
python live_trading_bot_pro.py --dry-run --equity 200 --risk-usd 50 --leverage 20

echo.
echo ==============================================================================
echo DRY-RUN TEST COMPLETE
echo ==============================================================================
echo.
echo Next steps:
echo 1. Review the logs in trading_bot_pro.log
echo 2. Check trade_log_pro.json for executed trades
echo 3. If satisfied with results, set API credentials and run live:
echo.
echo    set BITGET_API_KEY=your_key
echo    set BITGET_SECRET=your_secret
echo    set BITGET_PASSWORD=your_password
echo    python live_trading_bot_pro.py --equity 200 --risk-usd 50 --leverage 20
echo.
echo ==============================================================================
pause
