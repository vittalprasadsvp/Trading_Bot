"""
Professional Risk Management System
Fixed Risk Position Sizing + 3-Stage Hybrid Exit System

Features:
- Fixed risk per trade (1-2% of equity)
- Multi-stage take profit (partial exits + trailing stop)
- Breakeven stop loss after first TP
- ATR-based trailing stop for remaining position
"""

import pandas as pd
import numpy as np
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, List, Tuple
import logging

logger = logging.getLogger(__name__)


@dataclass
class Position:
    """Position data structure"""
    symbol: str
    direction: str  # 'LONG' or 'SHORT'
    entry_price: float
    stop_loss: float
    take_profit_1: float  # First TP (1.5:1 R:R)
    take_profit_2: float  # Trailing stop target
    initial_size: float
    current_size: float
    entry_time: datetime
    order_id: str

    # Exit tracking
    stage: int = 1  # 1 = full position, 2 = partial closed, 3 = trailing
    breakeven_set: bool = False
    trailing_stop: Optional[float] = None
    highest_price: Optional[float] = None  # For trailing (LONG)
    lowest_price: Optional[float] = None   # For trailing (SHORT)


class ProfessionalRiskManager:
    """
    Professional risk management with fixed risk sizing and hybrid exits

    Position Sizing:
    - Fixed risk per trade: 1-2% of total equity
    - Position size = (Equity * Risk%) / (Entry - StopLoss)

    Exit Strategy (3 Stages):
    1. Take Profit 1 (1.5:1 R:R): Close 50%, move SL to breakeven
    2. Trailing Stop: ATR-based trailing for remaining 50%
    3. Emergency Exit: Hard stop if trailing fails
    """

    def __init__(
        self,
        initial_equity: float,
        risk_per_trade_pct: float = 0.02,  # 2% default
        leverage: float = 10.0,
        max_daily_loss_pct: float = 0.05,  # 5% max daily loss
        min_order_value: float = 10.0,
        atr_trailing_multiplier: float = 3.0
    ):
        self.initial_equity = initial_equity
        self.current_equity = initial_equity
        self.risk_per_trade_pct = risk_per_trade_pct
        self.leverage = leverage
        self.max_daily_loss_pct = max_daily_loss_pct
        self.min_order_value = min_order_value
        self.atr_trailing_multiplier = atr_trailing_multiplier

        # Position tracking
        self.positions: Dict[str, Position] = {}

        # Daily tracking
        self.daily_pnl = 0.0
        self.total_gross_pnl = 0.0
        self.daily_reset_time = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0)

        # Trade statistics
        self.total_trades = 0
        self.winning_trades = 0
        self.losing_trades = 0

        logger.info(
            f"ProfessionalRiskManager initialized:\n"
            f"  Initial Equity: ${initial_equity:,.2f}\n"
            f"  Risk per Trade: {risk_per_trade_pct*100:.1f}%\n"
            f"  Leverage: {leverage}x\n"
            f"  ATR Trailing Multiplier: {atr_trailing_multiplier}x\n"
            f"  Max Daily Loss: {max_daily_loss_pct*100:.1f}%"
        )

    def can_open_position(self, symbol: str) -> bool:
        """Check if we can open a new position"""

        # Check daily loss limit
        if self.daily_pnl <= -self.current_equity * self.max_daily_loss_pct:
            logger.warning(
                f"[RISK BLOCK] Daily loss limit reached: "
                f"${self.daily_pnl:,.2f} / ${-self.current_equity * self.max_daily_loss_pct:,.2f}"
            )
            return False

        # Check if position already exists
        if symbol in self.positions:
            logger.warning(f"[RISK BLOCK] Position already open for {symbol}")
            return False

        # Check if equity is sufficient
        if self.current_equity < self.min_order_value:
            logger.warning(f"[RISK BLOCK] Insufficient equity: ${self.current_equity:.2f}")
            return False

        return True

    def calculate_position_size(
        self,
        entry_price: float,
        stop_loss: float,
        equity: Optional[float] = None
    ) -> float:
        """
        Calculate position size using FIXED RISK method

        Formula:
        Risk Amount = Equity * Risk%
        Position Size = Risk Amount / |Entry - StopLoss|

        With leverage, actual margin required is Position Size / Leverage

        Args:
            entry_price: Entry price
            stop_loss: Stop loss price
            equity: Total equity (defaults to current_equity)

        Returns:
            Position size in base currency (BTC)
        """
        if equity is None:
            equity = self.current_equity

        # Calculate risk amount (1-2% of equity)
        risk_amount = equity * self.risk_per_trade_pct

        # Calculate price distance (risk per unit)
        price_distance = abs(entry_price - stop_loss)

        if price_distance == 0:
            logger.error("[POSITION CALC] Stop loss equals entry price!")
            return 0.0

        # Position size = Risk Amount / Price Distance
        # This ensures we only risk X% of equity on this trade
        position_size = risk_amount / price_distance

        # Validate minimum order size
        MIN_BTC = 0.0001
        order_value = position_size * entry_price

        if position_size < MIN_BTC:
            logger.warning(
                f"[POSITION CALC] Calculated size {position_size:.8f} < minimum {MIN_BTC} BTC. "
                f"Using minimum."
            )
            position_size = MIN_BTC

        if order_value < self.min_order_value:
            logger.warning(
                f"[POSITION CALC] Order value ${order_value:.2f} < minimum ${self.min_order_value:.2f}. "
                f"Adjusting."
            )
            position_size = self.min_order_value / entry_price

        # Calculate margin required
        margin_required = (position_size * entry_price) / self.leverage

        # Log calculation
        logger.info(
            f"[POSITION CALC] Fixed Risk Sizing:\n"
            f"  Equity: ${equity:.2f}\n"
            f"  Risk per Trade: {self.risk_per_trade_pct*100:.1f}% = ${risk_amount:.2f}\n"
            f"  Entry: ${entry_price:.2f} | Stop Loss: ${stop_loss:.2f}\n"
            f"  Price Distance: ${price_distance:.2f}\n"
            f"  Position Size: {position_size:.8f} BTC\n"
            f"  Order Value: ${order_value:.2f}\n"
            f"  Margin Required ({self.leverage}x): ${margin_required:.2f}\n"
            f"  Max Loss if SL hit: ${risk_amount:.2f}"
        )

        return position_size

    def calculate_take_profit_levels(
        self,
        entry_price: float,
        stop_loss: float,
        direction: str,
        atr: float
    ) -> Tuple[float, float]:
        """
        Calculate 2-stage take profit levels

        Stage 1: 1.5:1 Risk/Reward ratio (close 50%)
        Stage 2: Bollinger Band or 3:1 R:R (trailing stop target)

        Args:
            entry_price: Entry price
            stop_loss: Stop loss price
            direction: 'LONG' or 'SHORT'
            atr: Current ATR value for trailing stop calculation

        Returns:
            (tp1, tp2) tuple
        """
        risk = abs(entry_price - stop_loss)

        if direction == 'LONG':
            tp1 = entry_price + (risk * 1.5)  # 1.5:1 R:R
            tp2 = entry_price + (risk * 3.0)  # 3:1 R:R (aspirational)
        else:  # SHORT
            tp1 = entry_price - (risk * 1.5)
            tp2 = entry_price - (risk * 3.0)

        logger.info(
            f"[TP CALC] {direction} position:\n"
            f"  Entry: ${entry_price:.2f} | SL: ${stop_loss:.2f}\n"
            f"  Risk: ${risk:.2f}\n"
            f"  TP1 (1.5:1 - 50% close): ${tp1:.2f}\n"
            f"  TP2 (3:1 - trailing target): ${tp2:.2f}"
        )

        return tp1, tp2

    def open_position(
        self,
        symbol: str,
        direction: str,
        entry_price: float,
        stop_loss: float,
        take_profit_1: float,
        take_profit_2: float,
        position_size: float,
        order_id: str
    ):
        """Register a new position"""

        position = Position(
            symbol=symbol,
            direction=direction,
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit_1=take_profit_1,
            take_profit_2=take_profit_2,
            initial_size=position_size,
            current_size=position_size,
            entry_time=datetime.now(timezone.utc),
            order_id=order_id,
            stage=1,
            breakeven_set=False,
            highest_price=entry_price if direction == 'LONG' else None,
            lowest_price=entry_price if direction == 'SHORT' else None
        )

        self.positions[symbol] = position

        logger.info(
            f"[POSITION OPENED] {symbol} {direction}\n"
            f"  Entry: ${entry_price:.2f}\n"
            f"  Size: {position_size:.8f} BTC\n"
            f"  SL: ${stop_loss:.2f}\n"
            f"  TP1 (50%): ${take_profit_1:.2f}\n"
            f"  TP2 (Trailing): ${take_profit_2:.2f}"
        )

    def check_exit_conditions(
        self,
        symbol: str,
        current_price: float,
        atr: float
    ) -> Optional[Dict]:
        """
        Check if any exit conditions are met

        Returns:
            Dict with exit action if needed, None otherwise
            {
                'action': 'stop_loss' | 'take_profit_1' | 'take_profit_2' | 'trailing_stop',
                'size': float (amount to close),
                'price': float
            }
        """
        if symbol not in self.positions:
            return None

        pos = self.positions[symbol]

        # === STAGE 1: Full position active ===
        if pos.stage == 1:
            # Check stop loss
            if pos.direction == 'LONG' and current_price <= pos.stop_loss:
                logger.warning(f"[STOP LOSS] {symbol} hit @ ${current_price:.2f}")
                return {'action': 'stop_loss', 'size': pos.current_size, 'price': current_price}

            if pos.direction == 'SHORT' and current_price >= pos.stop_loss:
                logger.warning(f"[STOP LOSS] {symbol} hit @ ${current_price:.2f}")
                return {'action': 'stop_loss', 'size': pos.current_size, 'price': current_price}

            # Check TP1 (1.5:1 R:R)
            if pos.direction == 'LONG' and current_price >= pos.take_profit_1:
                logger.info(f"[TP1 HIT] {symbol} @ ${current_price:.2f} - Closing 50%")
                return {
                    'action': 'take_profit_1',
                    'size': pos.initial_size * 0.5,  # Close 50%
                    'price': current_price
                }

            if pos.direction == 'SHORT' and current_price <= pos.take_profit_1:
                logger.info(f"[TP1 HIT] {symbol} @ ${current_price:.2f} - Closing 50%")
                return {
                    'action': 'take_profit_1',
                    'size': pos.initial_size * 0.5,
                    'price': current_price
                }

        # === STAGE 2/3: Partial position, trailing stop active ===
        if pos.stage >= 2:
            # Update trailing stop
            self._update_trailing_stop(pos, current_price, atr)

            # Check trailing stop
            if pos.trailing_stop is not None:
                if pos.direction == 'LONG' and current_price <= pos.trailing_stop:
                    logger.info(f"[TRAILING STOP] {symbol} hit @ ${current_price:.2f}")
                    return {
                        'action': 'trailing_stop',
                        'size': pos.current_size,
                        'price': current_price
                    }

                if pos.direction == 'SHORT' and current_price >= pos.trailing_stop:
                    logger.info(f"[TRAILING STOP] {symbol} hit @ ${current_price:.2f}")
                    return {
                        'action': 'trailing_stop',
                        'size': pos.current_size,
                        'price': current_price
                    }

            # Check TP2 (aspirational 3:1)
            if pos.direction == 'LONG' and current_price >= pos.take_profit_2:
                logger.info(f"[TP2 HIT] {symbol} @ ${current_price:.2f} - Closing remaining")
                return {
                    'action': 'take_profit_2',
                    'size': pos.current_size,
                    'price': current_price
                }

            if pos.direction == 'SHORT' and current_price <= pos.take_profit_2:
                logger.info(f"[TP2 HIT] {symbol} @ ${current_price:.2f} - Closing remaining")
                return {
                    'action': 'take_profit_2',
                    'size': pos.current_size,
                    'price': current_price
                }

        return None

    def _update_trailing_stop(self, pos: Position, current_price: float, atr: float):
        """Update ATR-based trailing stop"""

        if pos.direction == 'LONG':
            # Track highest price
            if pos.highest_price is None or current_price > pos.highest_price:
                pos.highest_price = current_price
                pos.trailing_stop = current_price - (atr * self.atr_trailing_multiplier)
                logger.debug(
                    f"[TRAILING] {pos.symbol} new high ${pos.highest_price:.2f}, "
                    f"trailing SL: ${pos.trailing_stop:.2f}"
                )

        else:  # SHORT
            # Track lowest price
            if pos.lowest_price is None or current_price < pos.lowest_price:
                pos.lowest_price = current_price
                pos.trailing_stop = current_price + (atr * self.atr_trailing_multiplier)
                logger.debug(
                    f"[TRAILING] {pos.symbol} new low ${pos.lowest_price:.2f}, "
                    f"trailing SL: ${pos.trailing_stop:.2f}"
                )

    def execute_partial_close(self, symbol: str, size: float, exit_price: float) -> Dict:
        """
        Execute partial position close (TP1)
        Move stop loss to breakeven
        """
        if symbol not in self.positions:
            return {}

        pos = self.positions[symbol]

        # Calculate PnL for closed portion
        if pos.direction == 'LONG':
            pnl = (exit_price - pos.entry_price) * size
        else:
            pnl = (pos.entry_price - exit_price) * size

        # Update position
        pos.current_size -= size
        pos.stage = 2

        # Move stop loss to breakeven
        pos.stop_loss = pos.entry_price
        pos.breakeven_set = True

        # Update equity
        self.current_equity += pnl
        self.daily_pnl += pnl
        self.total_gross_pnl += pnl

        logger.info(
            f"[PARTIAL CLOSE] {symbol} - Closed {size:.8f} BTC @ ${exit_price:.2f}\n"
            f"  PnL: ${pnl:,.2f}\n"
            f"  Remaining: {pos.current_size:.8f} BTC\n"
            f"  Stop Loss moved to BREAKEVEN: ${pos.stop_loss:.2f}\n"
            f"  Equity: ${self.current_equity:,.2f}"
        )

        return {
            'symbol': symbol,
            'pnl': pnl,
            'size_closed': size,
            'size_remaining': pos.current_size,
            'breakeven_set': True
        }

    def close_position(self, symbol: str, exit_price: float, reason: str) -> Dict:
        """Close entire position"""

        if symbol not in self.positions:
            return {}

        pos = self.positions[symbol]

        # Calculate PnL
        if pos.direction == 'LONG':
            pnl = (exit_price - pos.entry_price) * pos.current_size
        else:
            pnl = (pos.entry_price - exit_price) * pos.current_size

        # Update equity
        self.current_equity += pnl
        self.daily_pnl += pnl
        self.total_gross_pnl += pnl

        # Update statistics
        self.total_trades += 1
        if pnl > 0:
            self.winning_trades += 1
        else:
            self.losing_trades += 1

        # Remove position
        del self.positions[symbol]

        logger.info(
            f"[POSITION CLOSED] {symbol} ({reason})\n"
            f"  Entry: ${pos.entry_price:.2f} | Exit: ${exit_price:.2f}\n"
            f"  Size: {pos.current_size:.8f} BTC\n"
            f"  PnL: ${pnl:,.2f} ({pnl/(pos.entry_price*pos.current_size)*100:+.2f}%)\n"
            f"  Equity: ${self.current_equity:,.2f}"
        )

        return {
            'symbol': symbol,
            'pnl': pnl,
            'exit_price': exit_price,
            'reason': reason,
            'return_pct': pnl / (pos.entry_price * pos.current_size) * 100
        }

    def get_statistics(self) -> Dict:
        """Get risk manager statistics"""

        win_rate = (self.winning_trades / self.total_trades * 100) if self.total_trades > 0 else 0

        return {
            'initial_equity': self.initial_equity,
            'current_equity': self.current_equity,
            'total_pnl': self.current_equity - self.initial_equity,
            'return_pct': (self.current_equity / self.initial_equity - 1) * 100,
            'daily_pnl': self.daily_pnl,
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'win_rate': win_rate,
            'open_positions': len(self.positions)
        }

    def reset_daily_stats(self):
        """Reset daily PnL"""
        now = datetime.now(timezone.utc)
        if now >= self.daily_reset_time + timedelta(days=1):
            logger.info(f"[DAILY RESET] PnL: ${self.daily_pnl:,.2f}")
            self.daily_pnl = 0.0
            self.daily_reset_time = now.replace(hour=0, minute=0, second=0)


# ============================================================================
# TESTING
# ============================================================================

if __name__ == '__main__':
    print("\n" + "="*80)
    print("PROFESSIONAL RISK MANAGER - TEST")
    print("="*80)

    # Initialize
    rm = ProfessionalRiskManager(
        initial_equity=1000.0,
        risk_per_trade_pct=0.02,  # 2% risk
        leverage=10.0
    )

    # Test position sizing
    entry = 50000.0
    stop_loss = 49250.0  # 1.5% stop

    size = rm.calculate_position_size(entry, stop_loss)

    # Test TP calculation
    tp1, tp2 = rm.calculate_take_profit_levels(entry, stop_loss, 'LONG', atr=500)

    # Open position
    rm.open_position(
        symbol='BTC/USDT',
        direction='LONG',
        entry_price=entry,
        stop_loss=stop_loss,
        take_profit_1=tp1,
        take_profit_2=tp2,
        position_size=size,
        order_id='test_001'
    )

    # Simulate TP1
    print("\n[SIMULATION] Price reaches TP1...")
    exit_signal = rm.check_exit_conditions('BTC/USDT', tp1, atr=500)
    if exit_signal:
        rm.execute_partial_close('BTC/USDT', exit_signal['size'], exit_signal['price'])

    # Simulate trailing
    print("\n[SIMULATION] Price continues higher, trailing stop active...")
    for price in [51500, 52000, 52500]:
        exit_signal = rm.check_exit_conditions('BTC/USDT', price, atr=500)
        if exit_signal:
            rm.close_position('BTC/USDT', exit_signal['price'], exit_signal['action'])
            break

    # Statistics
    print("\n" + "="*80)
    print("STATISTICS")
    print("="*80)
    stats = rm.get_statistics()
    for key, value in stats.items():
        print(f"{key:20s}: {value}")
