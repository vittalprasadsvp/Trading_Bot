# CRITICAL ADJUSTMENT: ULTRA-SHORT-TERM MODEL FOR 2026 SCALPING

## PROBLEM IDENTIFIED

Your current signal shows:
```
Stop Loss:    1.5% ($1,337 USD)
Take Profit:  2.2% ($2,000 USD)
Entry:        $88,681
TP Target:    $90,633
```

**This is SWING TRADING, NOT scalping!**

With 30x leverage:
- SL 1.5% = **-45% equity loss**
- TP 2.2% = **+66% equity gain**

**For scalping, this is ABSURD:**
- Time in trade: Hours (not minutes)
- Risk: Catastrophic
- Not suitable for high frequency

---

## ADJUSTMENT FOR 2026 HYPER-SCALPING

### Correct Parameters

| Parameter | Current State | **CORRECT for Scalping** |
|-----------|---------------|--------------------------|
| **Stop Loss** | 1.5% ($1,337) | **0.3-0.5%** ($260-440) |
| **Take Profit** | 2.2% ($2,000) | **0.6-0.9%** ($500-800) |
| **Time in Trade** | Hours | **5-15 minutes** |
| **Confidence** | 0.52 | **0.65-0.70** |
| **Label Horizon** | 60 candles (1h) | **5-10 candles (5-10 min)** |

---

## NECESSARY MODEL ADJUSTMENTS

### 1. **Label Horizon** (CRITICAL)

**BEFORE:**
```python
# XGBoostStrategy.py line 97
df['target'] = AdvancedFeatureEngineering.create_target(df, periods_ahead=4)
# 4 periods at 15m = 1 HOUR → SWING TRADING
```

**AFTER (Scalping):**
```python
# For 1m timeframe
df['target'] = AdvancedFeatureEngineering.create_target(df, periods_ahead=5)
# 5 periods at 1m = 5 MINUTES → SCALPING

# With adjusted threshold
def create_target(df, periods_ahead=5, threshold=0.003):
    future_return = df['close'].shift(-periods_ahead) / df['close'] - 1
    # Look for 0.3% or more movements in 5 minutes
    target = (future_return > threshold).astype(int)
    return target
```

---

### 2. **Confidence Threshold** (CRITICAL)

**BEFORE:**
```python
# config.py
MIN_CONFIDENCE = 0.65  # Too low for 1m (noise)
```

**AFTER:**
```python
# config.py
MIN_CONFIDENCE = 0.68  # Filter noise in 1m
# Only trade with 68%+ confidence
```

**Justification:**
- At 1m, there is A LOT of noise
- Confidence 0.52 = almost random (50%)
- Confidence 0.68 = real signal (68% vs 32%)

---

### 3. **Dynamic Stop Loss** (CRITICAL)

**BEFORE:**
```python
# config.py
BASE_STOP_LOSS_PCT = 0.003  # 0.3% (correct)
ATR_STOP_MULTIPLIER = 1.5   # But can expand too much
```

**AFTER:**
```python
# config.py
BASE_STOP_LOSS_PCT = 0.003  # 0.3% minimum
ATR_STOP_MULTIPLIER = 1.2   # REDUCED (don't expand as much)
MAX_STOP_LOSS_PCT = 0.005   # 0.5% MAXIMUM (never > 0.5%)
```

**Implementation:**
```python
def calculate_dynamic_stop_loss(...):
    atr_stop_pct = (atr * 1.2) / entry_price
    stop_pct = max(0.003, atr_stop_pct)  # MAX(0.3%, ATR*1.2)
    stop_pct = min(stop_pct, 0.005)  # NEVER > 0.5%

    return entry_price * (1 - stop_pct if LONG else 1 + stop_pct)
```

---

### 4. **Realistic Take Profit** (CRITICAL)

**BEFORE:**
```python
TP1_RATIO = 1.2   # 1.2:1 R:R (if SL=1.5%, TP=1.8%)
TP2_RATIO = 2.0   # 2:1 R:R (if SL=1.5%, TP=3%)
```

**AFTER (Scalping):**
```python
TP1_RATIO = 1.5   # 1.5:1 R:R (if SL=0.3%, TP=0.45%)
TP1_SIZE_PCT = 60 # Close 60% at TP1 (secure profit)
TP2_RATIO = 2.5   # 2.5:1 R:R (if SL=0.3%, TP=0.75%)
TP2_SIZE_PCT = 40 # Close remainder at TP2

# For 0.3% SL with 30x leverage:
# TP1 = 0.45% = +13.5% equity
# TP2 = 0.75% = +22.5% equity
```

**Concrete Example:**
```
Entry:  $88,681
SL:     $88,415 (0.3% = -$266 = -9% equity with 30x)
TP1:    $88,841 (0.18% = +$160 = +5.4% equity) → Close 60%
TP2:    $88,947 (0.30% = +$266 = +9% equity) → Close 40%
```

---

### 5. **Volatility + Commission Filter** (CRITICAL)

**Golden Rule:**
```
Predicted Movement > (Maker Commission × 2) + Spread + Slippage
Predicted Movement > 0.04% + 0.02% + 0.02% = 0.08%
```

**Implementation:**
```python
def is_move_worthwhile(predicted_move_pct, atr, spread_pct):
    """
    Verify if the predicted movement is worthwhile

    Args:
        predicted_move_pct: % movement predicted by ML
        atr: Current ATR
        spread_pct: Current bid-ask spread
    """
    # Minimum costs
    maker_fees = 0.0002 * 2  # Round trip = 0.04%
    min_slippage = 0.0002     # 0.02%
    total_cost = maker_fees + spread_pct + min_slippage

    # Minimum viable movement
    min_viable_move = total_cost * 1.5  # 1.5x the costs

    if predicted_move_pct < min_viable_move:
        logger.info(
            f"[FILTER REJECT] Predicted move {predicted_move_pct:.3%} < "
            f"Min viable {min_viable_move:.3%} (costs + buffer)"
        )
        return False

    # Additional filter: If ATR very low, skip
    atr_pct = atr / price
    if atr_pct < 0.002:  # ATR < 0.2%
        logger.info(f"[FILTER REJECT] ATR too low ({atr_pct:.3%}) - illiquid/flat")
        return False

    return True
```

---

## PRACTICAL IMPLEMENTATION

### File: `AdvancedFeatureEngineering.py`

**Modify `create_target` function:**

```python
@staticmethod
def create_target(df: pd.DataFrame, periods_ahead: int = 5) -> pd.Series:
    """
    Create SCALPING target: 5-minute lookforward with 0.3% threshold

    SCALPING MODE:
    - periods_ahead = 5 (5 minutes on 1m chart)
    - threshold = 0.003 (0.3% minimum)
    - Looks for fast but real movements
    """
    # Future max/min in next N periods
    future_high = pd.Series(index=df.index, dtype=float)
    future_low = pd.Series(index=df.index, dtype=float)

    for i in range(len(df)):
        end_idx = min(i + periods_ahead, len(df))
        if end_idx > i:
            future_high.iloc[i] = df['high'].iloc[i:end_idx].max()
            future_low.iloc[i] = df['low'].iloc[i:end_idx].min()

    current_close = df['close']

    # Potential profit in both directions
    long_profit = (future_high - current_close) / current_close
    short_profit = (current_close - future_low) / current_close

    # SCALPING THRESHOLD: 0.3% minimum
    threshold = 0.003

    # Target = 1 (LONG) if upward move > 0.3% AND > downward move
    target = ((long_profit > threshold) & (long_profit > short_profit)).astype(int)

    # Log distribution
    logger.info(
        f"\n[TARGET - SCALPING MODE] Periods: {periods_ahead}min | Threshold: {threshold:.2%}\n"
        f"  LONG (1):  {(target == 1).sum()} ({(target == 1).sum()/len(target)*100:.1f}%)\n"
        f"  SHORT (0): {(target == 0).sum()} ({(target == 0).sum()/len(target)*100:.1f}%)"
    )

    return target
```

---

### File: `config.py`

**Update parameters:**

```python
# ============================================================================
# RISK MANAGEMENT - ULTRA-SHORT-TERM SCALPING
# ============================================================================
BASE_STOP_LOSS_PCT = 0.003      # 0.3% base (NEVER more)
ATR_STOP_MULTIPLIER = 1.2       # REDUCED from 1.5 to 1.2
MAX_STOP_LOSS_PCT = 0.005       # 0.5% ABSOLUTE MAXIMUM

# Ultra-aggressive breakeven
BREAKEVEN_TRIGGER_PCT = 0.0015  # 0.15% (activate VERY fast)

# Take Profit for scalping (0.3-0.75% targets)
TP1_RATIO = 1.5        # R:R 1.5:1 (if SL=0.3%, TP=0.45%)
TP1_SIZE_PCT = 60      # Close 60% at TP1 (secure)
TP2_RATIO = 2.5        # R:R 2.5:1 (if SL=0.3%, TP=0.75%)
TP2_SIZE_PCT = 40      # Close remainder at TP2

# ============================================================================
# ML MODEL - ULTRA-STRICT FILTERS FOR SCALPING
# ============================================================================
MIN_CONFIDENCE = 0.68           # INCREASED from 0.65 to 0.68
MIN_ADX = 25.0                  # Minimum trending
MIN_VOLUME_RATIO = 0.9          # INCREASED from 0.8 to 0.9
MAX_VOLATILITY_PERCENTILE = 0.90 # REDUCED from 0.95 to 0.90

# Minimum viable movement filter
MIN_PREDICTED_MOVE_PCT = 0.004  # 0.4% minimum predicted (after costs)
MIN_ATR_PCT = 0.002             # 0.2% minimum ATR (filter flat markets)

# ============================================================================
# LABEL HORIZON (TRAINING)
# ============================================================================
LABEL_PERIODS_AHEAD = 5         # 5 minutes at 1m (not 60)
LABEL_THRESHOLD_PCT = 0.003     # 0.3% minimum movement
```

---

### File: `XGBoostStrategy.py`

**Modify training:**

```python
def train_model(self, historical_data, df_1h, df_4h, ...):
    ...
    # === CREATE TARGET - SCALPING MODE ===
    df['target'] = AdvancedFeatureEngineering.create_target(
        df,
        periods_ahead=5,  # 5 minutes (not 4 hours)
    )
    ...
```

**Modify prediction with filters:**

```python
def predict(self, current_data, df_1h, df_4h, ...):
    ...
    # Predict
    probas = self.model.predict_proba(latest_features_scaled)[0]
    predicted_class = int(probas[1] > 0.5)
    confidence = probas[predicted_class]

    # === SCALPING FILTERS ===
    latest_row = df.iloc[-1]

    # Filter 1: Minimum 68% confidence
    if confidence < 0.68:
        logger.info(f"[FILTER] Low confidence ({confidence:.2%} < 68%)")
        return 0, 0.0

    # Filter 2: ADX trending
    adx = latest_row.get('adx', 0)
    if adx < 25:
        logger.info(f"[FILTER] Low ADX ({adx:.1f} < 25)")
        return 0, 0.0

    # Filter 3: Sufficient volume
    vol_ratio = latest_row.get('volume_ratio', 0)
    if vol_ratio < 0.9:
        logger.info(f"[FILTER] Low volume ({vol_ratio:.2f} < 0.9)")
        return 0, 0.0

    # Filter 4: Sufficient ATR (not flat)
    atr_pct = latest_row.get('atr_normalized', 0)
    if atr_pct < 0.002:
        logger.info(f"[FILTER] ATR too low ({atr_pct:.3%} < 0.2%) - flat market")
        return 0, 0.0

    # Filter 5: Reasonable spread
    spread = latest_row.get('spread_estimate', 0)
    if spread > 0.0008:
        logger.info(f"[FILTER] Spread too wide ({spread:.3%} > 0.08%)")
        return 0, 0.0

    logger.info(
        f"[PREDICTION ACCEPTED] {('SHORT' if predicted_class == 0 else 'LONG')} | "
        f"Confidence: {confidence:.2%} | ADX: {adx:.1f} | Vol: {vol_ratio:.2f}"
    )

    return predicted_class, confidence
```

---

## COMPARATIVE EXAMPLE

### Signal BEFORE (Swing Trading)
```
Symbol: BTC/USDT
Entry:  $88,681
SL:     $87,344 (1.5% = $1,337)
TP1:    $90,633 (2.2% = $1,952)

With 30x leverage:
Risk:   -45% equity
Reward: +66% equity

Time: HOURS
Viable: NO for scalping
```

### Signal AFTER (Hyper-Scalping)
```
Symbol: BTC/USDT
Entry:  $88,681
SL:     $88,415 (0.3% = $266)
TP1:    $88,841 (0.18% = $160) → Close 60%
TP2:    $88,947 (0.30% = $266) → Close 40%

With 30x leverage:
Risk:   -9% equity
Reward: +5.4% (TP1) / +9% (TP2)

Time: 5-15 MINUTES
Viable: YES for scalping
```

---

## RETRAINING REQUIRED

```bash
# 1. Download 1m data (60+ days)
python data_fetcher.py --timeframe 1m --days 60

# 2. Retrain with new horizon (5 min, not 1 hour)
python train_xgboost_model.py --symbol BTC/USDT

# Expected:
# - Accuracy: 65-72% (not 81%, more realistic at 1m)
# - AUC: 0.68-0.75 (not 0.77, more conservative)
# - Balance: 30-40% LONG (0.3% threshold)
```

---

## EXPECTED RESULT

### Model Metrics
```
Accuracy:     65-72% (realistic at 1m)
AUC:          0.68-0.75
Confidence:   0.68-0.78 average
Signals/day:  8-15 (strictly filtered)
```

### Trading Performance
```
Win Rate:     65-70% (with strict filters)
Avg R:R:      1.5:1 (TP1) / 2.5:1 (TP2)
Avg SL:       0.3-0.4%
Avg TP:       0.4-0.7%
Time/trade:   5-15 minutes
Trades/day:   8-15
```

### Expected ROI (conservative)
```
Win rate:     68%
Trades/day:   10
Avg profit:   $6/trade (after fees)
Daily:        10 × $6 × 0.68 = $40.8/day
Monthly:      $40.8 × 20 = $816/month
ROI:          408% monthly (on $200 equity)
```

---

## CRITICAL WARNING

**Your current model is NOT trained for scalping.**

You need to RETRAIN with:
1. 5-minute horizon (not 1 hour)
2. 0.3% threshold (not any movement)
3. 1m data (not 15m)
4. Minimum 68% confidence (not 65%)
5. ATR/spread/volume filters

**Without retraining, the model will continue giving swing trading signals** (TP of $2000, SL of $1300).

---

## ADJUSTMENT CHECKLIST

- [ ] Modify `create_target()` → periods_ahead=5, threshold=0.003
- [ ] Update config.py → MIN_CONFIDENCE=0.68, MAX_SL=0.005
- [ ] Update TP ratios → TP1=1.5, TP2=2.5
- [ ] Add minimum ATR filter
- [ ] Add minimum viable movement filter
- [ ] Re-download 1m data (60 days)
- [ ] Retrain XGBoost model
- [ ] Validate accuracy 65-72% (realistic)
- [ ] Dry-run for 2 weeks
- [ ] Verify realistic TP/SL (0.3-0.7%)

**These adjustments are CRITICAL before live trading!**
