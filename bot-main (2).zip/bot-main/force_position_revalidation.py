"""
Force Position Revalidation After Model Retraining
Revalidates all open positions immediately after new model is loaded
"""

import asyncio
import ccxt
import pandas as pd
import os
import json
import logging
from pathlib import Path
from datetime import datetime, timezone

from XGBoostStrategy import XGBoostStrategyEngine
from ProfessionalRiskManager import ProfessionalRiskManager
from PositionValidator import PositionValidator

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class PositionRevalidationTool:
    """
    Tool to force revalidation of open positions after model retraining

    This runs as a separate process after retraining to ensure all
    positions in profit are evaluated with the new model
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        api_password: str,
        symbol: str = 'BTC/USDT'
    ):
        self.symbol = symbol
        self.futures_symbol = f"{symbol.split('/')[0]}/USDT:USDT"

        # Initialize exchange
        self.exchange = ccxt.bitget({
            'apiKey': api_key,
            'secret': api_secret,
            'password': api_password,
            'enableRateLimit': True,
            'options': {'defaultType': 'swap'}
        })

        # Load strategy engine with NEW model
        self.strategy_engine = XGBoostStrategyEngine(
            symbol=self.futures_symbol,
            confidence_threshold=0.40,  # Lower threshold for revalidation
            dry_run=False
        )

        logger.info(
            f"PositionRevalidationTool initialized\n"
            f"  Symbol: {self.futures_symbol}\n"
            f"  Model loaded: {self.strategy_engine.is_trained}"
        )

    async def fetch_current_data(self):
        """Fetch current market data for all timeframes"""
        try:
            # Fetch 15m data
            candles_15m = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                self.futures_symbol,
                '15m',
                limit=500
            )

            # Fetch 1h data
            candles_1h = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                self.futures_symbol,
                '1h',
                limit=300
            )

            # Fetch 4h data
            candles_4h = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                self.futures_symbol,
                '4h',
                limit=300
            )

            # Convert to DataFrames
            df_15m = self._candles_to_df(candles_15m)
            df_1h = self._candles_to_df(candles_1h)
            df_4h = self._candles_to_df(candles_4h)

            logger.info(
                f"Market data fetched: "
                f"15m={len(df_15m)}, 1h={len(df_1h)}, 4h={len(df_4h)}"
            )

            return df_15m, df_1h, df_4h

        except Exception as e:
            logger.error(f"Error fetching market data: {e}")
            return None, None, None

    def _candles_to_df(self, candles: list) -> pd.DataFrame:
        """Convert candle list to DataFrame"""
        if not candles:
            return pd.DataFrame()

        df = pd.DataFrame(
            candles,
            columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
        )
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        return df

    async def get_open_positions(self):
        """Fetch all open positions from exchange"""
        try:
            positions = await asyncio.to_thread(
                self.exchange.fetch_positions,
                [self.futures_symbol]
            )

            # Filter for open positions with non-zero contracts
            open_positions = [
                pos for pos in positions
                if float(pos.get('contracts', 0)) > 0
            ]

            logger.info(f"Found {len(open_positions)} open position(s)")

            return open_positions

        except Exception as e:
            logger.error(f"Error fetching positions: {e}")
            return []

    async def revalidate_position(self, position, df_15m, df_1h, df_4h):
        """
        Revalidate a single position with new model

        Args:
            position: Position object from exchange
            df_15m, df_1h, df_4h: Market data
        """
        symbol = position['symbol']
        side = position['side']  # 'long' or 'short'
        entry_price = float(position['entryPrice'])
        contracts = float(position['contracts'])
        unrealized_pnl = float(position.get('unrealizedPnl', 0))
        pnl_percentage = float(position.get('percentage', 0))

        logger.info(
            f"\n{'='*70}\n"
            f"[REVALIDATION AFTER RETRAIN] Position: {symbol}\n"
            f"  Side: {side.upper()}\n"
            f"  Entry Price: ${entry_price:.2f}\n"
            f"  Contracts: {contracts}\n"
            f"  Unrealized PnL: ${unrealized_pnl:.2f} ({pnl_percentage:+.2f}%)\n"
            f"{'='*70}"
        )

        # Only revalidate profitable positions
        if unrealized_pnl <= 0:
            logger.info(
                f"[SKIP] Position not in profit (PnL: ${unrealized_pnl:.2f})\n"
                f"No revalidation needed for losing positions"
            )
            return

        logger.info(
            f"[PROFITABLE POSITION DETECTED] PnL: ${unrealized_pnl:.2f}\n"
            f"Running ML prediction with newly trained model..."
        )

        # Get prediction from NEW model
        predicted_class, confidence = self.strategy_engine.predict(df_15m, df_1h, df_4h)
        predicted_direction = 'LONG' if predicted_class == 1 else 'SHORT'
        current_direction = 'LONG' if side == 'long' else 'SHORT'

        logger.info(
            f"[NEW MODEL PREDICTION]\n"
            f"  Original Direction: {current_direction}\n"
            f"  New Prediction: {predicted_direction}\n"
            f"  Confidence: {confidence:.2%}\n"
            f"  Threshold: 40%"
        )

        # Analyze and provide recommendation
        await self._analyze_and_recommend(
            symbol=symbol,
            current_direction=current_direction,
            predicted_direction=predicted_direction,
            confidence=confidence,
            unrealized_pnl=unrealized_pnl,
            pnl_percentage=pnl_percentage,
            entry_price=entry_price
        )

    async def _analyze_and_recommend(
        self,
        symbol: str,
        current_direction: str,
        predicted_direction: str,
        confidence: float,
        unrealized_pnl: float,
        pnl_percentage: float,
        entry_price: float
    ):
        """Analyze position and provide recommendation"""

        # Get current price
        ticker = await asyncio.to_thread(
            self.exchange.fetch_ticker,
            symbol
        )
        current_price = ticker['last']

        logger.info(
            f"\n{'='*70}\n"
            f"[REVALIDATION ANALYSIS]\n"
            f"{'='*70}"
        )

        # Case 1: Direction reversed
        if predicted_direction != current_direction:
            logger.warning(
                f"⚠️ DIRECTION REVERSAL DETECTED!\n"
                f"  Position: {current_direction}\n"
                f"  New Model Prediction: {predicted_direction}\n"
                f"  Confidence: {confidence:.2%}\n"
                f"\n"
                f"RECOMMENDATION: CLOSE OR TIGHTEN STOPS\n"
                f"  Current PnL: ${unrealized_pnl:.2f} ({pnl_percentage:+.2f}%)\n"
                f"  Consider taking profits now before reversal\n"
                f"  Or move SL to lock in gains"
            )

            # Log to file for review
            self._log_recommendation(
                symbol=symbol,
                action="CLOSE_OR_TIGHTEN",
                reason="Direction Reversal",
                details=f"Position {current_direction}, Prediction {predicted_direction}, Confidence {confidence:.2%}"
            )

        # Case 2: Low confidence on same direction
        elif confidence < 0.40:
            logger.warning(
                f"⚠️ LOW CONFIDENCE DETECTED!\n"
                f"  Direction: {current_direction} (matches position)\n"
                f"  Confidence: {confidence:.2%} < 40%\n"
                f"\n"
                f"RECOMMENDATION: TIGHTEN STOPS\n"
                f"  Current PnL: ${unrealized_pnl:.2f} ({pnl_percentage:+.2f}%)\n"
                f"  Move SL closer to current price: ${current_price:.2f}\n"
                f"  Reduce TP target to secure gains earlier"
            )

            self._log_recommendation(
                symbol=symbol,
                action="TIGHTEN_STOPS",
                reason="Low Confidence",
                details=f"Confidence {confidence:.2%}, PnL ${unrealized_pnl:.2f}"
            )

        # Case 3: High confidence, same direction
        else:
            logger.info(
                f"✅ POSITION VALIDATED!\n"
                f"  Direction: {current_direction}\n"
                f"  New Prediction: {predicted_direction} (matches)\n"
                f"  Confidence: {confidence:.2%} (good)\n"
                f"\n"
                f"RECOMMENDATION: HOLD POSITION\n"
                f"  Current PnL: ${unrealized_pnl:.2f} ({pnl_percentage:+.2f}%)\n"
                f"  Position still looks favorable with new model\n"
                f"  Keep existing SL/TP strategy"
            )

            self._log_recommendation(
                symbol=symbol,
                action="HOLD",
                reason="Position Validated",
                details=f"Confidence {confidence:.2%}, Direction matches"
            )

        logger.info(f"{'='*70}\n")

    def _log_recommendation(self, symbol: str, action: str, reason: str, details: str):
        """Log recommendation to file for audit"""
        log_file = Path('position_revalidation_log.json')

        recommendation = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'symbol': symbol,
            'action': action,
            'reason': reason,
            'details': details
        }

        # Append to log file
        logs = []
        if log_file.exists():
            with open(log_file, 'r') as f:
                try:
                    logs = json.load(f)
                except:
                    logs = []

        logs.append(recommendation)

        with open(log_file, 'w') as f:
            json.dump(logs, f, indent=2)

        logger.info(f"[LOG] Recommendation saved to {log_file}")

    async def run(self):
        """Main execution"""
        logger.info(
            f"\n{'='*70}\n"
            f"POSITION REVALIDATION AFTER MODEL RETRAINING\n"
            f"Started: {datetime.now(timezone.utc).isoformat()}\n"
            f"{'='*70}\n"
        )

        # Check if model is trained
        if not self.strategy_engine.is_trained:
            logger.error(
                "[ERROR] Model not found!\n"
                "Make sure retraining completed successfully"
            )
            return

        logger.info("[OK] New model loaded successfully")

        # Fetch current market data
        df_15m, df_1h, df_4h = await self.fetch_current_data()

        if df_15m is None or df_15m.empty:
            logger.error("[ERROR] Failed to fetch market data")
            return

        # Get open positions
        open_positions = await self.get_open_positions()

        if len(open_positions) == 0:
            logger.info(
                "\n[NO OPEN POSITIONS]\n"
                "No positions to revalidate. Exiting."
            )
            return

        # Revalidate each position
        for position in open_positions:
            await self.revalidate_position(position, df_15m, df_1h, df_4h)
            await asyncio.sleep(1)  # Rate limiting

        logger.info(
            f"\n{'='*70}\n"
            f"REVALIDATION COMPLETE\n"
            f"Finished: {datetime.now(timezone.utc).isoformat()}\n"
            f"Check position_revalidation_log.json for recommendations\n"
            f"{'='*70}\n"
        )


async def main():
    """Entry point"""
    # Get API credentials from environment
    api_key = os.getenv('BITGET_API_KEY', '')
    api_secret = os.getenv('BITGET_SECRET', '')
    api_password = os.getenv('BITGET_PASSWORD', '')

    if not api_key or not api_secret or not api_password:
        logger.error(
            "[ERROR] API credentials not found!\n"
            "Set environment variables:\n"
            "  BITGET_API_KEY\n"
            "  BITGET_SECRET\n"
            "  BITGET_PASSWORD"
        )
        return

    # Create revalidation tool
    tool = PositionRevalidationTool(
        api_key=api_key,
        api_secret=api_secret,
        api_password=api_password,
        symbol='BTC/USDT'
    )

    # Run revalidation
    await tool.run()


if __name__ == '__main__':
    asyncio.run(main())
