#!/bin/bash
# Professional Trading Strategy - Complete Setup Script with 24H Position Validation

echo "=============================================================================="
echo "PROFESSIONAL TRADING STRATEGY - SETUP AND EXECUTION"
echo "With 24-Hour Position Validation System"
echo "=============================================================================="
echo ""

# Step 1: Download multi-timeframe historical data
echo "[STEP 1/4] Downloading multi-timeframe historical data..."
echo "This will fetch 15m, 1h, and 4h data for BTC/USDT (120 days)"
echo ""
python data_fetcher.py
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to download data"
    echo "Make sure you have internet connection and ccxt is installed"
    exit 1
fi
echo ""
echo "✓ Data download complete"
echo ""

# Step 2: Train XGBoost model
echo "[STEP 2/4] Training XGBoost model with temporal cross-validation..."
echo "This may take 2-5 minutes..."
echo ""
python train_xgboost_model.py --symbol BTC/USDT --confidence 0.55
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to train model"
    echo "Check that all dependencies are installed:"
    echo "  pip install xgboost scikit-learn pandas numpy talib"
    exit 1
fi
echo ""
echo "✓ Model training complete"
echo ""

# Step 3: Setup automatic retraining and bot restart service
echo "[STEP 3/4] Setting up automatic retraining system (every 48 hours)..."
echo "This will create a systemd service and timer for automatic model updates"
echo ""

# Create retrain script
cat > retrain_and_restart.sh << 'EOF'
#!/bin/bash
# Automatic Retraining and Bot Restart Script
# Runs every 48 hours to keep the model fresh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=============================================================================="
echo "AUTOMATIC MODEL RETRAINING - $(date)"
echo "=============================================================================="

# Step 1: Download fresh data
echo "[1/4] Downloading latest market data..."
python data_fetcher.py
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to download data"
    exit 1
fi
echo "✓ Data downloaded"

# Step 2: Retrain model with new data
echo "[2/4] Retraining XGBoost model..."
python train_xgboost_model.py --symbol BTC/USDT --confidence 0.55
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to retrain model"
    exit 1
fi
echo "✓ Model retrained"

# Step 3: Stop trading bot
echo "[3/4] Stopping trading bot service..."
sudo systemctl stop trading-bot
echo "✓ Bot stopped"

# Step 4: Reload and restart bot with new model
echo "[4/4] Restarting trading bot with updated model..."
sudo systemctl daemon-reload
sudo systemctl enable trading-bot
sudo systemctl start trading-bot

if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to restart bot"
    exit 1
fi

echo "✓ Bot restarted successfully"
echo ""

# Step 5: Revalidate open positions with new model
echo "[5/5] Revalidating open positions with new model..."
echo "Checking for positions in profit that need evaluation..."
echo ""

# Wait a few seconds for bot to fully start
sleep 5

# Run position revalidation
python force_position_revalidation.py

if [ $? -eq 0 ]; then
    echo "✓ Position revalidation complete"
    echo ""
    echo "=============================================================================="
    echo "RETRAINING COMPLETE - $(date)"
    echo "=============================================================================="
    echo "Bot is now running with freshly trained model"
    echo "All profitable positions have been revalidated"
    echo "Check position_revalidation_log.json for recommendations"
    echo "=============================================================================="
else
    echo "⚠️  WARNING: Position revalidation failed (bot still running)"
    echo "Manual review recommended for open positions"
    echo ""
    echo "=============================================================================="
    echo "RETRAINING COMPLETE - $(date)"
    echo "Bot is running with new model but revalidation had issues"
    echo "=============================================================================="
fi
EOF

chmod +x retrain_and_restart.sh
echo "✓ Retrain script created: retrain_and_restart.sh"
echo ""

# Create systemd service file
cat > trading-bot.service << 'EOF'
[Unit]
Description=Professional BTC Trading Bot with ML
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$(pwd)
Environment="PATH=/usr/bin:/usr/local/bin"
ExecStart=/usr/bin/python3 live_trading_bot_pro.py --equity 200 --risk-pct 0.2 --leverage 10
Restart=on-failure
RestartSec=10
StandardOutput=append:/var/log/trading-bot.log
StandardError=append:/var/log/trading-bot-error.log

[Install]
WantedBy=multi-user.target
EOF

echo "✓ Service file created: trading-bot.service"
echo ""

# Create systemd timer for automatic retraining every 48 hours
cat > trading-bot-retrain.timer << 'EOF'
[Unit]
Description=Retrain Trading Bot Model Every 48 Hours
Requires=trading-bot-retrain.service

[Timer]
OnBootSec=48h
OnUnitActiveSec=48h
Persistent=true

[Install]
WantedBy=timers.target
EOF

echo "✓ Timer file created: trading-bot-retrain.timer"
echo ""

# Create systemd service for retraining
cat > trading-bot-retrain.service << 'EOF'
[Unit]
Description=Retrain Trading Bot Model
After=network.target

[Service]
Type=oneshot
User=$USER
WorkingDirectory=$(pwd)
ExecStart=$(pwd)/retrain_and_restart.sh
StandardOutput=append:/var/log/trading-bot-retrain.log
StandardError=append:/var/log/trading-bot-retrain-error.log

[Install]
WantedBy=multi-user.target
EOF

echo "✓ Retrain service file created: trading-bot-retrain.service"
echo ""

echo "=============================================================================="
echo "INSTALLATION INSTRUCTIONS"
echo "=============================================================================="
echo ""
echo "To enable automatic retraining every 48 hours, run these commands:"
echo ""
echo "  # Copy service files to systemd"
echo "  sudo cp trading-bot.service /etc/systemd/system/"
echo "  sudo cp trading-bot-retrain.service /etc/systemd/system/"
echo "  sudo cp trading-bot-retrain.timer /etc/systemd/system/"
echo ""
echo "  # Enable and start the bot"
echo "  sudo systemctl daemon-reload"
echo "  sudo systemctl enable trading-bot"
echo "  sudo systemctl start trading-bot"
echo ""
echo "  # Enable automatic retraining timer"
echo "  sudo systemctl enable trading-bot-retrain.timer"
echo "  sudo systemctl start trading-bot-retrain.timer"
echo ""
echo "  # Check bot status"
echo "  sudo systemctl status trading-bot"
echo "  sudo systemctl status trading-bot-retrain.timer"
echo ""
echo "  # View logs"
echo "  sudo journalctl -u trading-bot -f"
echo "  sudo tail -f /var/log/trading-bot.log"
echo ""
echo "=============================================================================="
echo "FEATURES INCLUDED:"
echo "  ✓ XGBoost ML predictions with multi-timeframe analysis"
echo "  ✓ Fixed risk position sizing (1-2% per trade)"
echo "  ✓ 3-stage hybrid exit system (partial TP + trailing stop)"
echo "  ✓ 24-hour position validation with dynamic SL/TP adjustment"
echo "  ✓ Automatic model retraining every 48 hours"
echo "  ✓ Systemd service for reliable bot operation"
echo "  ✓ Commission tracking and temporal cross-validation"
echo ""
echo "=============================================================================="
echo ""

# Step 4: Optional - Test bot in dry-run mode
echo "[STEP 4/4] OPTIONAL: Test bot in dry-run mode"
echo ""
echo "Would you like to test the bot in dry-run mode? (y/n)"
echo "This will run the bot in simulation mode for a few seconds to verify setup"
echo ""
read -p "Test now? (y/n): " -n 1 -r
echo ""

if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo ""
    echo "Starting bot in dry-run mode (will stop after 30 seconds)..."
    echo "Press Ctrl+C to stop earlier if needed"
    echo ""

    # Run bot in background with timeout
    timeout 30s python live_trading_bot_pro.py --dry-run --equity 200 --risk-pct 0.2 --leverage 10 || true

    echo ""
    echo "✓ Dry-run test complete"
    echo ""
else
    echo ""
    echo "Skipping dry-run test"
    echo ""
fi

echo "=============================================================================="
echo "SETUP COMPLETE!"
echo "=============================================================================="
echo ""
echo "📊 WHAT WAS CREATED:"
echo ""
echo "Files created:"
echo "  ✓ retrain_and_restart.sh              - Auto-retrain script"
echo "  ✓ trading-bot.service                 - Main bot systemd service"
echo "  ✓ trading-bot-retrain.service         - Retrain systemd service"
echo "  ✓ trading-bot-retrain.timer           - 48h timer"
echo "  ✓ models/BTC_USDT_xgb_model.pkl      - Trained XGBoost model"
echo "  ✓ models/BTC_USDT_xgb_scaler.pkl     - Feature scaler"
echo ""
echo "=============================================================================="
echo "🚀 NEXT STEPS - CHOOSE YOUR MODE:"
echo "=============================================================================="
echo ""
echo "OPTION 1: DRY-RUN MODE (Recommended for testing)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Run the bot in simulation mode (no real trades):"
echo ""
echo "  python live_trading_bot_pro.py --dry-run --equity 200 --risk-pct 0.2 --leverage 10"
echo ""
echo "Monitor for 24-48 hours to verify:"
echo "  - Model predictions are working"
echo "  - Position validator is active"
echo "  - No errors in logs"
echo ""
echo "=============================================================================="
echo ""
echo "OPTION 2: LIVE MODE WITH SYSTEMD (Production)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "1. Set your API credentials:"
echo ""
echo "   export BITGET_API_KEY='your_key_here'"
echo "   export BITGET_SECRET='your_secret_here'"
echo "   export BITGET_PASSWORD='your_password_here'"
echo ""
echo "2. Install systemd services:"
echo ""
echo "   sudo cp trading-bot.service /etc/systemd/system/"
echo "   sudo cp trading-bot-retrain.service /etc/systemd/system/"
echo "   sudo cp trading-bot-retrain.timer /etc/systemd/system/"
echo "   sudo systemctl daemon-reload"
echo ""
echo "3. Start the bot:"
echo ""
echo "   sudo systemctl enable trading-bot"
echo "   sudo systemctl start trading-bot"
echo ""
echo "4. Enable automatic retraining (every 48h):"
echo ""
echo "   sudo systemctl enable trading-bot-retrain.timer"
echo "   sudo systemctl start trading-bot-retrain.timer"
echo ""
echo "5. Monitor the bot:"
echo ""
echo "   sudo systemctl status trading-bot"
echo "   sudo journalctl -u trading-bot -f"
echo ""
echo "=============================================================================="
echo ""
echo "📝 IMPORTANT FILES TO MONITOR:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  • trading_bot_pro.log                 - Main bot logs"
echo "  • trade_log_pro.json                  - All trades executed"
echo "  • position_revalidation_log.json      - Position recommendations (after retrain)"
echo "  • /var/log/trading-bot-retrain.log    - Retraining logs (systemd mode)"
echo ""
echo "=============================================================================="
echo ""
echo "🔧 USEFUL COMMANDS:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Bot management:"
echo "  sudo systemctl status trading-bot          # Check bot status"
echo "  sudo systemctl restart trading-bot         # Restart bot"
echo "  sudo systemctl stop trading-bot            # Stop bot"
echo ""
echo "View logs:"
echo "  sudo journalctl -u trading-bot -f          # Live bot logs"
echo "  tail -f trading_bot_pro.log                # Local logs"
echo "  cat trade_log_pro.json | jq                # View trades (needs jq)"
echo ""
echo "Retraining:"
echo "  sudo systemctl list-timers                 # See when next retrain"
echo "  sudo systemctl start trading-bot-retrain   # Force retrain now"
echo "  tail -f /var/log/trading-bot-retrain.log   # Retrain logs"
echo ""
echo "Position validation:"
echo "  cat position_revalidation_log.json | jq    # View recommendations"
echo ""
echo "=============================================================================="
echo ""
echo "⚠️  REMINDERS:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  1. ALWAYS test in dry-run mode first before going live"
echo "  2. Start with small equity to test the system"
echo "  3. Monitor position_revalidation_log.json after each retrain"
echo "  4. The bot will stop briefly during retraining (every 48h)"
echo "  5. Check logs regularly for any issues"
echo ""
echo "=============================================================================="
echo ""
echo "📚 Documentation:"
echo "  - POSITION_VALIDATOR_README.md  - Complete validator documentation"
echo "  - INSTALL_RETRAINING.md         - Detailed installation guide"
echo ""
echo "=============================================================================="
echo ""
echo "✅ Setup complete! Choose your mode above and start trading."
echo ""
echo "=============================================================================="
