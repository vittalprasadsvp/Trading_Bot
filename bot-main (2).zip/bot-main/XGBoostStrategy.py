"""
XGBoost Strategy Engine with Temporal Cross-Validation
Professional implementation for time-series ML trading
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Optional, Tuple, List
import logging
import pickle

import xgboost as xgb
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

from AdvancedFeatureEngineering import AdvancedFeatureEngineering

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class XGBoostStrategyEngine:
    """
    Professional XGBoost trading strategy with temporal validation

    Features:
    - Walk-forward temporal cross-validation
    - Handles class imbalance with scale_pos_weight
    - Early stopping to prevent overfitting
    - Feature importance analysis
    """

    def __init__(
        self,
        symbol: str = 'BTC/USDT',
        confidence_threshold: float = 0.65,
        model_path: Optional[Path] = None,
        dry_run: bool = True
    ):
        self.symbol = symbol
        self.confidence_threshold = confidence_threshold
        self.dry_run = dry_run

        # Model components
        self.model: Optional[xgb.XGBClassifier] = None
        self.scaler = StandardScaler()
        self.feature_columns = None
        self.is_trained = False

        # Model persistence
        self.model_path = model_path or Path('models')
        self.model_path.mkdir(exist_ok=True)

        # Load existing model
        self._load_model()

        logger.info(
            f"XGBoostStrategyEngine initialized:\n"
            f"  Symbol: {symbol}\n"
            f"  Confidence Threshold: {confidence_threshold}\n"
            f"  Dry Run: {dry_run}"
        )

    def train_model(
        self,
        historical_data: pd.DataFrame,
        df_1h: Optional[pd.DataFrame] = None,
        df_4h: Optional[pd.DataFrame] = None,
        n_splits: int = 5,
        test_size: float = 0.2
    ) -> Dict:
        """
        Train XGBoost with temporal cross-validation

        Args:
            historical_data: 15-minute OHLCV data
            df_1h: Optional 1-hour data for multi-timeframe features
            df_4h: Optional 4-hour data for multi-timeframe features
            n_splits: Number of CV splits (walk-forward)
            test_size: Proportion of final test set

        Returns:
            Dict with training metrics
        """
        logger.info(f"Training XGBoost model on {len(historical_data)} samples...")

        # === FEATURE ENGINEERING ===
        logger.info("Calculating advanced features...")
        df = AdvancedFeatureEngineering.calculate_all_features(
            historical_data, df_1h, df_4h
        )

        # Create target
        df['target'] = AdvancedFeatureEngineering.create_target(df, periods_ahead=4)

        # Remove NaN
        df = df.dropna()
        logger.info(f"After feature engineering and NaN removal: {len(df)} samples")

        if len(df) < 200:
            raise ValueError(f"Insufficient data: {len(df)} samples. Need at least 200.")

        # Detect if multi-timeframe features are available
        has_mtf = df_1h is not None and df_4h is not None
        if not has_mtf:
            logger.warning("Multi-timeframe data not available, using base features only")

        # Get feature columns (with or without MTF)
        self.feature_columns = AdvancedFeatureEngineering.get_feature_columns(include_mtf=has_mtf)

        # Filter to available columns only (extra safety check)
        self.feature_columns = [col for col in self.feature_columns if col in df.columns]
        logger.info(f"Using {len(self.feature_columns)} features (MTF: {has_mtf})")

        if len(self.feature_columns) == 0:
            raise ValueError("No features available! Check data and feature engineering.")

        X = df[self.feature_columns]
        y = df['target']

        # === TRAIN/TEST SPLIT ===
        split_idx = int(len(X) * (1 - test_size))
        X_train, X_test = X[:split_idx], X[split_idx:]
        y_train, y_test = y[:split_idx], y[split_idx:]

        logger.info(f"Train set: {len(X_train)} | Test set: {len(X_test)}")

        # Check class balance
        pos_ratio = y_train.sum() / len(y_train)
        logger.info(f"Positive class ratio (train): {pos_ratio:.2%}")

        # === TEMPORAL CROSS-VALIDATION ===
        logger.info(f"Running {n_splits}-fold temporal cross-validation...")
        cv_scores = self._temporal_cross_validation(X_train, y_train, n_splits)

        # === SCALE FEATURES ===
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # === TRAIN XGBOOST ===
        logger.info("Training XGBoost classifier...")

        # Calculate scale_pos_weight for class imbalance
        neg_ratio = 1 - pos_ratio
        scale_pos_weight = neg_ratio / pos_ratio if pos_ratio > 0 else 1.0
        logger.info(f"Scale pos weight: {scale_pos_weight:.2f}")

        self.model = xgb.XGBClassifier(
            n_estimators=300,
            max_depth=6,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            gamma=0.1,
            min_child_weight=5,
            scale_pos_weight=scale_pos_weight,  # Handle class imbalance
            objective='binary:logistic',
            eval_metric='logloss',
            random_state=42,
            n_jobs=-1,
            early_stopping_rounds=20,
            verbosity=0
        )

        # Train with early stopping
        self.model.fit(
            X_train_scaled, y_train,
            eval_set=[(X_test_scaled, y_test)],
            verbose=False
        )

        # === EVALUATION ===
        train_metrics = self._evaluate_model(X_train_scaled, y_train, "Train")
        test_metrics = self._evaluate_model(X_test_scaled, y_test, "Test")

        # === FEATURE IMPORTANCE ===
        self._print_feature_importance()

        # === SAVE MODEL ===
        self.is_trained = True
        self._save_model()

        logger.info(f"[OK] Model training complete!")

        return {
            'cv_scores': cv_scores,
            'train_metrics': train_metrics,
            'test_metrics': test_metrics,
            'feature_importance': self._get_feature_importance_df()
        }

    def _temporal_cross_validation(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        n_splits: int
    ) -> Dict:
        """
        Walk-forward temporal cross-validation

        Args:
            X: Features
            y: Target
            n_splits: Number of splits

        Returns:
            Dict with CV metrics
        """
        tscv = TimeSeriesSplit(n_splits=n_splits)

        cv_scores = {
            'accuracy': [],
            'precision': [],
            'recall': [],
            'f1': [],
            'auc': []
        }

        for fold, (train_idx, val_idx) in enumerate(tscv.split(X), 1):
            X_fold_train = X.iloc[train_idx]
            X_fold_val = X.iloc[val_idx]
            y_fold_train = y.iloc[train_idx]
            y_fold_val = y.iloc[val_idx]

            # Scale
            scaler_fold = StandardScaler()
            X_fold_train_scaled = scaler_fold.fit_transform(X_fold_train)
            X_fold_val_scaled = scaler_fold.transform(X_fold_val)

            # Train
            pos_ratio = y_fold_train.sum() / len(y_fold_train)
            scale_pos_weight = (1 - pos_ratio) / pos_ratio if pos_ratio > 0 else 1.0

            model_fold = xgb.XGBClassifier(
                n_estimators=200,
                max_depth=6,
                learning_rate=0.05,
                scale_pos_weight=scale_pos_weight,
                objective='binary:logistic',
                random_state=42,
                n_jobs=-1,
                verbosity=0
            )

            model_fold.fit(X_fold_train_scaled, y_fold_train, verbose=False)

            # Evaluate
            y_pred = model_fold.predict(X_fold_val_scaled)
            y_proba = model_fold.predict_proba(X_fold_val_scaled)[:, 1]

            cv_scores['accuracy'].append(accuracy_score(y_fold_val, y_pred))
            cv_scores['precision'].append(precision_score(y_fold_val, y_pred, zero_division=0))
            cv_scores['recall'].append(recall_score(y_fold_val, y_pred, zero_division=0))
            cv_scores['f1'].append(f1_score(y_fold_val, y_pred, zero_division=0))
            cv_scores['auc'].append(roc_auc_score(y_fold_val, y_proba))

            logger.info(
                f"  Fold {fold}/{n_splits}: "
                f"Acc={cv_scores['accuracy'][-1]:.3f} | "
                f"F1={cv_scores['f1'][-1]:.3f} | "
                f"AUC={cv_scores['auc'][-1]:.3f}"
            )

        # Calculate mean and std
        cv_results = {
            metric: {
                'mean': np.mean(scores),
                'std': np.std(scores)
            }
            for metric, scores in cv_scores.items()
        }

        logger.info("\nCross-Validation Results:")
        for metric, stats in cv_results.items():
            logger.info(f"  {metric.upper()}: {stats['mean']:.3f} ± {stats['std']:.3f}")

        return cv_results

    def _evaluate_model(
        self,
        X: np.ndarray,
        y: pd.Series,
        dataset_name: str
    ) -> Dict:
        """Evaluate model performance"""

        y_pred = self.model.predict(X)
        y_proba = self.model.predict_proba(X)[:, 1]

        metrics = {
            'accuracy': accuracy_score(y, y_pred),
            'precision': precision_score(y, y_pred, zero_division=0),
            'recall': recall_score(y, y_pred, zero_division=0),
            'f1': f1_score(y, y_pred, zero_division=0),
            'auc': roc_auc_score(y, y_proba)
        }

        logger.info(
            f"\n{dataset_name} Metrics:\n"
            f"  Accuracy:  {metrics['accuracy']:.3f}\n"
            f"  Precision: {metrics['precision']:.3f}\n"
            f"  Recall:    {metrics['recall']:.3f}\n"
            f"  F1 Score:  {metrics['f1']:.3f}\n"
            f"  AUC:       {metrics['auc']:.3f}"
        )

        return metrics

    def _get_feature_importance_df(self) -> pd.DataFrame:
        """Get feature importance as DataFrame"""
        if self.model is None:
            return pd.DataFrame()

        importance_df = pd.DataFrame({
            'feature': self.feature_columns,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)

        return importance_df

    def _print_feature_importance(self, top_n: int = 15):
        """Print top feature importances"""
        importance_df = self._get_feature_importance_df()

        logger.info(f"\nTop {top_n} Most Important Features:")
        for idx, row in importance_df.head(top_n).iterrows():
            logger.info(f"  {row['feature']:30s}: {row['importance']:.4f}")

    def predict(
        self,
        current_data: pd.DataFrame,
        df_1h: Optional[pd.DataFrame] = None,
        df_4h: Optional[pd.DataFrame] = None
    ) -> Tuple[int, float]:
        """
        Predict direction and confidence

        Args:
            current_data: Recent 15-minute data
            df_1h: Optional 1-hour data
            df_4h: Optional 4-hour data

        Returns:
            (prediction, confidence) where prediction is 0/1 and confidence is probability
        """
        if not self.is_trained:
            logger.warning("Model not trained!")
            return 0, 0.0

        # Feature engineering
        df = AdvancedFeatureEngineering.calculate_all_features(current_data, df_1h, df_4h)
        df = df.dropna()

        if len(df) == 0:
            logger.warning("No valid data after feature calculation")
            return 0, 0.0

        # Get latest features
        latest_features = df[self.feature_columns].iloc[-1:].values
        latest_features_scaled = self.scaler.transform(latest_features)

        # Predict
        probas = self.model.predict_proba(latest_features_scaled)[0]
        predicted_class = np.argmax(probas)
        confidence = probas[predicted_class]

        return predicted_class, confidence

    def _save_model(self):
        """Save model, scaler, and features"""
        symbol_clean = self.symbol.replace("/", "_").replace(":", "_")

        model_file = self.model_path / f'{symbol_clean}_xgb_model.pkl'
        scaler_file = self.model_path / f'{symbol_clean}_xgb_scaler.pkl'
        features_file = self.model_path / f'{symbol_clean}_xgb_features.pkl'

        with open(model_file, 'wb') as f:
            pickle.dump(self.model, f)

        with open(scaler_file, 'wb') as f:
            pickle.dump(self.scaler, f)

        with open(features_file, 'wb') as f:
            pickle.dump(self.feature_columns, f)

        logger.info(f"[SAVED] Model saved to {model_file}")

    def _load_model(self):
        """Load model from disk"""
        symbol_variants = [
            self.symbol.replace("/", "_"),
            self.symbol.replace("/", "_").replace(":USDT", ""),
        ]

        for symbol_variant in symbol_variants:
            model_file = self.model_path / f'{symbol_variant}_xgb_model.pkl'
            scaler_file = self.model_path / f'{symbol_variant}_xgb_scaler.pkl'
            features_file = self.model_path / f'{symbol_variant}_xgb_features.pkl'

            if model_file.exists() and scaler_file.exists():
                try:
                    with open(model_file, 'rb') as f:
                        self.model = pickle.load(f)

                    with open(scaler_file, 'rb') as f:
                        self.scaler = pickle.load(f)

                    if features_file.exists():
                        with open(features_file, 'rb') as f:
                            self.feature_columns = pickle.load(f)

                    self.is_trained = True
                    logger.info(f"[LOADED] Model loaded from {model_file}")
                    return
                except Exception as e:
                    logger.warning(f"Failed to load model: {e}")
                    continue

        self.is_trained = False


# ============================================================================
# TESTING
# ============================================================================

if __name__ == '__main__':
    from datetime import datetime, timezone

    # Generate synthetic data
    dates_15m = pd.date_range(end=datetime.now(timezone.utc), periods=2000, freq='15min')
    dates_1h = pd.date_range(end=datetime.now(timezone.utc), periods=500, freq='1h')
    dates_4h = pd.date_range(end=datetime.now(timezone.utc), periods=125, freq='4h')

    np.random.seed(42)
    returns_15m = np.random.normal(0.0001, 0.01, 2000)
    returns_1h = np.random.normal(0.0001, 0.015, 500)
    returns_4h = np.random.normal(0.0001, 0.02, 125)

    close_15m = 50000 * (1 + returns_15m).cumprod()
    close_1h = 50000 * (1 + returns_1h).cumprod()
    close_4h = 50000 * (1 + returns_4h).cumprod()

    df_15m = pd.DataFrame({
        'timestamp': dates_15m,
        'open': close_15m * (1 + np.random.uniform(-0.002, 0.002, 2000)),
        'high': close_15m * (1 + np.random.uniform(0, 0.005, 2000)),
        'low': close_15m * (1 + np.random.uniform(-0.005, 0, 2000)),
        'close': close_15m,
        'volume': np.random.uniform(100, 1000, 2000)
    })

    df_1h = pd.DataFrame({
        'timestamp': dates_1h,
        'open': close_1h * (1 + np.random.uniform(-0.002, 0.002, 500)),
        'high': close_1h * (1 + np.random.uniform(0, 0.005, 500)),
        'low': close_1h * (1 + np.random.uniform(-0.005, 0, 500)),
        'close': close_1h,
        'volume': np.random.uniform(100, 1000, 500)
    })

    df_4h = pd.DataFrame({
        'timestamp': dates_4h,
        'open': close_4h * (1 + np.random.uniform(-0.002, 0.002, 125)),
        'high': close_4h * (1 + np.random.uniform(0, 0.005, 125)),
        'low': close_4h * (1 + np.random.uniform(-0.005, 0, 125)),
        'close': close_4h,
        'volume': np.random.uniform(100, 1000, 125)
    })

    # Initialize engine
    engine = XGBoostStrategyEngine(
        symbol='BTC/USDT',
        confidence_threshold=0.65,
        dry_run=True
    )

    # Train model
    print("\n" + "="*80)
    print("TRAINING XGBOOST MODEL WITH TEMPORAL CV")
    print("="*80)

    results = engine.train_model(df_15m, df_1h, df_4h, n_splits=5, test_size=0.2)

    print("\n" + "="*80)
    print("TRAINING COMPLETE")
    print("="*80)

    # Test prediction
    print("\n[TEST] Making prediction on latest data...")
    test_data = df_15m.tail(100)
    predicted_class, confidence = engine.predict(test_data, df_1h, df_4h)

    direction = "LONG" if predicted_class == 1 else "SHORT"
    print(f"Prediction: {direction} | Confidence: {confidence:.2%}")
