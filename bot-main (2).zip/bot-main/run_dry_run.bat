@echo off
REM Dry-Run Testing Script for Professional Trading Bot
REM This runs the bot in simulation mode (no real trades)

echo.
echo ================================================================================
echo PROFESSIONAL TRADING BOT - DRY-RUN MODE
echo ================================================================================
echo.
echo This will start the trading bot in SIMULATION mode:
echo   - Uses REAL market data
echo   - Makes SIMULATED trades (no real money)
echo   - Tests all strategy logic
echo   - Tracks performance metrics
echo.
echo Press Ctrl+C at any time to stop the bot
echo.
echo ================================================================================
echo.

REM Activate virtual environment if it exists
if exist .venv\Scripts\activate.bat (
    echo Activating virtual environment...
    call .venv\Scripts\activate.bat
)

REM Run the bot in dry-run mode
echo Starting bot with $1000 virtual equity...
echo.
python live_trading_bot_pro.py --dry-run --equity 1000 --risk-pct 0.2 --leverage 10 --confidence 0.55

echo.
echo ================================================================================
echo Bot stopped. Check trading_bot_pro.log for details.
echo ================================================================================
echo.
pause
