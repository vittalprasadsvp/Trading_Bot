"""
Position Validator - 24-Hour Position Revalidation System
Revalidates open positions every 24 hours and adjusts SL/TP based on confidence score
"""

import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class PositionValidator:
    """
    Validates open positions every 24 hours and adjusts risk parameters

    Features:
    - Re-predicts confidence score for open positions
    - If confidence < 40%, tightens stop loss and take profit
    - Keeps track of last validation time per position
    - Logs all validation decisions
    """

    def __init__(
        self,
        strategy_engine,
        risk_manager,
        order_executor,
        low_confidence_threshold: float = 0.40,
        validation_interval_hours: int = 24
    ):
        """
        Initialize Position Validator

        Args:
            strategy_engine: XGBoostStrategyEngine instance
            risk_manager: ProfessionalRiskManager instance
            order_executor: OrderExecutor instance
            low_confidence_threshold: Threshold below which to tighten SL/TP (default: 0.40 = 40%)
            validation_interval_hours: Hours between validations (default: 24)
        """
        self.strategy_engine = strategy_engine
        self.risk_manager = risk_manager
        self.order_executor = order_executor
        self.low_confidence_threshold = low_confidence_threshold
        self.validation_interval = timedelta(hours=validation_interval_hours)

        # Track last validation time per symbol
        self.last_validation: Dict[str, datetime] = {}

        logger.info(
            f"PositionValidator initialized:\n"
            f"  Low Confidence Threshold: {low_confidence_threshold:.0%}\n"
            f"  Validation Interval: {validation_interval_hours} hours"
        )

    async def validate_all_positions(
        self,
        current_price: float,
        current_atr: float,
        df_15m: pd.DataFrame,
        df_1h: Optional[pd.DataFrame] = None,
        df_4h: Optional[pd.DataFrame] = None
    ):
        """
        Validate all open positions and adjust if needed

        Args:
            current_price: Current market price
            current_atr: Current ATR value
            df_15m: 15-minute timeframe data
            df_1h: Optional 1-hour timeframe data
            df_4h: Optional 4-hour timeframe data
        """
        now = datetime.now(timezone.utc)

        for symbol, position in list(self.risk_manager.positions.items()):
            # Check if validation is needed
            last_check = self.last_validation.get(symbol)

            # Validate if:
            # 1. Never validated before, OR
            # 2. 24 hours have passed since last validation
            should_validate = (
                last_check is None or
                (now - last_check) >= self.validation_interval
            )

            if should_validate:
                logger.info(
                    f"\n{'='*70}\n"
                    f"[VALIDATION] Checking position: {symbol}\n"
                    f"  Direction: {position.direction}\n"
                    f"  Entry: ${position.entry_price:.2f}\n"
                    f"  Current Price: ${current_price:.2f}\n"
                    f"  Stage: {position.stage}\n"
                    f"  Open Duration: {(now - position.entry_time).total_seconds() / 3600:.1f} hours\n"
                    f"{'='*70}"
                )

                # Re-predict confidence score
                await self._revalidate_position(
                    symbol=symbol,
                    position=position,
                    current_price=current_price,
                    current_atr=current_atr,
                    df_15m=df_15m,
                    df_1h=df_1h,
                    df_4h=df_4h
                )

                # Update last validation time
                self.last_validation[symbol] = now

    async def _revalidate_position(
        self,
        symbol: str,
        position,
        current_price: float,
        current_atr: float,
        df_15m: pd.DataFrame,
        df_1h: Optional[pd.DataFrame],
        df_4h: Optional[pd.DataFrame]
    ):
        """
        Revalidate a single position and adjust SL/TP if confidence is low

        Args:
            symbol: Position symbol
            position: Position object
            current_price: Current market price
            current_atr: Current ATR
            df_15m, df_1h, df_4h: Multi-timeframe data
        """
        # Get fresh prediction
        predicted_class, confidence = self.strategy_engine.predict(df_15m, df_1h, df_4h)
        predicted_direction = 'LONG' if predicted_class == 1 else 'SHORT'

        logger.info(
            f"[REVALIDATION] ML Prediction:\n"
            f"  Original Direction: {position.direction}\n"
            f"  Current Prediction: {predicted_direction}\n"
            f"  Confidence Score: {confidence:.2%}\n"
            f"  Threshold: {self.low_confidence_threshold:.0%}"
        )

        # Check if confidence is below threshold
        if confidence < self.low_confidence_threshold:
            logger.warning(
                f"[LOW CONFIDENCE DETECTED] {confidence:.2%} < {self.low_confidence_threshold:.0%}\n"
                f"Adjusting stop loss and take profit for tighter risk management..."
            )

            await self._adjust_position_risk(
                symbol=symbol,
                position=position,
                current_price=current_price,
                current_atr=current_atr,
                confidence=confidence
            )

        # Check if prediction direction reversed
        elif predicted_direction != position.direction:
            logger.warning(
                f"[DIRECTION REVERSAL] Prediction changed from {position.direction} to {predicted_direction}\n"
                f"Consider closing position or tightening stops"
            )

            # Tighten stop loss on direction reversal
            await self._tighten_stop_loss(
                symbol=symbol,
                position=position,
                current_price=current_price,
                current_atr=current_atr,
                reason="Direction Reversal"
            )

        else:
            logger.info(
                f"[VALIDATION PASSED] Position {symbol} still looks good\n"
                f"  Confidence: {confidence:.2%} (Above threshold)\n"
                f"  Direction: {predicted_direction} (Matches position)"
            )

    async def _adjust_position_risk(
        self,
        symbol: str,
        position,
        current_price: float,
        current_atr: float,
        confidence: float
    ):
        """
        Adjust stop loss and take profit for low confidence positions

        Strategy:
        - Tighten stop loss closer to current price (reduce risk)
        - Lower take profit targets (secure profits earlier)
        - Use ATR to calculate tighter levels

        Args:
            symbol: Position symbol
            position: Position object
            current_price: Current market price
            current_atr: Current ATR
            confidence: Current confidence score
        """
        # Calculate tighter stop loss based on confidence level
        # Lower confidence = tighter stop loss
        # Confidence 0.40 -> 1.0 ATR away
        # Confidence 0.20 -> 0.5 ATR away
        confidence_factor = max(0.5, confidence)  # Min 0.5 ATR

        if position.direction == 'LONG':
            # Tighter stop loss (closer to current price)
            new_stop_loss = current_price - (current_atr * confidence_factor)

            # Don't move SL below breakeven if already profitable
            if position.breakeven_set:
                new_stop_loss = max(new_stop_loss, position.entry_price)

            # Don't move SL down (only tighten)
            new_stop_loss = max(new_stop_loss, position.stop_loss)

            # Tighter take profit
            current_profit_potential = position.take_profit_2 - current_price
            new_take_profit = current_price + (current_profit_potential * confidence_factor)

        else:  # SHORT
            # Tighter stop loss
            new_stop_loss = current_price + (current_atr * confidence_factor)

            # Don't move SL above breakeven if already profitable
            if position.breakeven_set:
                new_stop_loss = min(new_stop_loss, position.entry_price)

            # Don't move SL up (only tighten)
            new_stop_loss = min(new_stop_loss, position.stop_loss)

            # Tighter take profit
            current_profit_potential = current_price - position.take_profit_2
            new_take_profit = current_price - (current_profit_potential * confidence_factor)

        # Check if changes are significant
        sl_changed = abs(new_stop_loss - position.stop_loss) > 1.0  # $1 threshold
        tp_changed = abs(new_take_profit - position.take_profit_2) > 1.0

        if sl_changed or tp_changed:
            logger.info(
                f"[ADJUSTING RISK] {symbol}\n"
                f"  Confidence: {confidence:.2%} (Low)\n"
                f"  Old SL: ${position.stop_loss:.2f} -> New SL: ${new_stop_loss:.2f}\n"
                f"  Old TP: ${position.take_profit_2:.2f} -> New TP: ${new_take_profit:.2f}\n"
                f"  ATR: ${current_atr:.2f} | Factor: {confidence_factor:.2f}x"
            )

            # Update position in risk manager
            old_sl = position.stop_loss
            old_tp = position.take_profit_2

            position.stop_loss = new_stop_loss
            position.take_profit_2 = new_take_profit

            # Cancel existing TP/SL orders on exchange
            await self.order_executor.cancel_tp_sl_orders(symbol, position.direction)

            # Place new TP/SL orders with updated levels
            await self.order_executor.place_tp_sl_orders(
                symbol=symbol,
                direction=position.direction,
                amount=position.current_size,
                stop_loss=new_stop_loss,
                take_profit=new_take_profit,
                reduce_only=True
            )

            logger.info(
                f"[RISK ADJUSTED] TP/SL orders updated on exchange\n"
                f"  Stop Loss: ${old_sl:.2f} -> ${new_stop_loss:.2f}\n"
                f"  Take Profit: ${old_tp:.2f} -> ${new_take_profit:.2f}"
            )
        else:
            logger.info(
                f"[NO ADJUSTMENT NEEDED] Changes too small to update\n"
                f"  SL change: ${abs(new_stop_loss - position.stop_loss):.2f}\n"
                f"  TP change: ${abs(new_take_profit - position.take_profit_2):.2f}"
            )

    async def _tighten_stop_loss(
        self,
        symbol: str,
        position,
        current_price: float,
        current_atr: float,
        reason: str
    ):
        """
        Tighten stop loss when prediction direction reverses

        Args:
            symbol: Position symbol
            position: Position object
            current_price: Current market price
            current_atr: Current ATR
            reason: Reason for tightening
        """
        if position.direction == 'LONG':
            # Move SL to 1.5 ATR below current price
            new_stop_loss = current_price - (current_atr * 1.5)

            # Don't move SL below breakeven
            if position.breakeven_set:
                new_stop_loss = max(new_stop_loss, position.entry_price)

            # Only tighten (move up)
            new_stop_loss = max(new_stop_loss, position.stop_loss)

        else:  # SHORT
            new_stop_loss = current_price + (current_atr * 1.5)

            # Don't move SL above breakeven
            if position.breakeven_set:
                new_stop_loss = min(new_stop_loss, position.entry_price)

            # Only tighten (move down)
            new_stop_loss = min(new_stop_loss, position.stop_loss)

        # Update if significant change
        if abs(new_stop_loss - position.stop_loss) > 1.0:
            logger.warning(
                f"[TIGHTENING SL] {symbol} due to {reason}\n"
                f"  Old SL: ${position.stop_loss:.2f}\n"
                f"  New SL: ${new_stop_loss:.2f}"
            )

            old_sl = position.stop_loss
            position.stop_loss = new_stop_loss

            # Update exchange orders
            await self.order_executor.cancel_tp_sl_orders(symbol, position.direction)
            await self.order_executor.place_tp_sl_orders(
                symbol=symbol,
                direction=position.direction,
                amount=position.current_size,
                stop_loss=new_stop_loss,
                take_profit=position.take_profit_2,
                reduce_only=True
            )

            logger.info(f"[SL TIGHTENED] ${old_sl:.2f} -> ${new_stop_loss:.2f}")

    def get_validation_status(self) -> Dict:
        """Get validation status for all positions"""
        now = datetime.now(timezone.utc)

        status = {}
        for symbol in self.risk_manager.positions.keys():
            last_check = self.last_validation.get(symbol)

            if last_check is None:
                time_until_next = "Never validated"
                hours_since_last = None
            else:
                hours_since_last = (now - last_check).total_seconds() / 3600
                time_until_next = self.validation_interval - (now - last_check)
                time_until_next = max(timedelta(0), time_until_next)

            status[symbol] = {
                'last_validation': last_check.isoformat() if last_check else None,
                'hours_since_last': hours_since_last,
                'next_validation_in': str(time_until_next) if isinstance(time_until_next, timedelta) else time_until_next
            }

        return status


# ============================================================================
# TESTING
# ============================================================================

if __name__ == '__main__':
    print("\n" + "="*80)
    print("POSITION VALIDATOR - TEST")
    print("="*80)

    print("\nThis module requires integration with live trading bot.")
    print("See live_trading_bot_pro.py for usage example.")
    print("\nKey Features:")
    print("  - Revalidates positions every 24 hours")
    print("  - Adjusts SL/TP if confidence < 40%")
    print("  - Tightens stops on direction reversal")
    print("  - Logs all validation decisions")
