#!/bin/bash
# Installation Script for Automatic Retraining System
# This integrates with your existing trading-bot.service

echo "=============================================================================="
echo "INSTALLING AUTOMATIC RETRAINING SYSTEM"
echo "=============================================================================="
echo ""

# Check if running as ubuntu user
if [ "$USER" != "ubuntu" ]; then
    echo "⚠️  Warning: Expected to run as 'ubuntu' user, current user: $USER"
    read -p "Continue anyway? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

INSTALL_DIR="/home/ubuntu/trading-bot"

# Check if we're in the right directory
if [ ! -f "live_trading_bot_pro.py" ]; then
    echo "❌ ERROR: live_trading_bot_pro.py not found"
    echo "Please run this script from your trading bot directory"
    exit 1
fi

echo "[1/5] Making retrain script executable..."
chmod +x retrain_and_restart.sh
echo "✓ Done"
echo ""

echo "[2/5] Copying systemd service files..."
sudo cp trading-bot-retrain.service /etc/systemd/system/
sudo cp trading-bot-retrain.timer /etc/systemd/system/
echo "✓ Service files copied"
echo ""

echo "[3/5] Reloading systemd daemon..."
sudo systemctl daemon-reload
echo "✓ Daemon reloaded"
echo ""

echo "[4/5] Enabling automatic retraining timer..."
sudo systemctl enable trading-bot-retrain.timer
echo "✓ Timer enabled"
echo ""

echo "[5/5] Starting retraining timer..."
sudo systemctl start trading-bot-retrain.timer
echo "✓ Timer started"
echo ""

echo "=============================================================================="
echo "INSTALLATION COMPLETE"
echo "=============================================================================="
echo ""
echo "Automatic retraining system is now active!"
echo ""
echo "Configuration:"
echo "  - Retraining interval: Every 48 hours"
echo "  - First retrain: 48 hours from now"
echo "  - Logs: /var/log/trading-bot-retrain.log"
echo ""
echo "Useful commands:"
echo ""
echo "  # Check timer status"
echo "  sudo systemctl status trading-bot-retrain.timer"
echo ""
echo "  # See when next retrain will happen"
echo "  sudo systemctl list-timers trading-bot-retrain.timer"
echo ""
echo "  # View retrain logs"
echo "  sudo tail -f /var/log/trading-bot-retrain.log"
echo ""
echo "  # View position revalidation recommendations"
echo "  cat position_revalidation_log.json | jq"
echo ""
echo "  # Manually trigger a retrain now (testing)"
echo "  sudo systemctl start trading-bot-retrain.service"
echo ""
echo "  # Stop automatic retraining"
echo "  sudo systemctl stop trading-bot-retrain.timer"
echo "  sudo systemctl disable trading-bot-retrain.timer"
echo ""
echo "=============================================================================="
echo ""
echo "IMPORTANT: Your existing trading-bot.service will continue running normally."
echo "The bot will only stop briefly during retraining (every 48 hours)."
echo ""
echo "After each retrain, check position_revalidation_log.json for any"
echo "recommendations about your open positions in profit."
echo ""
echo "=============================================================================="
