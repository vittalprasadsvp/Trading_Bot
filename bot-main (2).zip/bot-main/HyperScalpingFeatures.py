"""
Hyper-Scalping Feature Engineering
Optimized for 1m/5m micro-movements with low-latency calculation
"""

import pandas as pd
import numpy as np
import talib as ta
from typing import Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class HyperScalpingFeatures:
    """
    Ultra-fast feature engineering for hyper-scalping

    New Features vs Standard:
    - Micro-momentum (RSI differential 1m vs 5m)
    - Tick volatility (ATR percentile + spread analysis)
    - VWAP deviation (mean reversion signals)
    - Order Book Imbalance (OBI)
    - Dynamic ATR-based stop loss
    """

    @staticmethod
    def calculate_micro_momentum(df_1m: pd.DataFrame, df_5m: pd.DataFrame) -> pd.DataFrame:
        """
        Micro-Momentum: Detecta divergencias entre timeframes cortos

        Features:
        - rsi_diff_1m_5m: Diferencia RSI 1m vs 5m (divergencias)
        - stoch_cross_1m: Cruce estocástico en 1m
        - momentum_acceleration: Segunda derivada del precio
        """
        df = df_1m.copy()

        # RSI Differential (clave para micro-reversiones)
        rsi_1m_fast = ta.RSI(df['close'].values, timeperiod=7)
        rsi_1m_slow = ta.RSI(df['close'].values, timeperiod=14)
        df['rsi_1m_fast'] = rsi_1m_fast
        df['rsi_1m_slow'] = rsi_1m_slow
        df['rsi_diff_fast_slow'] = rsi_1m_fast - rsi_1m_slow

        # RSI from 5m (para comparación multi-timeframe)
        if len(df_5m) > 0:
            rsi_5m = ta.RSI(df_5m['close'].values, timeperiod=14)
            # Align 5m RSI to 1m (forward fill)
            df_5m_temp = df_5m.copy()
            df_5m_temp['rsi_5m'] = rsi_5m
            df_5m_temp = df_5m_temp[['timestamp', 'rsi_5m']].set_index('timestamp')
            df = df.set_index('timestamp')
            df['rsi_5m'] = df_5m_temp['rsi_5m'].reindex(df.index, method='ffill')
            df = df.reset_index()

            # Divergencia 1m vs 5m (señal de reversión)
            df['rsi_divergence_1m_5m'] = df['rsi_1m_slow'] - df['rsi_5m']
        else:
            df['rsi_5m'] = 50.0
            df['rsi_divergence_1m_5m'] = 0.0

        # Stochastic (ultra-sensible para scalping)
        stoch_k, stoch_d = ta.STOCH(
            df['high'].values,
            df['low'].values,
            df['close'].values,
            fastk_period=14,
            slowk_period=3,
            slowd_period=3
        )
        df['stoch_k'] = stoch_k
        df['stoch_d'] = stoch_d
        df['stoch_cross'] = np.where(stoch_k > stoch_d, 1, -1)
        df['stoch_overbought'] = (stoch_k > 80).astype(int)
        df['stoch_oversold'] = (stoch_k < 20).astype(int)

        # Momentum Acceleration (segunda derivada = aceleración del precio)
        df['momentum_1'] = df['close'].pct_change(1)
        df['momentum_2'] = df['close'].pct_change(2)
        df['momentum_5'] = df['close'].pct_change(5)
        df['momentum_velocity'] = df['momentum_1'].diff()  # Velocidad
        df['momentum_acceleration'] = df['momentum_velocity'].diff()  # Aceleración

        return df

    @staticmethod
    def calculate_tick_volatility(df: pd.DataFrame) -> pd.DataFrame:
        """
        Tick Volatility: Mide volatilidad instantánea y liquidez

        Features:
        - atr_percentile: ATR normalizado (percentil 0-1)
        - spread_estimate: Spread estimado (high-low ratio)
        - tick_range: Rango intra-vela normalizado
        - volume_surge: Picos de volumen anormales
        """

        # ATR (Average True Range) - medida de volatilidad
        atr = ta.ATR(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['atr'] = atr
        df['atr_normalized'] = atr / df['close']  # ATR como % del precio

        # ATR Percentile (0-1, indica si volatilidad es alta o baja)
        df['atr_percentile'] = df['atr'].rolling(window=100).apply(
            lambda x: pd.Series(x).rank(pct=True).iloc[-1] if len(x) > 0 else 0.5
        )

        # Spread Estimate (proxy de liquidez)
        # Spread real no está disponible sin order book, pero high-low es proxy
        df['tick_range'] = (df['high'] - df['low']) / df['close']
        df['spread_estimate'] = df['tick_range']  # Simplificación

        # Volume Surge Detection (anomalías de volumen)
        df['volume_sma_20'] = df['volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['volume'] / (df['volume_sma_20'] + 1e-10)
        df['volume_surge'] = (df['volume_ratio'] > 2.0).astype(int)  # Spike si > 2x
        df['volume_dry'] = (df['volume_ratio'] < 0.5).astype(int)    # Bajo si < 0.5x

        # Volatility Regime Classification
        df['volatility_high'] = (df['atr_percentile'] > 0.8).astype(int)
        df['volatility_low'] = (df['atr_percentile'] < 0.2).astype(int)
        df['volatility_normal'] = ((df['atr_percentile'] >= 0.2) & (df['atr_percentile'] <= 0.8)).astype(int)

        return df

    @staticmethod
    def calculate_vwap_deviation(df: pd.DataFrame, lookback: int = 50) -> pd.DataFrame:
        """
        VWAP Deviation: Mean reversion signals

        VWAP = Volume Weighted Average Price
        Desviación del VWAP indica sobre-extensión (probable reversión)
        """

        # VWAP Calculation
        df['vwap'] = (df['close'] * df['volume']).rolling(window=lookback).sum() / \
                     df['volume'].rolling(window=lookback).sum()

        # Deviation from VWAP
        df['vwap_deviation'] = (df['close'] - df['vwap']) / df['vwap']
        df['vwap_deviation_pct'] = df['vwap_deviation'] * 100

        # VWAP Bands (similar a Bollinger pero con VWAP)
        df['vwap_std'] = df['close'].rolling(window=lookback).std()
        df['vwap_upper'] = df['vwap'] + (df['vwap_std'] * 2.0)
        df['vwap_lower'] = df['vwap'] - (df['vwap_std'] * 2.0)

        # Position relative to VWAP bands
        df['vwap_position'] = (df['close'] - df['vwap_lower']) / \
                              (df['vwap_upper'] - df['vwap_lower'] + 1e-10)

        # Mean reversion signals
        df['vwap_overextended_up'] = (df['vwap_position'] > 0.95).astype(int)  # > upper band
        df['vwap_overextended_down'] = (df['vwap_position'] < 0.05).astype(int)  # < lower band

        # VWAP Trend
        df['vwap_slope'] = df['vwap'].diff(5) / df['vwap']
        df['price_above_vwap'] = (df['close'] > df['vwap']).astype(int)

        return df

    @staticmethod
    def calculate_order_book_imbalance(
        order_book: Optional[Dict] = None,
        default_obi: float = 0.0
    ) -> float:
        """
        Order Book Imbalance (OBI)

        OBI = (Bid Volume - Ask Volume) / (Bid Volume + Ask Volume)

        OBI > 0 → Más demanda (bullish)
        OBI < 0 → Más oferta (bearish)
        OBI ≈ 0 → Equilibrado

        Range: -1 to +1
        """
        if order_book is None or 'bids' not in order_book or 'asks' not in order_book:
            return default_obi

        try:
            # Sum volume in top 10 levels
            bid_volume = sum([bid[1] for bid in order_book['bids'][:10]])
            ask_volume = sum([ask[1] for ask in order_book['asks'][:10]])

            total_volume = bid_volume + ask_volume
            if total_volume == 0:
                return default_obi

            obi = (bid_volume - ask_volume) / total_volume
            return obi

        except Exception as e:
            logger.warning(f"Error calculating OBI: {e}")
            return default_obi

    @staticmethod
    def calculate_dynamic_stop_loss(
        entry_price: float,
        atr: float,
        direction: str,
        base_stop_pct: float = 0.003,
        atr_multiplier: float = 1.5
    ) -> float:
        """
        Dynamic Stop Loss = MAX(Base Stop %, ATR * Multiplier)

        Args:
            entry_price: Precio de entrada
            atr: Current ATR value
            direction: 'LONG' or 'SHORT'
            base_stop_pct: Stop loss mínimo (0.3% default)
            atr_multiplier: Multiplicador del ATR (1.5x default)

        Returns:
            Stop loss price
        """
        # ATR-based stop distance
        atr_stop_distance = atr * atr_multiplier
        atr_stop_pct = atr_stop_distance / entry_price

        # Use the LARGER of base_stop or ATR-based stop
        stop_distance_pct = max(base_stop_pct, atr_stop_pct)

        if direction == 'LONG':
            stop_loss = entry_price * (1 - stop_distance_pct)
        else:  # SHORT
            stop_loss = entry_price * (1 + stop_distance_pct)

        logger.info(
            f"Dynamic SL: Base={base_stop_pct:.2%}, ATR={atr_stop_pct:.2%}, "
            f"Used={stop_distance_pct:.2%} → SL=${stop_loss:.2f}"
        )

        return stop_loss

    @staticmethod
    def calculate_all_hyper_features(
        df_1m: pd.DataFrame,
        df_5m: Optional[pd.DataFrame] = None,
        df_15m: Optional[pd.DataFrame] = None,
        order_book: Optional[Dict] = None,
        funding_rate: Optional[float] = None
    ) -> pd.DataFrame:
        """
        Calculate ALL hyper-scalping features

        Returns:
            DataFrame with all features added
        """
        # Start with 1m data
        df = df_1m.copy()

        # Ensure we have 5m data (even if empty)
        if df_5m is None or len(df_5m) == 0:
            df_5m = pd.DataFrame(columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])

        # === MICRO-MOMENTUM ===
        df = HyperScalpingFeatures.calculate_micro_momentum(df, df_5m)

        # === TICK VOLATILITY ===
        df = HyperScalpingFeatures.calculate_tick_volatility(df)

        # === VWAP DEVIATION ===
        df = HyperScalpingFeatures.calculate_vwap_deviation(df, lookback=50)

        # === ORDER BOOK IMBALANCE (single value, replicate to all rows) ===
        obi = HyperScalpingFeatures.calculate_order_book_imbalance(order_book)
        df['obi'] = obi

        # === FUNDING RATE (single value, replicate to all rows) ===
        df['funding_rate'] = funding_rate if funding_rate is not None else 0.0

        # === BASIC INDICATORS (complementary) ===
        # EMA slopes (trend)
        df['ema_9'] = ta.EMA(df['close'].values, timeperiod=9)
        df['ema_21'] = ta.EMA(df['close'].values, timeperiod=21)
        df['ema_9_slope'] = df['ema_9'].diff(3) / df['ema_9']
        df['ema_21_slope'] = df['ema_21'].diff(3) / df['ema_21']
        df['price_above_ema9'] = (df['close'] > df['ema_9']).astype(int)
        df['price_above_ema21'] = (df['close'] > df['ema_21']).astype(int)

        # ADX (trend strength) - CRITICAL for filter
        df['adx'] = ta.ADX(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['plus_di'] = ta.PLUS_DI(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['minus_di'] = ta.MINUS_DI(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

        # MACD (momentum)
        macd, signal, hist = ta.MACD(df['close'].values, fastperiod=12, slowperiod=26, signalperiod=9)
        df['macd'] = macd
        df['macd_signal'] = signal
        df['macd_hist'] = hist
        df['macd_cross'] = np.where(macd > signal, 1, -1)

        # Bollinger Bands (volatility)
        upper, middle, lower = ta.BBANDS(df['close'].values, timeperiod=20, nbdevup=2, nbdevdn=2)
        df['bb_upper'] = upper
        df['bb_middle'] = middle
        df['bb_lower'] = lower
        df['bb_width'] = (upper - lower) / middle
        df['bb_position'] = (df['close'] - lower) / (upper - lower + 1e-10)

        return df

    @staticmethod
    def get_feature_columns() -> list:
        """
        Get list of feature columns for ML model

        OPTIMIZED: Only high-value features for hyper-scalping
        """
        features = [
            # Micro-momentum (CRITICAL)
            'rsi_1m_fast', 'rsi_1m_slow', 'rsi_diff_fast_slow',
            'rsi_5m', 'rsi_divergence_1m_5m',
            'stoch_k', 'stoch_d', 'stoch_cross',
            'momentum_1', 'momentum_2', 'momentum_5',
            'momentum_velocity', 'momentum_acceleration',

            # Tick volatility (CRITICAL)
            'atr_normalized', 'atr_percentile',
            'tick_range', 'spread_estimate',
            'volume_ratio', 'volume_surge',
            'volatility_high', 'volatility_low',

            # VWAP deviation (CRITICAL for mean reversion)
            'vwap_deviation_pct', 'vwap_position',
            'vwap_overextended_up', 'vwap_overextended_down',
            'vwap_slope', 'price_above_vwap',

            # Market microstructure
            'obi', 'funding_rate',

            # Trend & momentum (supplementary)
            'ema_9_slope', 'ema_21_slope',
            'price_above_ema9', 'price_above_ema21',
            'adx', 'plus_di', 'minus_di',
            'macd_cross', 'macd_hist',
            'bb_width', 'bb_position',
        ]

        return features
