"""
Professional Live Trading Bot v5.0 - INSTITUTIONAL GRADE
Features:
- XGBoost ML predictions with multi-timeframe analysis
- Fixed risk position sizing (1-2% per trade)
- 3-stage hybrid exit system (partial TP + trailing stop + breakeven)
- Advanced feature engineering (60+ features)
- Commission tracking
- Temporal cross-validation
"""

import asyncio
import ccxt
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone
import logging
import os
import json
from pathlib import Path
from typing import Optional, Dict, List
import signal as sys_signal

# Import professional modules
from XGBoostStrategy import XGBoostStrategyEngine
from ProfessionalRiskManager import ProfessionalRiskManager
from AdvancedFeatureEngineering import AdvancedFeatureEngineering
from PositionValidator import PositionValidator

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trading_bot_pro.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('TradingBotPro')


class MultiTimeframeDataFetcher:
    """Fetches and manages multi-timeframe real-time data"""

    def __init__(self, exchange: ccxt.Exchange, symbol: str):
        self.exchange = exchange
        self.symbol = symbol  # Format: BTC/USDT:USDT for futures

        # Data buffers for different timeframes
        self.buffer_15m = pd.DataFrame()
        self.buffer_1h = pd.DataFrame()
        self.buffer_4h = pd.DataFrame()

        logger.info(f"MultiTimeframeDataFetcher initialized: {symbol}")

    async def fetch_all_timeframes(self, limit_15m: int = 500) -> Dict[str, pd.DataFrame]:
        """
        Fetch latest candles for all timeframes

        IMPORTANT: Increased limits to support feature engineering
        - 500 candles @ 15m = ~5 days of data (enough for EMA 200, ADX, etc.)
        - 300 candles @ 1h = ~12.5 days
        - 200 candles @ 4h = ~33 days

        Returns:
            Dict with 'df_15m', 'df_1h', 'df_4h'
        """
        try:
            # Fetch 15m data (primary) - INCREASED to 500 for feature calculation
            candles_15m = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                self.symbol,
                '15m',
                limit=limit_15m
            )

            # Fetch 1h data - INCREASED to 300
            candles_1h = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                self.symbol,
                '1h',
                limit=300
            )

            # Fetch 4h data - INCREASED to 200
            candles_4h = await asyncio.to_thread(
                self.exchange.fetch_ohlcv,
                self.symbol,
                '4h',
                limit=300
            )

            # Convert to DataFrames
            self.buffer_15m = self._candles_to_df(candles_15m)
            self.buffer_1h = self._candles_to_df(candles_1h)
            self.buffer_4h = self._candles_to_df(candles_4h)

            logger.debug(
                f"[DATA] Fetched: 15m={len(self.buffer_15m)}, "
                f"1h={len(self.buffer_1h)}, 4h={len(self.buffer_4h)}"
            )

            return {
                'df_15m': self.buffer_15m,
                'df_1h': self.buffer_1h,
                'df_4h': self.buffer_4h
            }

        except Exception as e:
            logger.error(f"Error fetching multi-timeframe data: {e}")
            return {
                'df_15m': pd.DataFrame(),
                'df_1h': pd.DataFrame(),
                'df_4h': pd.DataFrame()
            }

    def _candles_to_df(self, candles: list) -> pd.DataFrame:
        """Convert candle list to DataFrame"""
        if not candles:
            return pd.DataFrame()

        df = pd.DataFrame(
            candles,
            columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
        )
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        return df

    async def get_current_price(self) -> float:
        """Get current market price"""
        try:
            ticker = await asyncio.to_thread(
                self.exchange.fetch_ticker,
                self.symbol
            )
            return ticker['last']
        except Exception as e:
            logger.error(f"Error fetching price: {e}")
            return 0.0

    def get_current_atr(self, period: int = 14) -> float:
        """Calculate current ATR from 15m data"""
        if len(self.buffer_15m) < period:
            return 0.0

        import talib as ta
        atr = ta.ATR(
            self.buffer_15m['high'].values,
            self.buffer_15m['low'].values,
            self.buffer_15m['close'].values,
            timeperiod=period
        )
        return atr[-1] if len(atr) > 0 else 0.0


class OrderExecutor:
    """Executes futures orders on Bitget"""

    def __init__(self, exchange: ccxt.Exchange, dry_run: bool = True):
        self.exchange = exchange
        self.dry_run = dry_run
        self.order_history: List[Dict] = []
        self.tp_sl_orders: Dict[str, List[str]] = {}  # Track TP/SL order IDs by position

        logger.info(f"OrderExecutor initialized: {'DRY-RUN' if dry_run else 'LIVE'}")

    async def place_market_order(
        self,
        symbol: str,
        side: str,
        amount: float,
        leverage: float = 10.0,
        price: float = 0.0
    ) -> Optional[Dict]:
        """Place market order on futures market"""

        if self.dry_run:
            logger.info(
                f"[DRY-RUN] Futures Market order: {side.upper()} {amount:.8f} {symbol} @ ${price:.2f}"
            )
            return {
                'id': f'dry_run_{datetime.now(timezone.utc).timestamp()}',
                'symbol': symbol,
                'side': side,
                'amount': amount,
                'price': price,
                'status': 'closed',
                'timestamp': datetime.now(timezone.utc).isoformat()
            }

        try:
            logger.info(f"[ORDER] Futures Market {side.upper()} {amount:.8f} {symbol}")

            params = {
                'tdMode': 'cross',
                'ordType': 'market',
                'posMode': 'net',
                'leverage': int(leverage)
            }

            order = await asyncio.to_thread(
                self.exchange.create_order,
                symbol, 'market', side, amount, None, params
            )

            logger.info(f"[ORDER SUCCESS] Futures market order executed: {order.get('id')}")
            self.order_history.append(order)
            return order

        except Exception as e:
            logger.error(f"[ORDER ERROR] {str(e)}")
            return None

    async def place_tp_sl_orders(
        self,
        symbol: str,
        direction: str,
        amount: float,
        stop_loss: float,
        take_profit: float,
        reduce_only: bool = True
    ) -> Dict[str, Optional[Dict]]:
        """
        Place Take Profit and Stop Loss orders for a position

        Args:
            symbol: Trading pair (e.g., 'BTC/USDT:USDT')
            direction: 'LONG' or 'SHORT'
            amount: Position size
            stop_loss: Stop loss price
            take_profit: Take profit price
            reduce_only: Only close existing position (don't open new)

        Returns:
            Dict with 'tp_order' and 'sl_order' keys
        """

        if self.dry_run:
            logger.info(
                f"[DRY-RUN] TP/SL orders: TP @ ${take_profit:.2f} | SL @ ${stop_loss:.2f}"
            )
            return {
                'tp_order': {
                    'id': f'dry_run_tp_{datetime.now(timezone.utc).timestamp()}',
                    'type': 'take_profit',
                    'price': take_profit
                },
                'sl_order': {
                    'id': f'dry_run_sl_{datetime.now(timezone.utc).timestamp()}',
                    'type': 'stop_loss',
                    'price': stop_loss
                }
            }

        results = {'tp_order': None, 'sl_order': None}

        try:
            # Determine order side (opposite of position for closing)
            close_side = 'sell' if direction == 'LONG' else 'buy'

            # Place Stop Loss order (using trigger order)
            logger.info(f"[SL ORDER] Placing stop loss @ ${stop_loss:.2f}")
            sl_params = {
                'triggerPrice': stop_loss,  # Price that triggers the order
                'stopLossPrice': stop_loss,  # Execution price
                'reduceOnly': reduce_only,
                'tdMode': 'cross'
            }

            sl_order = await asyncio.to_thread(
                self.exchange.create_order,
                symbol,
                'trigger',  # Trigger market order
                close_side,
                amount,
                stop_loss,  # Stop price
                sl_params
            )
            results['sl_order'] = sl_order
            logger.info(f"[SL SUCCESS] Stop loss order placed: {sl_order.get('id')}")

            # Place Take Profit order (using trigger order)
            logger.info(f"[TP ORDER] Placing take profit @ ${take_profit:.2f}")
            tp_params = {
                'triggerPrice': take_profit,  # Price that triggers the order
                'takeProfitPrice': take_profit,  # Execution price
                'reduceOnly': reduce_only,
                'tdMode': 'cross'
            }

            tp_order = await asyncio.to_thread(
                self.exchange.create_order,
                symbol,
                'trigger',  # Trigger market order
                close_side,
                amount,
                take_profit,  # Trigger price
                tp_params
            )
            results['tp_order'] = tp_order
            logger.info(f"[TP SUCCESS] Take profit order placed: {tp_order.get('id')}")

            # Track order IDs
            order_key = f"{symbol}_{direction}"
            self.tp_sl_orders[order_key] = [
                tp_order.get('id', ''),
                sl_order.get('id', '')
            ]

        except Exception as e:
            logger.error(f"[TP/SL ERROR] Failed to place TP/SL orders: {str(e)}")

        return results

    async def cancel_tp_sl_orders(self, symbol: str, direction: str):
        """Cancel existing TP/SL orders for a position"""

        if self.dry_run:
            logger.info(f"[DRY-RUN] Cancelling TP/SL orders for {symbol}")
            return

        order_key = f"{symbol}_{direction}"
        if order_key not in self.tp_sl_orders:
            return

        try:
            for order_id in self.tp_sl_orders[order_key]:
                if order_id:
                    await asyncio.to_thread(
                        self.exchange.cancel_order,
                        order_id,
                        symbol
                    )
                    logger.info(f"[CANCEL] Cancelled order {order_id}")

            del self.tp_sl_orders[order_key]

        except Exception as e:
            logger.error(f"[CANCEL ERROR] Failed to cancel TP/SL orders: {str(e)}")


class ProfessionalTradingBot:
    """
    Professional Trading Bot with Institutional-Grade Architecture

    Components:
    - XGBoost ML strategy
    - Multi-timeframe analysis
    - Fixed risk position sizing
    - 3-stage hybrid exits
    - Commission tracking
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        api_password: str,
        symbol: str = 'BTC/USDT',
        initial_equity: float = 1000.0,
        risk_per_trade_pct: float = 0.02,
        leverage: float = 10.0,
        confidence_threshold: float = 0.65,
        dry_run: bool = True
    ):
        self.symbol = symbol
        self.futures_symbol = f"{symbol.split('/')[0]}/USDT:USDT"
        self.leverage = leverage
        self.dry_run = dry_run
        self.running = False
        self.shutdown_event = asyncio.Event()

        # Initialize FUTURES exchange
        self.exchange = ccxt.bitget({
            'apiKey': api_key,
            'secret': api_secret,
            'password': api_password,
            'enableRateLimit': True,
            'options': {'defaultType': 'swap'}
        })

        # Multi-timeframe data fetcher
        self.data_fetcher = MultiTimeframeDataFetcher(self.exchange, self.futures_symbol)

        # Professional risk manager
        self.risk_manager = ProfessionalRiskManager(
            initial_equity=initial_equity,
            risk_per_trade_pct=risk_per_trade_pct,
            leverage=leverage,
            max_daily_loss_pct=0.05,
            min_order_value=10.0,
            atr_trailing_multiplier=3.0
        )

        # Order executor
        self.executor = OrderExecutor(self.exchange, dry_run)

        # XGBoost strategy engine
        self.strategy_engine = None
        self.confidence_threshold = confidence_threshold

        # Position validator (initialized after strategy engine is loaded)
        self.position_validator = None

        # Trade log
        self.trade_log = []

        logger.info(
            f"ProfessionalTradingBot initialized:\n"
            f"  Symbol: {self.futures_symbol}\n"
            f"  Initial Equity: ${initial_equity:,.2f}\n"
            f"  Risk per Trade: {risk_per_trade_pct*100:.1f}%\n"
            f"  Leverage: {leverage}x\n"
            f"  Confidence Threshold: {confidence_threshold}\n"
            f"  Mode: {'DRY-RUN' if dry_run else 'LIVE TRADING'}"
        )

    def load_strategy(self):
        """Load trained XGBoost strategy"""
        logger.info("Loading XGBoost strategy engine...")

        self.strategy_engine = XGBoostStrategyEngine(
            symbol=self.futures_symbol,
            confidence_threshold=self.confidence_threshold,
            dry_run=self.dry_run
        )

        if not self.strategy_engine.is_trained:
            logger.error(
                "[ERROR] Model not trained!\n"
                "Run: python train_xgboost_model.py"
            )
            raise ValueError("Strategy model not found")

        logger.info("[OK] XGBoost strategy engine loaded")

        # Initialize position validator with loaded strategy
        self.position_validator = PositionValidator(
            strategy_engine=self.strategy_engine,
            risk_manager=self.risk_manager,
            order_executor=self.executor,
            low_confidence_threshold=0.40,  # 40% threshold
            validation_interval_hours=24    # Validate every 24 hours
        )

        logger.info("[OK] Position validator initialized")

    async def run(self):
        """Main event loop"""
        self.running = True
        logger.info("[START] Professional futures trading bot started")

        # Validate credentials
        if not self.dry_run and not self.exchange.apiKey:
            logger.error("[ERROR] LIVE TRADING requires API credentials!")
            return

        if self.dry_run and not self.exchange.apiKey:
            logger.warning("[WARN] DRY-RUN mode without credentials")
            return

        try:
            await self._run_trading_loop()
        except KeyboardInterrupt:
            logger.info("[STOP] Shutdown signal received")
            self.running = False
        finally:
            await self._shutdown()

    async def _run_trading_loop(self):
        """Main trading loop with multi-timeframe analysis"""
        logger.info("[TRADING] Starting professional trading loop")

        check_interval = 30  # Check every 30 seconds

        while self.running:
            try:
                # Fetch multi-timeframe data (500 candles @ 15m for proper feature calculation)
                mtf_data = await self.data_fetcher.fetch_all_timeframes(limit_15m=500)

                df_15m = mtf_data['df_15m']
                df_1h = mtf_data['df_1h']
                df_4h = mtf_data['df_4h']

                if df_15m.empty:
                    logger.warning("[DATA] No 15m data received, retrying...")
                    await asyncio.sleep(10)
                    continue

                # Get current price and ATR
                current_price = await self.data_fetcher.get_current_price()
                if current_price == 0:
                    logger.warning("[DATA] Invalid price, retrying...")
                    await asyncio.sleep(10)
                    continue

                current_atr = self.data_fetcher.get_current_atr()

                logger.info(
                    f"[TICK] {self.futures_symbol} @ ${current_price:.2f} | "
                    f"ATR: ${current_atr:.2f}"
                )

                # Check existing positions
                await self._check_positions(current_price, current_atr)

                # Validate open positions every 24 hours
                if self.position_validator and self.risk_manager.positions:
                    await self.position_validator.validate_all_positions(
                        current_price=current_price,
                        current_atr=current_atr,
                        df_15m=df_15m,
                        df_1h=df_1h,
                        df_4h=df_4h
                    )

                # Generate signal if no position
                if self.strategy_engine and self.risk_manager.can_open_position(self.futures_symbol):
                    await self._generate_and_execute_signal(
                        df_15m, df_1h, df_4h, current_price, current_atr
                    )

                # Reset daily stats
                self.risk_manager.reset_daily_stats()

                # Print statistics periodically
                if int(datetime.now(timezone.utc).timestamp()) % 300 == 0:  # Every 5 min
                    self._print_statistics()

                    # Print validation status
                    if self.position_validator and self.risk_manager.positions:
                        self._print_validation_status()

                # Wait for next check
                logger.info(f"[WAIT] Next check in {check_interval}s...")
                elapsed = 0

                while elapsed < check_interval and self.running:
                    try:
                        await asyncio.wait_for(
                            self.shutdown_event.wait(),
                            timeout=min(5, check_interval - elapsed)
                        )
                        break
                    except asyncio.TimeoutError:
                        elapsed += 5
                        # Quick position check every 5 seconds
                        if self.risk_manager.positions:
                            current_price = await self.data_fetcher.get_current_price()
                            current_atr = self.data_fetcher.get_current_atr()
                            if current_price > 0:
                                await self._check_positions(current_price, current_atr)
                        if elapsed >= check_interval:
                            break

            except Exception as e:
                logger.error(f"[ERROR] Trading loop: {e}", exc_info=True)
                await asyncio.sleep(60)

    async def _generate_and_execute_signal(
        self,
        df_15m: pd.DataFrame,
        df_1h: pd.DataFrame,
        df_4h: pd.DataFrame,
        current_price: float,
        current_atr: float
    ):
        """Generate ML signal and execute if valid"""

        # Get prediction
        predicted_class, confidence = self.strategy_engine.predict(df_15m, df_1h, df_4h)

        if confidence < self.confidence_threshold:
            logger.debug(
                f"[SIGNAL] Low confidence: {confidence:.2%} < {self.confidence_threshold:.2%}"
            )
            return

        direction = 'LONG' if predicted_class == 1 else 'SHORT'

        logger.info(
            f"[SIGNAL] ML Prediction: {direction} | Confidence: {confidence:.2%}"
        )

        # Calculate stop loss (1.5% from entry)
        if direction == 'LONG':
            stop_loss = current_price * 0.985
        else:
            stop_loss = current_price * 1.015

        # Calculate position size
        position_size = self.risk_manager.calculate_position_size(
            entry_price=current_price,
            stop_loss=stop_loss,
            equity=self.risk_manager.current_equity
        )

        if position_size == 0:
            logger.error("[ERROR] Position size is zero - insufficient equity")
            return

        # Calculate take profit levels
        tp1, tp2 = self.risk_manager.calculate_take_profit_levels(
            entry_price=current_price,
            stop_loss=stop_loss,
            direction=direction,
            atr=current_atr
        )

        # Validate order value
        order_value = position_size * current_price
        if order_value < self.risk_manager.min_order_value:
            logger.error(
                f"[ERROR] Order value ${order_value:.2f} < min ${self.risk_manager.min_order_value:.2f}"
            )
            return

        # Execute order
        side = 'buy' if direction == 'LONG' else 'sell'
        order = await self.executor.place_market_order(
            symbol=self.futures_symbol,
            side=side,
            amount=position_size,
            leverage=self.leverage,
            price=current_price
        )

        if order:
            # Register position in risk manager
            self.risk_manager.open_position(
                symbol=self.futures_symbol,
                direction=direction,
                entry_price=current_price,
                stop_loss=stop_loss,
                take_profit_1=tp1,
                take_profit_2=tp2,
                position_size=position_size,
                order_id=order['id']
            )

            # Place TP/SL orders on exchange (for TP2 - final take profit)
            await self.executor.place_tp_sl_orders(
                symbol=self.futures_symbol,
                direction=direction,
                amount=position_size,
                stop_loss=stop_loss,
                take_profit=tp2,  # Use TP2 as the main take profit on exchange
                reduce_only=True
            )

            logger.info(
                f"[POSITION OPENED] {direction} {position_size:.8f} @ ${current_price:.2f}\n"
                f"  Stop Loss: ${stop_loss:.2f}\n"
                f"  Take Profit 1 (Partial): ${tp1:.2f}\n"
                f"  Take Profit 2 (Final): ${tp2:.2f}"
            )

            # Log trade
            self.trade_log.append({
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'symbol': self.futures_symbol,
                'direction': direction,
                'entry_price': current_price,
                'stop_loss': stop_loss,
                'tp1': tp1,
                'tp2': tp2,
                'size': position_size,
                'confidence': confidence,
                'order_id': order['id']
            })
            self._save_trade_log()

    async def _check_positions(self, current_price: float, current_atr: float):
        """Check all positions for exit conditions"""

        for symbol in list(self.risk_manager.positions.keys()):
            exit_signal = self.risk_manager.check_exit_conditions(
                symbol=symbol,
                current_price=current_price,
                atr=current_atr
            )

            if exit_signal:
                action = exit_signal['action']
                size = exit_signal['size']
                price = exit_signal['price']

                # Determine if partial or full close
                if action == 'take_profit_1':
                    await self._execute_partial_close(symbol, size, price)
                else:
                    await self._execute_full_close(symbol, price, action)

    async def _execute_partial_close(self, symbol: str, size: float, exit_price: float):
        """Execute partial close (TP1)"""

        position = self.risk_manager.positions[symbol]

        # Cancel existing TP/SL orders (we'll place new ones for remaining position)
        await self.executor.cancel_tp_sl_orders(symbol, position.direction)

        # Close 50%
        side = 'sell' if position.direction == 'LONG' else 'buy'
        order = await self.executor.place_market_order(
            symbol=symbol,
            side=side,
            amount=size,
            leverage=self.leverage,
            price=exit_price
        )

        if order:
            result = self.risk_manager.execute_partial_close(symbol, size, exit_price)

            # Place new TP/SL for remaining 50% with breakeven SL
            remaining_size = result['size_remaining']
            if remaining_size > 0:
                await self.executor.place_tp_sl_orders(
                    symbol=symbol,
                    direction=position.direction,
                    amount=remaining_size,
                    stop_loss=position.entry_price,  # Breakeven SL
                    take_profit=position.take_profit_2,  # Keep TP2
                    reduce_only=True
                )

            logger.info(
                f"[PARTIAL CLOSE] {symbol} - PnL: ${result['pnl']:,.2f} | "
                f"Remaining: {result['size_remaining']:.8f} BTC | "
                f"Breakeven SL set @ ${position.entry_price:.2f}"
            )

    async def _execute_full_close(self, symbol: str, exit_price: float, reason: str):
        """Execute full position close"""

        position = self.risk_manager.positions[symbol]

        # Cancel existing TP/SL orders before closing
        await self.executor.cancel_tp_sl_orders(symbol, position.direction)

        # Close remaining position
        side = 'sell' if position.direction == 'LONG' else 'buy'
        order = await self.executor.place_market_order(
            symbol=symbol,
            side=side,
            amount=position.current_size,
            leverage=self.leverage,
            price=exit_price
        )

        if order:
            result = self.risk_manager.close_position(symbol, exit_price, reason)
            logger.info(
                f"[FULL CLOSE] {symbol} ({reason}) | "
                f"PnL: ${result['pnl']:,.2f} ({result['return_pct']:+.2f}%)"
            )

    def _print_statistics(self):
        """Print current session statistics"""
        stats = self.risk_manager.get_statistics()

        logger.info(
            f"\n{'='*60}\n"
            f"SESSION STATISTICS\n"
            f"{'='*60}\n"
            f"Initial Equity: ${stats['initial_equity']:,.2f}\n"
            f"Current Equity: ${stats['current_equity']:,.2f}\n"
            f"Total PnL: ${stats['total_pnl']:,.2f} ({stats['return_pct']:+.2f}%)\n"
            f"Daily PnL: ${stats['daily_pnl']:,.2f}\n"
            f"Total Trades: {stats['total_trades']}\n"
            f"Win Rate: {stats['win_rate']:.1f}%\n"
            f"Open Positions: {stats['open_positions']}\n"
            f"{'='*60}"
        )

    def _print_validation_status(self):
        """Print position validation status"""
        if not self.position_validator:
            return

        validation_status = self.position_validator.get_validation_status()

        logger.info(
            f"\n{'='*60}\n"
            f"POSITION VALIDATION STATUS (24H CHECK)\n"
            f"{'='*60}"
        )

        for symbol, status in validation_status.items():
            logger.info(
                f"Symbol: {symbol}\n"
                f"  Last Validation: {status['last_validation'] or 'Never'}\n"
                f"  Hours Since Last: {status['hours_since_last']:.1f}h" if status['hours_since_last'] else "  Hours Since Last: N/A\n"
                f"  Next Validation: {status['next_validation_in']}"
            )

        logger.info(f"{'='*60}")

    def _save_trade_log(self):
        """Save trade log to JSON"""
        log_file = Path('trade_log_pro.json')
        with open(log_file, 'w') as f:
            json.dump(self.trade_log, f, indent=2, default=str)

    async def _shutdown(self):
        """Graceful shutdown"""
        logger.info("[SHUTDOWN] Closing all positions...")
        self.running = False

        # Close all open positions
        for symbol in list(self.risk_manager.positions.keys()):
            current_price = await self.data_fetcher.get_current_price()
            if current_price > 0:
                await self._execute_full_close(symbol, current_price, 'Shutdown')

        # Print final statistics
        self._print_statistics()

        logger.info("[STOP] Professional bot stopped gracefully")


async def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(description='Professional Futures Trading Bot')
    parser.add_argument('--dry-run', action='store_true', help='Run in simulation mode')
    parser.add_argument('--symbol', default='BTC/USDT', help='Trading pair')
    parser.add_argument('--equity', type=float, default=200, help='Initial equity (default: 200 USDT)')
    parser.add_argument('--risk-pct', type=float, default=None, help='Risk per trade as percentage (e.g., 0.02 = 2%%)')
    parser.add_argument('--risk-usd', type=float, default=50, help='Risk per trade in USD (default: 50 USDT)')
    parser.add_argument('--leverage', type=float, default=20.0, help='Leverage (default: 20x)')
    parser.add_argument('--confidence', type=float, default=0.65, help='Confidence threshold (default: 0.65)')
    args = parser.parse_args()

    # Get API credentials
    api_key = os.getenv('BITGET_API_KEY', '')
    api_secret = os.getenv('BITGET_SECRET', '')
    api_password = os.getenv('BITGET_PASSWORD', '')

    if not args.dry_run and (not api_key or not api_secret or not api_password):
        logger.error("API credentials not set! Use --dry-run or set environment variables.")
        return

    # Calculate risk percentage from USD if not specified
    if args.risk_pct is None:
        risk_per_trade_pct = args.risk_usd / args.equity
    else:
        risk_per_trade_pct = args.risk_pct

    # Initialize bot
    bot = ProfessionalTradingBot(
        api_key=api_key,
        api_secret=api_secret,
        api_password=api_password,
        symbol=args.symbol,
        initial_equity=args.equity,
        risk_per_trade_pct=risk_per_trade_pct,
        leverage=args.leverage,
        confidence_threshold=args.confidence,
        dry_run=args.dry_run
    )

    # Load strategy
    try:
        bot.load_strategy()
    except Exception as e:
        logger.error(f"Failed to load strategy: {e}")
        return

    # Handle shutdown
    def signal_handler(sig, frame):
        logger.info("[INTERRUPT] Ctrl+C - stopping bot...")
        bot.running = False
        bot.shutdown_event.set()

    sys_signal.signal(sys_signal.SIGINT, signal_handler)
    sys_signal.signal(sys_signal.SIGTERM, signal_handler)

    # Run bot
    await bot.run()


if __name__ == '__main__':
    asyncio.run(main())
