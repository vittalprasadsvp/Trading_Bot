"""
Training Script for XGBoost Strategy
Includes multi-timeframe data fetching and advanced feature engineering
"""

import pandas as pd
from pathlib import Path
import logging
from XGBoostStrategy import XGBoostStrategyEngine
import glob
import sys

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def find_latest_csv(data_dir: str = 'data', symbol_pattern: str = 'BTC_USDT', timeframe: str = '15m') -> Path:
    """Find the most recent CSV file for a specific timeframe"""
    data_path = Path(data_dir)

    if not data_path.exists():
        raise FileNotFoundError(
            f"Directory '{data_dir}' not found. Run data_fetcher.py first!"
        )

    # Find all matching CSV files
    pattern = f'{symbol_pattern}*{timeframe}*.csv'
    csv_files = list(data_path.glob(pattern))

    if not csv_files:
        raise FileNotFoundError(
            f"No CSV files found in '{data_dir}' matching '{pattern}'. "
            "Run data_fetcher.py first to download historical data!"
        )

    # Get the most recent file
    latest_file = max(csv_files, key=lambda p: p.stat().st_mtime)
    return latest_file


def load_multi_timeframe_data(symbol: str = 'BTC/USDT') -> tuple:
    """
    Load 15m, 1h, and 4h data for multi-timeframe analysis

    Returns:
        (df_15m, df_1h, df_4h) tuple
    """
    symbol_clean = symbol.split('/')[0]  # BTC from BTC/USDT

    try:
        # Load 15-minute data (primary)
        csv_15m = find_latest_csv(symbol_pattern=f'{symbol_clean}_USDT', timeframe='15m')
        logger.info(f"Loading 15m data: {csv_15m}")
        df_15m = pd.read_csv(csv_15m)
        df_15m['timestamp'] = pd.to_datetime(df_15m['timestamp'])
        logger.info(f"[OK] 15m data: {len(df_15m)} candles")

        # Load 1-hour data (optional)
        try:
            csv_1h = find_latest_csv(symbol_pattern=f'{symbol_clean}_USDT', timeframe='1h')
            logger.info(f"Loading 1h data: {csv_1h}")
            df_1h = pd.read_csv(csv_1h)
            df_1h['timestamp'] = pd.to_datetime(df_1h['timestamp'])
            logger.info(f"[OK] 1h data: {len(df_1h)} candles")
        except FileNotFoundError:
            logger.warning("[WARN] 1h data not found, multi-timeframe features will be limited")
            df_1h = None

        # Load 4-hour data (optional)
        try:
            csv_4h = find_latest_csv(symbol_pattern=f'{symbol_clean}_USDT', timeframe='4h')
            logger.info(f"Loading 4h data: {csv_4h}")
            df_4h = pd.read_csv(csv_4h)
            df_4h['timestamp'] = pd.to_datetime(df_4h['timestamp'])
            logger.info(f"[OK] 4h data: {len(df_4h)} candles")
        except FileNotFoundError:
            logger.warning("[WARN] 4h data not found, multi-timeframe features will be limited")
            df_4h = None

        return df_15m, df_1h, df_4h

    except FileNotFoundError as e:
        logger.error(f"\n❌ {e}")
        logger.error(
            "\n💡 Solution: Download historical data first:\n"
            "   python data_fetcher.py\n"
            "\n   Make sure to fetch data for all timeframes:\n"
            "   - 15m (primary)\n"
            "   - 1h (for trend context)\n"
            "   - 4h (for higher timeframe trend)\n"
        )
        raise


def train_xgboost_model(
    symbol: str = 'BTC/USDT',
    confidence_threshold: float = 0.65,
    test_size: float = 0.2,
    cv_splits: int = 5
):
    """
    Train XGBoost model with multi-timeframe data

    Args:
        symbol: Trading symbol
        confidence_threshold: Minimum confidence for signals
        test_size: Proportion of data for testing
        cv_splits: Number of cross-validation splits
    """
    print("\n" + "="*80)
    print("XGBOOST MODEL TRAINING - MULTI-TIMEFRAME STRATEGY")
    print("="*80)

    # Load data
    logger.info(f"\n[1/4] Loading multi-timeframe data for {symbol}...")
    df_15m, df_1h, df_4h = load_multi_timeframe_data(symbol)

    # Validate data
    if len(df_15m) < 500:
        logger.error(
            f"[ERROR] Insufficient 15m data: {len(df_15m)} candles. "
            f"Need at least 500 for robust training."
        )
        return 1

    logger.info(
        f"\n[DATA SUMMARY]\n"
        f"  15m: {len(df_15m)} candles ({df_15m['timestamp'].min()} to {df_15m['timestamp'].max()})\n"
        f"  1h:  {len(df_1h) if df_1h is not None else 0} candles\n"
        f"  4h:  {len(df_4h) if df_4h is not None else 0} candles"
    )

    # Initialize engine
    logger.info(f"\n[2/4] Initializing XGBoost strategy engine...")
    engine = XGBoostStrategyEngine(
        symbol=symbol,
        confidence_threshold=confidence_threshold,
        dry_run=True
    )

    # Train model
    logger.info(f"\n[3/4] Training XGBoost model with temporal cross-validation...")
    logger.info(f"  This may take 2-5 minutes depending on data size...")

    try:
        results = engine.train_model(
            historical_data=df_15m,
            df_1h=df_1h,
            df_4h=df_4h,
            n_splits=cv_splits,
            test_size=test_size
        )
    except Exception as e:
        logger.error(f"[ERROR] Training failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    # Print results
    print("\n" + "="*80)
    print("MODEL TRAINING COMPLETE")
    print("="*80)

    # Cross-validation results
    print("\n[CROSS-VALIDATION RESULTS]")
    cv_scores = results['cv_scores']
    for metric, stats in cv_scores.items():
        print(f"  {metric.upper():12s}: {stats['mean']:.3f} ± {stats['std']:.3f}")

    # Test set results
    print("\n[TEST SET PERFORMANCE]")
    test_metrics = results['test_metrics']
    for metric, value in test_metrics.items():
        print(f"  {metric.upper():12s}: {value:.3f}")

    # Feature importance
    print("\n[TOP 10 MOST IMPORTANT FEATURES]")
    feature_importance = results['feature_importance'].head(10)
    for idx, row in feature_importance.iterrows():
        print(f"  {row['feature']:30s}: {row['importance']:.4f}")

    # Model assessment
    print("\n" + "="*80)
    test_acc = test_metrics['accuracy']
    test_auc = test_metrics['auc']

    if test_acc >= 0.55 and test_auc >= 0.55:
        print("[✓ SUCCESS] Model meets performance targets!")
        print(f"  Accuracy: {test_acc:.2%} (target: >55%)")
        print(f"  AUC:      {test_auc:.2%} (target: >55%)")
    else:
        print("[⚠ WARNING] Model performance below targets")
        print(f"  Accuracy: {test_acc:.2%} (target: >55%)")
        print(f"  AUC:      {test_auc:.2%} (target: >55%)")
        print("\n  Recommendations:")
        print("  - Fetch more historical data (120+ days)")
        print("  - Ensure 1h and 4h data are available for multi-timeframe features")
        print("  - Review feature importance and eliminate low-value features")
        print("  - Adjust confidence_threshold if needed")

    print("\n[NEXT STEPS]")
    print("  1. Review cross-validation scores for overfitting")
    print("  2. Test bot in dry-run mode:")
    print(f"     python live_trading_bot_pro.py --dry-run --equity 1000")
    print("  3. Monitor performance for several days before going live")
    print("  4. Only enable live trading after successful dry-run testing")

    print("\n" + "="*80 + "\n")

    return 0


def main():
    """Main training workflow"""
    import argparse

    parser = argparse.ArgumentParser(description='Train XGBoost trading model')
    parser.add_argument('--symbol', type=str, default='BTC/USDT', help='Trading symbol')
    parser.add_argument(
        '--confidence',
        type=float,
        default=0.65,
        help='Confidence threshold (default: 0.65)'
    )
    parser.add_argument(
        '--test-size',
        type=float,
        default=0.2,
        help='Test data proportion (default: 0.2)'
    )
    parser.add_argument(
        '--cv-splits',
        type=int,
        default=5,
        help='Cross-validation splits (default: 5)'
    )
    args = parser.parse_args()

    try:
        exit_code = train_xgboost_model(
            symbol=args.symbol,
            confidence_threshold=args.confidence,
            test_size=args.test_size,
            cv_splits=args.cv_splits
        )
        return exit_code

    except Exception as e:
        logger.error(f"\n❌ Training failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
