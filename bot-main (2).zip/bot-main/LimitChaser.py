"""
Limit Order Chaser - MAKER-FOCUSED EXECUTION
Optimized to avoid taker fees (0.06%) by placing limit orders at best bid/ask
and chasing execution with dynamic repositioning
"""

import asyncio
import ccxt
from datetime import datetime, timezone
from typing import Optional, Dict, Tuple
import logging

logger = logging.getLogger(__name__)


class LimitOrderChaser:
    """
    Intelligent Limit Order Execution Engine

    Strategy:
    1. Place LIMIT order at Best Bid (buy) or Best Ask (sell)
    2. Every 0.5-1s, check if executed
    3. If not executed, cancel and replace at new Best Bid/Ask
    4. Repeat up to N times (default: 6 attempts = 3 seconds)
    5. If still not executed after N attempts → CANCEL and re-evaluate signal
    6. NEVER fall back to market order (except emergency stop loss)

    Fees saved:
    - Maker: 0.02%
    - Taker: 0.06%
    - Savings: 0.04% per trade = $0.40 per $1000 position
    - On 20 trades/day: $8/day savings = $240/month
    """

    def __init__(
        self,
        exchange: ccxt.Exchange,
        dry_run: bool = True,
        timeout_seconds: float = 3.0,
        chase_interval: float = 0.3,  # ULTRA-FAST: Check cada 0.3s
        max_attempts: int = 10,       # 10 intentos × 0.3s = 3 segundos
        allow_taker_fallback: bool = False
    ):
        self.exchange = exchange
        self.dry_run = dry_run
        self.timeout_seconds = timeout_seconds
        self.chase_interval = chase_interval
        self.max_attempts = max_attempts
        self.allow_taker_fallback = allow_taker_fallback

        self.active_order_id: Optional[str] = None
        self.chase_attempts = 0

        logger.info(
            f"LimitChaser initialized: timeout={timeout_seconds}s, "
            f"interval={chase_interval}s, max_attempts={max_attempts}, "
            f"taker_fallback={allow_taker_fallback}"
        )

    async def execute_limit_order_with_chase(
        self,
        symbol: str,
        side: str,  # 'buy' or 'sell'
        amount: float,
        leverage: float = 30.0,
        max_spread_pct: float = 0.0008  # 0.08% max spread
    ) -> Optional[Dict]:
        """
        Execute limit order with intelligent chasing

        Args:
            symbol: e.g., 'BTC/USDT:USDT'
            side: 'buy' or 'sell'
            amount: Position size
            leverage: Leverage multiplier
            max_spread_pct: Maximum acceptable spread (% of price)

        Returns:
            Order dict if successful, None if failed
        """
        logger.info(
            f"[LIMIT CHASE] Starting execution: {side.upper()} {amount:.8f} {symbol} "
            f"(Leverage: {leverage}x)"
        )

        self.chase_attempts = 0
        start_time = datetime.now(timezone.utc).timestamp()

        while self.chase_attempts < self.max_attempts:
            self.chase_attempts += 1
            elapsed = datetime.now(timezone.utc).timestamp() - start_time

            if elapsed > self.timeout_seconds:
                logger.warning(
                    f"[LIMIT CHASE] Timeout after {elapsed:.1f}s and {self.chase_attempts} attempts"
                )
                break

            # Step 1: Get current order book
            order_book = await self._fetch_order_book(symbol)
            if not order_book:
                logger.error("[LIMIT CHASE] Failed to fetch order book")
                await asyncio.sleep(self.chase_interval)
                continue

            # Step 2: Calculate best price and validate spread
            best_price, spread_pct = self._calculate_best_price(order_book, side)
            if best_price is None:
                logger.error("[LIMIT CHASE] Failed to calculate best price")
                await asyncio.sleep(self.chase_interval)
                continue

            # Step 3: Check spread (liquidity filter)
            if spread_pct > max_spread_pct:
                logger.warning(
                    f"[LIMIT CHASE] Spread too wide: {spread_pct:.4%} > {max_spread_pct:.4%}. "
                    f"Market illiquid, aborting."
                )
                return None

            logger.info(
                f"[LIMIT CHASE] Attempt {self.chase_attempts}/{self.max_attempts}: "
                f"Placing LIMIT {side.upper()} @ ${best_price:.2f} (spread: {spread_pct:.4%})"
            )

            # Step 4: Place limit order
            order = await self._place_limit_order(
                symbol, side, amount, best_price, leverage
            )

            if not order:
                logger.error("[LIMIT CHASE] Failed to place limit order")
                await asyncio.sleep(self.chase_interval)
                continue

            self.active_order_id = order.get('id')

            # Step 5: Wait and check if filled
            await asyncio.sleep(self.chase_interval)

            is_filled = await self._check_order_filled(symbol, self.active_order_id)

            if is_filled:
                logger.info(
                    f"[LIMIT CHASE SUCCESS] Order filled as MAKER @ ${best_price:.2f} "
                    f"(attempt {self.chase_attempts}/{self.max_attempts})"
                )
                return order

            # Step 6: Not filled → cancel and retry
            logger.info(f"[LIMIT CHASE] Order not filled, cancelling and repositioning...")
            await self._cancel_order(symbol, self.active_order_id)
            self.active_order_id = None

        # Exceeded max attempts
        logger.warning(
            f"[LIMIT CHASE FAILED] Could not execute after {self.chase_attempts} attempts"
        )

        # Fallback to taker (if allowed)
        if self.allow_taker_fallback:
            logger.warning("[LIMIT CHASE] Falling back to MARKET order (TAKER FEES)")
            return await self._place_market_order_fallback(symbol, side, amount, leverage)

        return None

    async def _fetch_order_book(self, symbol: str, depth: int = 10) -> Optional[Dict]:
        """Fetch current order book"""
        try:
            order_book = await asyncio.to_thread(
                self.exchange.fetch_order_book,
                symbol,
                limit=depth
            )
            return order_book
        except Exception as e:
            logger.error(f"Error fetching order book: {e}")
            return None

    def _calculate_best_price(
        self,
        order_book: Dict,
        side: str
    ) -> Tuple[Optional[float], float]:
        """
        Calculate best limit price and spread

        Returns:
            (best_price, spread_pct)
        """
        try:
            if side == 'buy':
                # For BUY: Place at BEST BID (highest buy price in order book)
                # This way we become a maker (providing liquidity)
                best_bid = order_book['bids'][0][0] if order_book['bids'] else None
                best_ask = order_book['asks'][0][0] if order_book['asks'] else None

                if best_bid is None or best_ask is None:
                    return None, 0.0

                # Calculate spread
                spread_pct = (best_ask - best_bid) / best_ask

                # Use best bid as our limit price (maker)
                return best_bid, spread_pct

            else:  # sell
                # For SELL: Place at BEST ASK (lowest sell price in order book)
                best_bid = order_book['bids'][0][0] if order_book['bids'] else None
                best_ask = order_book['asks'][0][0] if order_book['asks'] else None

                if best_bid is None or best_ask is None:
                    return None, 0.0

                spread_pct = (best_ask - best_bid) / best_ask

                # Use best ask as our limit price (maker)
                return best_ask, spread_pct

        except Exception as e:
            logger.error(f"Error calculating best price: {e}")
            return None, 0.0

    async def _place_limit_order(
        self,
        symbol: str,
        side: str,
        amount: float,
        price: float,
        leverage: float
    ) -> Optional[Dict]:
        """Place a limit order"""

        if self.dry_run:
            logger.info(
                f"[DRY-RUN] LIMIT {side.upper()} {amount:.8f} @ ${price:.2f}"
            )
            return {
                'id': f'dry_limit_{datetime.now(timezone.utc).timestamp()}',
                'symbol': symbol,
                'side': side,
                'amount': amount,
                'price': price,
                'type': 'limit',
                'status': 'open',
                'timestamp': datetime.now(timezone.utc).isoformat()
            }

        try:
            params = {
                'tdMode': 'cross',
                'ordType': 'limit',
                'posMode': 'net',
                'leverage': int(leverage),
                'timeInForce': 'GTC'  # Good Till Cancelled
            }

            order = await asyncio.to_thread(
                self.exchange.create_order,
                symbol,
                'limit',
                side,
                amount,
                price,
                params
            )

            logger.info(f"[LIMIT ORDER PLACED] {order.get('id')} @ ${price:.2f}")
            return order

        except Exception as e:
            logger.error(f"Error placing limit order: {e}")
            return None

    async def _check_order_filled(self, symbol: str, order_id: str) -> bool:
        """Check if order is filled"""

        if self.dry_run:
            # In dry run, simulate 50% fill rate per attempt
            import random
            is_filled = random.random() > 0.5
            if is_filled:
                logger.info(f"[DRY-RUN] Order {order_id} FILLED")
            return is_filled

        try:
            order = await asyncio.to_thread(
                self.exchange.fetch_order,
                order_id,
                symbol
            )

            status = order.get('status', 'unknown')
            is_filled = status in ['closed', 'filled']

            if is_filled:
                logger.info(f"[ORDER FILLED] {order_id} - Status: {status}")

            return is_filled

        except Exception as e:
            logger.error(f"Error checking order status: {e}")
            return False

    async def _cancel_order(self, symbol: str, order_id: str) -> bool:
        """Cancel an order"""

        if self.dry_run:
            logger.info(f"[DRY-RUN] Cancelling order {order_id}")
            return True

        try:
            await asyncio.to_thread(
                self.exchange.cancel_order,
                order_id,
                symbol
            )
            logger.info(f"[ORDER CANCELLED] {order_id}")
            return True

        except Exception as e:
            logger.error(f"Error cancelling order: {e}")
            return False

    async def _place_market_order_fallback(
        self,
        symbol: str,
        side: str,
        amount: float,
        leverage: float
    ) -> Optional[Dict]:
        """Fallback to market order (TAKER FEES - should be avoided)"""

        if self.dry_run:
            logger.warning(
                f"[DRY-RUN] MARKET FALLBACK: {side.upper()} {amount:.8f} (TAKER FEES)"
            )
            return {
                'id': f'dry_market_{datetime.now(timezone.utc).timestamp()}',
                'symbol': symbol,
                'side': side,
                'amount': amount,
                'type': 'market',
                'status': 'closed',
                'timestamp': datetime.now(timezone.utc).isoformat()
            }

        try:
            params = {
                'tdMode': 'cross',
                'ordType': 'market',
                'posMode': 'net',
                'leverage': int(leverage)
            }

            order = await asyncio.to_thread(
                self.exchange.create_order,
                symbol,
                'market',
                side,
                amount,
                None,
                params
            )

            logger.warning(f"[MARKET ORDER PLACED] {order.get('id')} (TAKER FEES APPLIED)")
            return order

        except Exception as e:
            logger.error(f"Error placing market order: {e}")
            return None

    async def emergency_close_position(
        self,
        symbol: str,
        side: str,  # 'buy' to close short, 'sell' to close long
        amount: float
    ) -> Optional[Dict]:
        """
        Emergency market close (for stop loss only)

        This bypasses limit chasing and uses market order immediately
        """
        logger.warning(
            f"[EMERGENCY CLOSE] Market {side.upper()} {amount:.8f} {symbol}"
        )

        return await self._place_market_order_fallback(
            symbol, side, amount, leverage=1.0  # Leverage irrelevant for closing
        )
