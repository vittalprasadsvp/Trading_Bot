# Trading Modes Guide: Live vs Dry-Run

This document explains the two operating modes of the Professional Trading Bot and how to use them safely.

---

## Overview

The bot supports two operating modes:

| Mode | Description | Real Money | Exchange Orders |
|------|-------------|------------|-----------------|
| **Dry-Run** | Simulation mode for testing | No | No |
| **Live** | Real trading with actual funds | Yes | Yes |

---

## Dry-Run Mode (Simulation)

### What is Dry-Run Mode?

Dry-Run mode simulates all trading operations without placing real orders on the exchange. It's essential for:

- Testing new strategies
- Validating model performance
- Learning the system
- Debugging issues

### How to Enable

```bash
python live_trading_bot_pro.py --dry-run --equity 200 --risk-usd 10
```

The `--dry-run` flag activates simulation mode.

### What Happens in Dry-Run Mode

1. **Order Execution**: Orders are logged but NOT sent to the exchange
   ```python
   # In OrderExecutor.place_market_order()
   if self.dry_run:
       logger.info(f"[DRY-RUN] Futures Market order: {side} {amount} {symbol}")
       return {'id': 'dry_run_...', 'status': 'closed'}  # Simulated order
   ```

2. **Position Tracking**: Positions are tracked internally in `ProfessionalRiskManager`
3. **PnL Calculation**: Profit/loss is calculated based on simulated entry/exit prices
4. **TP/SL Orders**: Take-profit and stop-loss orders are simulated
5. **Statistics**: All metrics (win rate, Sharpe ratio, etc.) are tracked

### Log Output Example (Dry-Run)

```
[DRY-RUN] Futures Market order: BUY 0.00234 BTC/USDT:USDT @ $88,500.00
[DRY-RUN] TP/SL orders: TP @ $89,200.00 | SL @ $88,100.00
[POSITION OPENED] LONG 0.00234 @ $88,500.00
  Stop Loss: $88,100.00
  Take Profit 1 (Partial): $88,850.00
  Take Profit 2 (Final): $89,200.00
```

### Dry-Run Limitations

- Does NOT account for slippage
- Does NOT account for order book depth
- Does NOT account for network latency
- Maker fees are estimated, not actual
- Results may be more optimistic than live trading

---

## Live Mode (Real Trading)

### What is Live Mode?

Live mode executes real orders on the Bitget exchange using actual funds. **Use with caution.**

### Requirements for Live Mode

1. **API Credentials**: Set environment variables
   ```bash
   export BITGET_API_KEY="your_api_key"
   export BITGET_SECRET="your_secret"
   export BITGET_PASSWORD="your_password"
   ```

2. **Funded Account**: Ensure sufficient USDT balance in futures wallet

3. **API Permissions**: Enable futures trading on your API key

### How to Enable

```bash
# Remove --dry-run flag for live trading
python live_trading_bot_pro.py --equity 200 --risk-usd 50 --leverage 20
```

### What Happens in Live Mode

1. **Order Execution**: Real market orders are placed on Bitget
   ```python
   order = await self.exchange.create_order(
       symbol, 'market', side, amount, None, params
   )
   ```

2. **TP/SL Orders**: Real trigger orders are placed on the exchange
3. **Position Sync**: Bot tracks positions from exchange data
4. **Commission Deduction**: Real fees are charged (Maker: 0.02%, Taker: 0.06%)

### Log Output Example (Live)

```
[ORDER] Futures Market BUY 0.00234 BTC/USDT:USDT
[ORDER SUCCESS] Futures market order executed: 1234567890
[SL ORDER] Placing stop loss @ $88,100.00
[SL SUCCESS] Stop loss order placed: 1234567891
[TP ORDER] Placing take profit @ $89,200.00
[TP SUCCESS] Take profit order placed: 1234567892
```

---

## Command Line Arguments

| Argument | Description | Default | Example |
|----------|-------------|---------|---------|
| `--dry-run` | Enable simulation mode | False | `--dry-run` |
| `--symbol` | Trading pair | BTC/USDT | `--symbol ETH/USDT` |
| `--equity` | Initial account equity (USDT) | 200 | `--equity 500` |
| `--risk-pct` | Risk per trade (percentage) | None | `--risk-pct 0.02` |
| `--risk-usd` | Risk per trade (USD) | 50 | `--risk-usd 25` |
| `--leverage` | Leverage multiplier | 20 | `--leverage 10` |
| `--confidence` | ML confidence threshold | 0.65 | `--confidence 0.70` |

### Example Commands

**Dry-Run with Conservative Settings:**
```bash
python live_trading_bot_pro.py --dry-run --equity 200 --risk-usd 10 --leverage 10 --confidence 0.70
```

**Live Trading with Default Settings:**
```bash
python live_trading_bot_pro.py --equity 500 --risk-usd 50 --leverage 20
```

**Live Trading with Percentage-Based Risk:**
```bash
python live_trading_bot_pro.py --equity 1000 --risk-pct 0.02 --leverage 15
```

---

## Code Paths: Dry-Run vs Live

### OrderExecutor Class

The `OrderExecutor` class handles the mode differentiation:

```python
class OrderExecutor:
    def __init__(self, exchange, dry_run=True):
        self.dry_run = dry_run  # Mode flag

    async def place_market_order(self, symbol, side, amount, ...):
        if self.dry_run:
            # Simulation: Log only, no real order
            logger.info(f"[DRY-RUN] Market order: {side} {amount}")
            return {'id': f'dry_run_{timestamp}', 'status': 'closed'}

        # Live: Execute real order
        order = await self.exchange.create_order(...)
        return order
```

### TP/SL Order Handling

```python
async def place_tp_sl_orders(self, symbol, direction, amount, stop_loss, take_profit):
    if self.dry_run:
        logger.info(f"[DRY-RUN] TP/SL: TP @ ${take_profit} | SL @ ${stop_loss}")
        return {'tp_order': {...}, 'sl_order': {...}}  # Simulated

    # Live: Place real trigger orders
    sl_order = await self.exchange.create_order(symbol, 'trigger', ...)
    tp_order = await self.exchange.create_order(symbol, 'trigger', ...)
    return {'tp_order': tp_order, 'sl_order': sl_order}
```

---

## Safety Recommendations

### Before Live Trading

1. **Run Dry-Run for at least 1-2 weeks**
2. **Verify win rate > 60%** in simulation
3. **Check that TP/SL levels are realistic**
4. **Start with minimal equity** ($50-100)
5. **Monitor the first 10-20 trades closely**

### Risk Management

| Parameter | Conservative | Moderate | Aggressive |
|-----------|--------------|----------|------------|
| Risk per trade | 1% | 2% | 3-5% |
| Leverage | 5-10x | 10-20x | 20-30x |
| Confidence threshold | 0.70+ | 0.65-0.70 | 0.60-0.65 |
| Max daily loss | 3% | 5% | 10% |

### Emergency Stop

The bot handles graceful shutdown on `Ctrl+C`:
```python
def signal_handler(sig, frame):
    logger.info("[INTERRUPT] Ctrl+C - stopping bot...")
    bot.running = False
    bot.shutdown_event.set()
```

During shutdown:
- All open positions are closed
- Final statistics are printed
- Trade log is saved

---

## Transition: Dry-Run → Live

### Recommended Progression

| Week | Mode | Equity | Risk/Trade |
|------|------|--------|------------|
| 1-2 | Dry-Run | $200 (simulated) | $10 |
| 3 | Live | $50 (real) | $5 |
| 4 | Live | $100 (real) | $10 |
| 5+ | Live | Scale up gradually | 2% of equity |

### Checklist Before Going Live

- [ ] Dry-run for 1+ week with positive results
- [ ] Win rate > 60% in simulation
- [ ] Sharpe ratio > 1.0
- [ ] API credentials configured correctly
- [ ] Futures wallet funded
- [ ] API has futures trading permission
- [ ] Understand all risk parameters
- [ ] Set appropriate leverage (start low: 5-10x)
- [ ] Monitor first trades in real-time

---

## Troubleshooting

### Dry-Run Works but Live Fails

1. **Check API credentials**
   ```bash
   echo $BITGET_API_KEY
   echo $BITGET_SECRET
   echo $BITGET_PASSWORD
   ```

2. **Verify API permissions** (must include futures trading)

3. **Check account balance** (sufficient USDT in futures wallet)

4. **Test API connectivity**
   ```python
   import ccxt
   exchange = ccxt.bitget({
       'apiKey': 'your_key',
       'secret': 'your_secret',
       'password': 'your_password',
       'options': {'defaultType': 'swap'}
   })
   print(exchange.fetch_balance())
   ```

### Orders Not Executing

1. **Check minimum order value** (typically $5-10 on Bitget)
2. **Verify position size calculation**
3. **Check leverage settings on exchange**
4. **Review error logs for specific messages**

---

## Log Files

The bot generates detailed logs:

- **Console Output**: Real-time status
- **trading_bot_pro.log**: Full session log
- **trade_log_pro.json**: Trade history (JSON format)

### Log Levels

```python
logging.basicConfig(
    level=logging.INFO,  # Change to DEBUG for more detail
    ...
)
```

---

## Summary

| Aspect | Dry-Run | Live |
|--------|---------|------|
| Real Orders | No | Yes |
| Real Money | No | Yes |
| Slippage | Not simulated | Real |
| Fees | Estimated | Real (deducted) |
| Risk | None | Real capital at risk |
| Purpose | Testing & validation | Actual trading |
| Command | `--dry-run` flag | No flag |

**Always start with Dry-Run mode and transition to Live only after thorough validation!**
