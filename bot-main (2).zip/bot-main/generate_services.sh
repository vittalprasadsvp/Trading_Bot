#!/bin/bash
# Generate systemd service files with correct absolute paths
# Run this script from your trading bot directory

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CURRENT_USER=$(whoami)

echo "=============================================================================="
echo "GENERATING SYSTEMD SERVICE FILES"
echo "=============================================================================="
echo ""
echo "Directory: $SCRIPT_DIR"
echo "User: $CURRENT_USER"
echo ""

# Create trading-bot.service
cat > trading-bot.service << EOF
[Unit]
Description=Trading Bot - Futures
After=network.target

[Service]
Type=simple
User=$CURRENT_USER
WorkingDirectory=$SCRIPT_DIR
Environment="PATH=$SCRIPT_DIR/.venv/bin:/usr/bin:/usr/local/bin"
EnvironmentFile=-$SCRIPT_DIR/.env
ExecStart=$SCRIPT_DIR/.venv/bin/python live_trading_bot_pro.py --equity 200 --risk-pct 0.3 --confidence 0.55
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=trading-bot

[Install]
WantedBy=multi-user.target
EOF

echo "✓ Created: trading-bot.service"

# Create trading-bot-retrain.service
cat > trading-bot-retrain.service << EOF
[Unit]
Description=Retrain Trading Bot Model Every 48 Hours
After=network.target

[Service]
Type=oneshot
User=$CURRENT_USER
WorkingDirectory=$SCRIPT_DIR
Environment="PATH=$SCRIPT_DIR/.venv/bin:/usr/bin:/usr/local/bin"
EnvironmentFile=-$SCRIPT_DIR/.env
ExecStart=$SCRIPT_DIR/retrain_and_restart.sh
StandardOutput=append:/var/log/trading-bot-retrain.log
StandardError=append:/var/log/trading-bot-retrain-error.log

[Install]
WantedBy=multi-user.target
EOF

echo "✓ Created: trading-bot-retrain.service"

# Create trading-bot-retrain.timer
cat > trading-bot-retrain.timer << 'EOF'
[Unit]
Description=Timer for Trading Bot Model Retraining (Every 48 Hours)
Requires=trading-bot-retrain.service

[Timer]
# First run: 48 hours after system boot
OnBootSec=48h

# Subsequent runs: Every 48 hours after last activation
OnUnitActiveSec=48h

# Ensure timer runs even if system was off during scheduled time
Persistent=true

[Install]
WantedBy=timers.target
EOF

echo "✓ Created: trading-bot-retrain.timer"
echo ""

# Update retrain_and_restart.sh with correct paths
cat > retrain_and_restart.sh << EOF
#!/bin/bash
# Automatic Retraining and Bot Restart Script
# Runs every 48 hours to keep the model fresh

SCRIPT_DIR="$SCRIPT_DIR"
cd "\$SCRIPT_DIR"

# Activate virtual environment
source .venv/bin/activate

echo "=============================================================================="
echo "AUTOMATIC MODEL RETRAINING - \$(date)"
echo "=============================================================================="

# Step 1: Download fresh data
echo "[1/5] Downloading latest market data..."
python data_fetcher.py
if [ \$? -ne 0 ]; then
    echo "❌ ERROR: Failed to download data"
    exit 1
fi
echo "✓ Data downloaded"

# Step 2: Retrain model with new data
echo "[2/5] Retraining XGBoost model..."
python train_xgboost_model.py --symbol BTC/USDT --confidence 0.55
if [ \$? -ne 0 ]; then
    echo "❌ ERROR: Failed to retrain model"
    exit 1
fi
echo "✓ Model retrained"

# Step 3: Stop trading bot
echo "[3/5] Stopping trading bot service..."
sudo systemctl stop trading-bot
sleep 3
echo "✓ Bot stopped"

# Step 4: Reload and restart bot with new model
echo "[4/5] Restarting trading bot with updated model..."
sudo systemctl daemon-reload
sudo systemctl start trading-bot

if [ \$? -ne 0 ]; then
    echo "❌ ERROR: Failed to restart bot"
    exit 1
fi

echo "✓ Bot restarted successfully"
echo ""

# Step 5: Revalidate open positions with new model
echo "[5/5] Revalidating open positions with new model..."
echo "Checking for positions in profit that need evaluation..."
echo ""

# Wait for bot to fully start and load model
sleep 10

# Run position revalidation
python force_position_revalidation.py

if [ \$? -eq 0 ]; then
    echo "✓ Position revalidation complete"
    echo ""
    echo "=============================================================================="
    echo "RETRAINING COMPLETE - \$(date)"
    echo "=============================================================================="
    echo "Bot is now running with freshly trained model"
    echo "All profitable positions have been revalidated"
    echo "Check position_revalidation_log.json for recommendations"
    echo "=============================================================================="
else
    echo "⚠️  WARNING: Position revalidation failed (bot still running)"
    echo "Manual review recommended for open positions"
    echo ""
    echo "=============================================================================="
    echo "RETRAINING COMPLETE - \$(date)"
    echo "Bot is running with new model but revalidation had issues"
    echo "=============================================================================="
fi
EOF

chmod +x retrain_and_restart.sh
echo "✓ Updated: retrain_and_restart.sh"
echo ""

echo "=============================================================================="
echo "FILES GENERATED SUCCESSFULLY"
echo "=============================================================================="
echo ""
echo "Generated files:"
echo "  ✓ trading-bot.service           (Main bot service)"
echo "  ✓ trading-bot-retrain.service   (Retrain service)"
echo "  ✓ trading-bot-retrain.timer     (48h timer)"
echo "  ✓ retrain_and_restart.sh        (Retrain script)"
echo ""
echo "Configuration:"
echo "  Working Directory: $SCRIPT_DIR"
echo "  User: $CURRENT_USER"
echo "  Python: $SCRIPT_DIR/.venv/bin/python"
echo ""
echo "=============================================================================="
echo "INSTALLATION COMMANDS"
echo "=============================================================================="
echo ""
echo "Run these commands to install the services:"
echo ""
echo "  # 1. Copy service files to systemd"
echo "  sudo cp trading-bot.service /etc/systemd/system/"
echo "  sudo cp trading-bot-retrain.service /etc/systemd/system/"
echo "  sudo cp trading-bot-retrain.timer /etc/systemd/system/"
echo ""
echo "  # 2. Reload systemd"
echo "  sudo systemctl daemon-reload"
echo ""
echo "  # 3. Enable and start the bot"
echo "  sudo systemctl enable trading-bot"
echo "  sudo systemctl start trading-bot"
echo ""
echo "  # 4. Enable automatic retraining"
echo "  sudo systemctl enable trading-bot-retrain.timer"
echo "  sudo systemctl start trading-bot-retrain.timer"
echo ""
echo "  # 5. Check status"
echo "  sudo systemctl status trading-bot"
echo "  sudo systemctl list-timers trading-bot-retrain.timer"
echo ""
echo "=============================================================================="
echo ""
echo "✅ Ready to install! Run the commands above to start the bot."
echo ""
echo "=============================================================================="
