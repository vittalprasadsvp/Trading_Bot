"""
Ultra-Fast Position Monitor
Checks positions every 0.5 seconds for:
- Breakeven activation (0.2% profit)
- Stop loss hits
- Take profit hits
- Trailing stop updates
"""

import asyncio
import ccxt
from datetime import datetime, timezone
from typing import Dict, Optional, List
import logging

logger = logging.getLogger(__name__)


class UltraFastPositionMonitor:
    """
    High-frequency position monitoring for hyper-scalping

    Features:
    - Checks every 0.5 seconds (not 1s)
    - Instant breakeven activation
    - Real-time stop loss monitoring
    - Trailing stop dynamic updates
    """

    def __init__(
        self,
        exchange: ccxt.Exchange,
        symbol: str,
        dry_run: bool = True,
        check_interval: float = 0.5,
        breakeven_trigger_pct: float = 0.002,  # 0.2%
        trailing_distance_pct: float = 0.002    # 0.2%
    ):
        self.exchange = exchange
        self.symbol = symbol
        self.dry_run = dry_run
        self.check_interval = check_interval
        self.breakeven_trigger_pct = breakeven_trigger_pct
        self.trailing_distance_pct = trailing_distance_pct

        # Position tracking
        self.active_position: Optional[Dict] = None
        self.position_entry_price: float = 0.0
        self.position_direction: str = ''  # 'LONG' or 'SHORT'
        self.position_size: float = 0.0
        self.current_stop_loss: float = 0.0
        self.current_take_profit: float = 0.0

        # State flags
        self.breakeven_activated: bool = False
        self.trailing_stop_activated: bool = False
        self.highest_profit_reached: float = 0.0

        # Monitoring task
        self.monitor_task: Optional[asyncio.Task] = None
        self.monitoring = False

        logger.info(
            f"UltraFastPositionMonitor initialized: "
            f"check_interval={check_interval}s, "
            f"breakeven_trigger={breakeven_trigger_pct:.2%}"
        )

    async def start_monitoring(
        self,
        position: Dict,
        entry_price: float,
        direction: str,
        size: float,
        stop_loss: float,
        take_profit: float
    ):
        """
        Start monitoring a new position

        Args:
            position: Position dict from exchange
            entry_price: Entry price
            direction: 'LONG' or 'SHORT'
            size: Position size
            stop_loss: Initial stop loss price
            take_profit: Take profit price
        """
        self.active_position = position
        self.position_entry_price = entry_price
        self.position_direction = direction
        self.position_size = size
        self.current_stop_loss = stop_loss
        self.current_take_profit = take_profit

        # Reset state
        self.breakeven_activated = False
        self.trailing_stop_activated = False
        self.highest_profit_reached = 0.0

        # Start monitoring loop
        self.monitoring = True
        self.monitor_task = asyncio.create_task(self._monitoring_loop())

        logger.info(
            f"[MONITOR START] {direction} position @ ${entry_price:.2f} | "
            f"SL: ${stop_loss:.2f} | TP: ${take_profit:.2f}"
        )

    async def stop_monitoring(self):
        """Stop monitoring position"""
        self.monitoring = False
        if self.monitor_task:
            self.monitor_task.cancel()
            try:
                await self.monitor_task
            except asyncio.CancelledError:
                pass

        logger.info("[MONITOR STOP] Position monitoring stopped")

    async def _monitoring_loop(self):
        """
        Main monitoring loop - runs every 0.5 seconds

        Checks:
        1. Current price
        2. Unrealized P&L
        3. Breakeven trigger
        4. Trailing stop update
        5. Stop loss / Take profit hits
        """
        logger.info(f"[MONITOR LOOP] Starting ultra-fast checks every {self.check_interval}s")

        while self.monitoring:
            try:
                # Get current price
                current_price = await self._get_current_price()
                if current_price == 0:
                    await asyncio.sleep(self.check_interval)
                    continue

                # Calculate unrealized P&L
                profit_pct = self._calculate_profit_pct(current_price)

                # Update highest profit reached (for trailing stop)
                if profit_pct > self.highest_profit_reached:
                    self.highest_profit_reached = profit_pct

                # Log current status (every 2 seconds to avoid spam)
                if int(datetime.now(timezone.utc).timestamp()) % 4 == 0:
                    logger.debug(
                        f"[MONITOR] Price: ${current_price:.2f} | "
                        f"Profit: {profit_pct:.3%} | "
                        f"Peak: {self.highest_profit_reached:.3%} | "
                        f"BE: {self.breakeven_activated} | "
                        f"Trail: {self.trailing_stop_activated}"
                    )

                # === CHECK 1: BREAKEVEN ACTIVATION ===
                if not self.breakeven_activated and profit_pct >= self.breakeven_trigger_pct:
                    await self._activate_breakeven(current_price)

                # === CHECK 2: TRAILING STOP ACTIVATION & UPDATE ===
                if self.breakeven_activated and not self.trailing_stop_activated:
                    # Activate trailing after breakeven
                    self.trailing_stop_activated = True
                    logger.info("[TRAILING] Trailing stop activated")

                if self.trailing_stop_activated:
                    await self._update_trailing_stop(current_price, profit_pct)

                # === CHECK 3: STOP LOSS HIT ===
                sl_hit = self._check_stop_loss_hit(current_price)
                if sl_hit:
                    logger.warning(f"[SL HIT] Stop loss triggered @ ${current_price:.2f}")
                    await self._handle_stop_loss_hit(current_price)
                    break

                # === CHECK 4: TAKE PROFIT HIT ===
                tp_hit = self._check_take_profit_hit(current_price)
                if tp_hit:
                    logger.info(f"[TP HIT] Take profit reached @ ${current_price:.2f}")
                    await self._handle_take_profit_hit(current_price)
                    break

                # Sleep until next check (0.5s)
                await asyncio.sleep(self.check_interval)

            except asyncio.CancelledError:
                logger.info("[MONITOR] Monitoring cancelled")
                break
            except Exception as e:
                logger.error(f"[MONITOR ERROR] {e}")
                await asyncio.sleep(self.check_interval)

    async def _get_current_price(self) -> float:
        """Get current market price"""
        try:
            ticker = await asyncio.to_thread(
                self.exchange.fetch_ticker,
                self.symbol
            )
            return ticker['last']
        except Exception as e:
            logger.error(f"Error fetching price: {e}")
            return 0.0

    def _calculate_profit_pct(self, current_price: float) -> float:
        """Calculate unrealized profit %"""
        if self.position_direction == 'LONG':
            profit_pct = (current_price - self.position_entry_price) / self.position_entry_price
        else:  # SHORT
            profit_pct = (self.position_entry_price - current_price) / self.position_entry_price

        return profit_pct

    async def _activate_breakeven(self, current_price: float):
        """
        Activate breakeven - move SL to entry + fees

        This eliminates risk after 0.2% profit
        """
        # Calculate fees (round trip: entry + exit)
        from config import MAKER_FEE
        fees = self.position_entry_price * (MAKER_FEE * 2)

        # New SL = entry + fees (zero risk)
        if self.position_direction == 'LONG':
            new_stop_loss = self.position_entry_price + fees
        else:  # SHORT
            new_stop_loss = self.position_entry_price - fees

        # Update stop loss
        await self._update_stop_loss(new_stop_loss)

        self.breakeven_activated = True
        logger.info(
            f"[BREAKEVEN ACTIVATED] Profit: {self._calculate_profit_pct(current_price):.3%} | "
            f"New SL: ${new_stop_loss:.2f} (Entry: ${self.position_entry_price:.2f} + Fees: ${fees:.2f}) | "
            f"RISK ELIMINATED"
        )

    async def _update_trailing_stop(self, current_price: float, current_profit: float):
        """
        Update trailing stop dynamically

        Trailing distance: 0.2% from highest profit
        """
        # Calculate trailing stop based on highest profit
        if self.position_direction == 'LONG':
            # For LONG: SL trails below price
            optimal_sl = current_price * (1 - self.trailing_distance_pct)
        else:  # SHORT
            # For SHORT: SL trails above price
            optimal_sl = current_price * (1 + self.trailing_distance_pct)

        # Only move SL in favorable direction (never worse)
        should_update = False
        if self.position_direction == 'LONG':
            should_update = optimal_sl > self.current_stop_loss
        else:  # SHORT
            should_update = optimal_sl < self.current_stop_loss

        if should_update:
            await self._update_stop_loss(optimal_sl)
            logger.info(
                f"[TRAILING UPDATE] Profit: {current_profit:.3%} | "
                f"New SL: ${optimal_sl:.2f} (trailing {self.trailing_distance_pct:.2%})"
            )

    async def _update_stop_loss(self, new_stop_loss: float):
        """Update stop loss on exchange"""
        if self.dry_run:
            logger.info(f"[DRY-RUN] Would update SL to ${new_stop_loss:.2f}")
            self.current_stop_loss = new_stop_loss
            return

        try:
            # Cancel old SL order and place new one
            # (Implementation depends on exchange API)
            # For now, just update our tracking
            self.current_stop_loss = new_stop_loss
            logger.info(f"[SL UPDATED] New stop loss: ${new_stop_loss:.2f}")

        except Exception as e:
            logger.error(f"Error updating stop loss: {e}")

    def _check_stop_loss_hit(self, current_price: float) -> bool:
        """Check if stop loss was hit"""
        if self.position_direction == 'LONG':
            return current_price <= self.current_stop_loss
        else:  # SHORT
            return current_price >= self.current_stop_loss

    def _check_take_profit_hit(self, current_price: float) -> bool:
        """Check if take profit was hit"""
        if self.position_direction == 'LONG':
            return current_price >= self.current_take_profit
        else:  # SHORT
            return current_price <= self.current_take_profit

    async def _handle_stop_loss_hit(self, current_price: float):
        """Handle stop loss hit"""
        logger.warning(
            f"[STOP LOSS] Position closed @ ${current_price:.2f} | "
            f"Entry: ${self.position_entry_price:.2f} | "
            f"Loss: {self._calculate_profit_pct(current_price):.3%}"
        )
        self.monitoring = False

    async def _handle_take_profit_hit(self, current_price: float):
        """Handle take profit hit"""
        logger.info(
            f"[TAKE PROFIT] Position closed @ ${current_price:.2f} | "
            f"Entry: ${self.position_entry_price:.2f} | "
            f"Profit: {self._calculate_profit_pct(current_price):.3%}"
        )
        self.monitoring = False


# ============================================================================
# USAGE EXAMPLE
# ============================================================================

async def example_usage():
    """Example of how to use UltraFastPositionMonitor"""

    # Initialize (dry run)
    import ccxt
    exchange = ccxt.bitget()
    symbol = 'BTC/USDT:USDT'

    monitor = UltraFastPositionMonitor(
        exchange=exchange,
        symbol=symbol,
        dry_run=True,
        check_interval=0.5,
        breakeven_trigger_pct=0.002,
        trailing_distance_pct=0.002
    )

    # Simulate opening a position
    position = {
        'id': 'test_position',
        'symbol': symbol,
        'side': 'long',
        'size': 0.01
    }

    # Start monitoring
    await monitor.start_monitoring(
        position=position,
        entry_price=50000.0,
        direction='LONG',
        size=0.01,
        stop_loss=49850.0,   # -0.3%
        take_profit=50600.0  # +1.2%
    )

    # Monitor will run in background, checking every 0.5s
    # It will automatically:
    # 1. Move SL to breakeven when profit reaches 0.2%
    # 2. Activate trailing stop after breakeven
    # 3. Close position if SL or TP hit

    # Keep monitoring for 60 seconds
    await asyncio.sleep(60)

    # Stop monitoring
    await monitor.stop_monitoring()


if __name__ == '__main__':
    asyncio.run(example_usage())
