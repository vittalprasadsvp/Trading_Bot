"""
Historical Data Fetcher for Trading Bot
Fetches OHLCV data from Bitget exchange via CCXT and exports to CSV
"""

import ccxt
import pandas as pd
from datetime import datetime, timedelta, timezone
import time
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class HistoricalDataFetcher:
    """
    Fetches historical OHLCV data from Bitget exchange
    Handles rate limits and data validation
    """
    
    def __init__(self, exchange_id: str = 'bitget'):
        """
        Initialize the data fetcher
        
        Args:
            exchange_id: CCXT exchange identifier (default: 'bitget')
        """
        self.exchange_id = exchange_id
        self.exchange = self._initialize_exchange()
        
    def _initialize_exchange(self):
        """Initialize CCXT exchange instance"""
        try:
            exchange_class = getattr(ccxt, self.exchange_id)
            exchange = exchange_class({
                'enableRateLimit': True,  # Respect rate limits
                'options': {
                    'defaultType': 'swap',  # Use perpetual futures
                }
            })
            
            # Test connection
            exchange.load_markets()
            logger.info(f"[OK] Connected to {self.exchange_id.upper()}")
            return exchange
            
        except Exception as e:
            logger.error(f"Failed to initialize exchange: {e}")
            raise
    
    def fetch_ohlcv(
        self,
        symbol: str = 'BTC/USDT:USDT',
        timeframe: str = '1h',
        days_back: int = 120,
        limit: int = 1000
    ) -> pd.DataFrame:
        """
        Fetch historical OHLCV data
        
        Args:
            symbol: Trading pair (e.g., 'BTC/USDT:USDT' for perpetual)
            timeframe: Candle timeframe ('1m', '5m', '15m', '1h', '4h', '1d')
            days_back: Number of days of historical data to fetch
            limit: Max candles per request (default: 1000, Bitget max)
            
        Returns:
            DataFrame with columns: timestamp, open, high, low, close, volume
        """
        logger.info(f"Fetching {symbol} {timeframe} data for last {days_back} days...")
        
        # Calculate time range
        end_time = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=days_back)
        since = int(start_time.timestamp() * 1000)  # Convert to milliseconds
        
        all_candles = []
        current_since = since
        
        # Fetch data in batches
        while True:
            try:
                # Fetch OHLCV
                candles = self.exchange.fetch_ohlcv(
                    symbol=symbol,
                    timeframe=timeframe,
                    since=current_since,
                    limit=limit
                )
                
                if not candles:
                    break
                
                all_candles.extend(candles)
                
                # Update since to last candle timestamp + 1
                last_timestamp = candles[-1][0]
                current_since = last_timestamp + 1
                
                # Check if we've reached the end
                if last_timestamp >= int(end_time.timestamp() * 1000):
                    break
                
                logger.info(f"Fetched {len(all_candles)} candles so far...")
                
                # Rate limit protection (Bitget: ~20 req/sec, be conservative)
                time.sleep(0.1)
                
            except ccxt.RateLimitExceeded:
                logger.warning("Rate limit exceeded, waiting 2 seconds...")
                time.sleep(2)
                continue
                
            except Exception as e:
                logger.error(f"Error fetching data: {e}")
                break
        
        # Convert to DataFrame
        df = pd.DataFrame(
            all_candles,
            columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
        )
        
        # Convert timestamp to datetime
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        
        # Remove duplicates and sort
        df = df.drop_duplicates(subset=['timestamp']).sort_values('timestamp').reset_index(drop=True)
        
        logger.info(f"[OK] Fetched {len(df)} candles from {df['timestamp'].min()} to {df['timestamp'].max()}")
        
        return df
    
    def save_to_csv(
        self,
        df: pd.DataFrame,
        symbol: str,
        timeframe: str,
        output_dir: str = 'data'
    ) -> Path:
        """
        Save DataFrame to CSV file
        
        Args:
            df: DataFrame with OHLCV data
            symbol: Trading pair
            timeframe: Candle timeframe
            output_dir: Output directory path
            
        Returns:
            Path to saved CSV file
        """
        # Create output directory
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        # Generate filename
        symbol_clean = symbol.replace('/', '_').replace(':', '_')
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        filename = f"{symbol_clean}_{timeframe}_{timestamp}.csv"
        filepath = output_path / filename
        
        # Save to CSV
        df.to_csv(filepath, index=False)
        logger.info(f"[SAVED] Saved {len(df)} rows to {filepath}")
        
        return filepath
    
    def fetch_and_save(
        self,
        symbol: str = 'BTC/USDT:USDT',
        timeframe: str = '15m',
        days_back: int = 90,
        output_dir: str = 'data'
    ) -> tuple[pd.DataFrame, Path]:
        """
        Fetch historical data and save to CSV in one step
        
        Returns:
            Tuple of (DataFrame, CSV filepath)
        """
        df = self.fetch_ohlcv(symbol, timeframe, days_back)
        filepath = self.save_to_csv(df, symbol, timeframe, output_dir)
        
        # Print summary statistics
        self._print_summary(df, symbol, timeframe)
        
        return df, filepath
    
    def _print_summary(self, df: pd.DataFrame, symbol: str, timeframe: str):
        """Print data summary statistics"""
        print("\n" + "="*80)
        print(f"HISTORICAL DATA SUMMARY - {symbol} ({timeframe})")
        print("="*80)
        print(f"\n[DATA] Total Candles: {len(df)}")
        print(f"[DATA] Date Range: {df['timestamp'].min()} to {df['timestamp'].max()}")
        print(f"[DATA] Duration: {(df['timestamp'].max() - df['timestamp'].min()).days} days")
        print(f"\n[PRICE] Price Statistics:")
        print(f"  High: ${df['high'].max():,.2f}")
        print(f"  Low: ${df['low'].min():,.2f}")
        print(f"  Current: ${df['close'].iloc[-1]:,.2f}")
        print(f"  Change: {((df['close'].iloc[-1] / df['close'].iloc[0] - 1) * 100):+.2f}%")
        print(f"\n[VOLUME] Volume Statistics:")
        print(f"  Total Volume: {df['volume'].sum():,.0f}")
        print(f"  Avg Volume: {df['volume'].mean():,.0f}")
        print(f"  Max Volume: {df['volume'].max():,.0f}")
        print("\n" + "="*80 + "\n")


def main():
    """
    Main execution function
    Fetches data for multiple symbols and timeframes
    """
    print("\n" + "="*80)
    print("HISTORICAL DATA FETCHER FOR TRADING BOT")
    print("="*80 + "\n")
    
    # Initialize fetcher
    fetcher = HistoricalDataFetcher(exchange_id='bitget')
    
    # Configuration - MULTI-TIMEFRAME SETUP FOR PROFESSIONAL STRATEGY
    configs = [
        # Primary timeframe (15m)
        {
            'symbol': 'BTC/USDT:USDT',
            'timeframe': '15m',
            'days_back': 365,  # 2 years for robust training
            'description': 'Bitcoin 15-minute (Primary Timeframe)'
        },
        # Higher timeframe context (1h)
        {
            'symbol': 'BTC/USDT:USDT',
            'timeframe': '1h',
            'days_back': 365,  # 2 years for alignment
            'description': 'Bitcoin 1-hour (Trend Context)'
        },
        # Macro timeframe context (4h)
        {
            'symbol': 'BTC/USDT:USDT',
            'timeframe': '4h',
            'days_back': 365,  # 2 years for alignment
            'description': 'Bitcoin 4-hour (Macro Trend)'
        },
        # Optional: ETH for diversification
        # {
        #     'symbol': 'ETH/USDT:USDT',
        #     'timeframe': '15m',
        #     'days_back': 120,
        #     'description': 'Ethereum 15-minute (Optional)'
        # },
    ]
    
    results = []
    
    for i, config in enumerate(configs, 1):
        print(f"\n[{i}/{len(configs)}] Fetching {config['description']}...")
        print("-" * 80)
        
        try:
            df, filepath = fetcher.fetch_and_save(
                symbol=config['symbol'],
                timeframe=config['timeframe'],
                days_back=config['days_back']
            )
            
            results.append({
                'symbol': config['symbol'],
                'timeframe': config['timeframe'],
                'filepath': filepath,
                'rows': len(df),
                'status': '[OK] Success'
            })
            
        except Exception as e:
            logger.error(f"Failed to fetch {config['description']}: {e}")
            results.append({
                'symbol': config['symbol'],
                'timeframe': config['timeframe'],
                'filepath': None,
                'rows': 0,
                'status': f'[ERROR] Failed: {str(e)[:50]}'
            })
    
    # Print final summary
    print("\n" + "="*80)
    print("FETCH COMPLETE - SUMMARY")
    print("="*80)
    
    results_df = pd.DataFrame(results)
    print("\n" + results_df.to_string(index=False))
    
    print("\n[FILES] Files saved in: ./data/")
    print("\n[MULTI-TIMEFRAME DATA READY]")
    print("  ✓ 15m data (primary strategy)")
    print("  ✓ 1h data (trend context)")
    print("  ✓ 4h data (macro trend)")
    print("\n[NEXT] Next steps:")
    print("  1. Train XGBoost model: python train_xgboost_model.py")
    print("  2. Dry-run test: python live_trading_bot_pro.py --dry-run --equity 1000")
    print("  3. Monitor for 48 hours before going live")
    print("\n" + "="*80 + "\n")


if __name__ == '__main__':
    main()