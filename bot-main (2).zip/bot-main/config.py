"""
HYPER-SCALPER CONFIGURATION
Optimized for 1m/5m micro-movements with Maker-focused execution
"""

# ============================================================================
# EXCHANGE & SYMBOL
# ============================================================================
SYMBOL = 'BTC/USDT'
FUTURES_SYMBOL = 'BTC/USDT:USDT'

# ============================================================================
# TIMEFRAMES - HYPER SCALPING MODE
# ============================================================================
PRIMARY_TIMEFRAME = '1m'      # Main execution timeframe
SECONDARY_TIMEFRAME = '5m'    # Trend confirmation
TERTIARY_TIMEFRAME = '15m'    # Macro context

# Data fetch limits (enough for feature calculation)
CANDLE_LIMIT_1M = 500    # ~8 hours
CANDLE_LIMIT_5M = 500    # ~41 hours
CANDLE_LIMIT_15M = 500   # ~5 days

# ============================================================================
# FEES - BITGET FUTURES (CRITICAL FOR SCALPING)
# ============================================================================
MAKER_FEE = 0.0002   # 0.02% - OBJETIVO: Siempre ejecutar como maker
TAKER_FEE = 0.0006   # 0.06% - EVITAR: Demasiado alto para scalping

# ============================================================================
# EXECUTION - LIMIT CHASER OPTIMIZADO (ULTRA-FAST)
# ============================================================================
# Colocar órdenes LIMIT en Best Bid/Ask y perseguir ejecución
LIMIT_ORDER_TIMEOUT = 3        # Segundos antes de cancelar y reevaluar
LIMIT_CHASE_INTERVAL = 0.3     # Reajustar cada 0.3s si no se ejecuta (más agresivo)
MAX_CHASE_ATTEMPTS = 10        # Máximo 10 intentos (3 segundos total = 10 × 0.3s)
ALLOW_TAKER_FALLBACK = False   # NUNCA usar market orders (excepto SL de emergencia)

# Spread máximo aceptable (en % del precio)
MAX_SPREAD_PCT = 0.08  # 0.08% - Si spread > esto, no entrar

# ============================================================================
# RISK MANAGEMENT - DINÁMICO
# ============================================================================
BASE_STOP_LOSS_PCT = 0.003      # 0.3% base
ATR_STOP_MULTIPLIER = 1.5       # Stop = MAX(0.3%, ATR * 1.5)
BREAKEVEN_TRIGGER_PCT = 0.002   # 0.2% - Saltar SL a breakeven si alcanza esto

# Take Profit (micro-targets para scalping)
TP1_RATIO = 1.2        # R:R 1.2:1 (0.36% si SL = 0.3%)
TP1_SIZE_PCT = 50      # Cerrar 50% en TP1
TP2_RATIO = 2.0        # R:R 2:1 (0.6%)
TP2_SIZE_PCT = 50      # Cerrar resto en TP2

# Trailing stop (activar después de TP1)
TRAILING_STOP_ACTIVATION = TP1_RATIO  # Activar trailing en TP1
TRAILING_STOP_DISTANCE_PCT = 0.002    # 0.2% trailing

# ============================================================================
# POSITION SIZING
# ============================================================================
RISK_PER_TRADE_USD = 10.0       # Fijo: $10 riesgo por trade
MIN_POSITION_VALUE_USD = 20.0   # Mínimo $20 de tamaño
MAX_POSITION_VALUE_USD = 500.0  # Máximo $500 por posición

# Leverage dinámico
BASE_LEVERAGE = 30.0            # 30x estándar para scalping
HIGH_CONFIDENCE_LEVERAGE = 50.0 # 50x si confidence > 0.75
LEVERAGE_THRESHOLD = 0.75       # Umbral para leverage alto

# ============================================================================
# ML MODEL - FILTROS ESTRICTOS
# ============================================================================
MIN_CONFIDENCE = 0.65           # Mínimo 65% confianza del modelo
MIN_ADX = 25.0                  # Mínimo 25 ADX (micro-tendencia confirmada)

# Filtros adicionales
MIN_VOLUME_RATIO = 0.8          # Volumen mínimo (80% del promedio)
MAX_VOLATILITY_PERCENTILE = 0.95 # Evitar extrema volatilidad

# ============================================================================
# LOOP DE EJECUCIÓN - ULTRA-FAST CHECKS
# ============================================================================
CHECK_INTERVAL_SECONDS = 0.5    # Verificar cada 0.5 segundos (hyper-scalping ultra-fast)
POSITION_CHECK_INTERVAL = 0.5   # Check posiciones cada 0.5s (breakeven/SL monitoring)
ORDER_STATUS_CHECK_INTERVAL = 0.5  # Check estado de órdenes cada 0.5s
FEATURE_CACHE_SECONDS = 5       # Cache de features por 5s para no recalcular (no recalcular cada 0.5s)

# ============================================================================
# MICRO-MOMENTUM FEATURES
# ============================================================================
# RSI Differential
RSI_PERIOD_FAST = 7     # RSI rápido en 1m
RSI_PERIOD_SLOW = 14    # RSI estándar
RSI_DIFF_THRESHOLD = 10 # Diferencia mínima para señal

# Stochastic
STOCH_K_PERIOD = 14
STOCH_D_PERIOD = 3
STOCH_SMOOTH = 3

# VWAP Deviation
VWAP_LOOKBACK = 50      # Períodos para calcular VWAP
VWAP_STD_BANDS = 2.0    # Bandas de desviación estándar

# ============================================================================
# VOLATILITY & LIQUIDITY FILTERS
# ============================================================================
ATR_PERIOD = 14
ATR_LOOKBACK_PERCENTILE = 100  # Calcular percentil de ATR en últimas N velas

# Spread dinámico (filtrar baja liquidez)
# Si spread > ATR/2, considerar ilíquido
SPREAD_TO_ATR_MAX_RATIO = 0.5

# ============================================================================
# POSITION LIMITS
# ============================================================================
MAX_CONCURRENT_POSITIONS = 1    # Solo 1 posición a la vez (scalping enfocado)
MAX_DAILY_TRADES = 20           # Máximo 20 trades/día
MAX_DAILY_LOSS_USD = 50.0       # Stop trading si pérdida diaria > $50
DAILY_PROFIT_TARGET_USD = 100.0 # Target diario de $100

# Cooldown entre trades
MIN_SECONDS_BETWEEN_TRADES = 30  # Mínimo 30s entre trades

# ============================================================================
# REENTRADA DESPUÉS DE STOP LOSS
# ============================================================================
REENTRY_COOLDOWN_AFTER_SL = 300  # 5 minutos después de SL antes de reentrar
REENTRY_COOLDOWN_AFTER_TP = 30   # 30s después de TP (puede reentrar rápido)

# ============================================================================
# LOGGING & MONITORING
# ============================================================================
LOG_LEVEL = 'INFO'
LOG_FILE = 'hyper_scalper.log'
ENABLE_TRADE_LOG_JSON = True
TRADE_LOG_FILE = 'trade_log_scalper.json'

# Performance tracking
TRACK_WIN_RATE = True
TRACK_SHARPE_RATIO = True
MIN_TRADES_FOR_STATS = 10  # Mínimo trades antes de mostrar estadísticas

# ============================================================================
# SAFETY FEATURES
# ============================================================================
ENABLE_KILL_SWITCH = True       # Parar bot si condiciones anormales
KILL_SWITCH_DRAWDOWN_PCT = 0.10 # Parar si drawdown > 10%
KILL_SWITCH_CONSECUTIVE_LOSSES = 5  # Parar si 5 pérdidas consecutivas

ENABLE_CIRCUIT_BREAKER = True   # Pausar temporalmente si alta volatilidad
CIRCUIT_BREAKER_VOLATILITY_MULTIPLIER = 3.0  # Pausar si volatilidad > 3x promedio

# ============================================================================
# ADVANCED FEATURES
# ============================================================================
# Asyncio optimizations
ENABLE_ASYNC_FEATURE_CALC = True  # Calcular features async (no bloquear)
PRELOAD_DATA_ON_START = True      # Pre-cargar datos al iniciar

# Order book depth analysis
USE_ORDER_BOOK_IMBALANCE = True   # Usar OBI (Order Book Imbalance)
ORDER_BOOK_DEPTH_LEVELS = 10      # Analizar top 10 niveles

# Funding rate consideration
USE_FUNDING_RATE_FILTER = True    # Evitar entradas si funding muy negativo
MAX_NEGATIVE_FUNDING_RATE = -0.001  # No SHORT si funding < -0.1%
MAX_POSITIVE_FUNDING_RATE = 0.001   # No LONG si funding > 0.1%

# ============================================================================
# DRY RUN DEFAULTS
# ============================================================================
DEFAULT_DRY_RUN = True
DEFAULT_INITIAL_EQUITY = 100.0
DEFAULT_VERBOSE = True
