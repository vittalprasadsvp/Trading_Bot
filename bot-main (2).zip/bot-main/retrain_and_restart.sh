#!/bin/bash
# Automatic Retraining and Bot Restart Script
# Runs every 48 hours to keep the model fresh

SCRIPT_DIR="/c/Users/abcussi/Documents/repos/bitget"
cd "$SCRIPT_DIR"

# Activate virtual environment
source .venv/bin/activate

echo "=============================================================================="
echo "AUTOMATIC MODEL RETRAINING - $(date)"
echo "=============================================================================="

# Step 1: Download fresh data
echo "[1/5] Downloading latest market data..."
python data_fetcher.py
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to download data"
    exit 1
fi
echo "✓ Data downloaded"

# Step 2: Retrain model with new data
echo "[2/5] Retraining XGBoost model..."
python train_xgboost_model.py --symbol BTC/USDT --confidence 0.55
if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to retrain model"
    exit 1
fi
echo "✓ Model retrained"

# Step 3: Stop trading bot
echo "[3/5] Stopping trading bot service..."
sudo systemctl stop trading-bot
sleep 3
echo "✓ Bot stopped"

# Step 4: Reload and restart bot with new model
echo "[4/5] Restarting trading bot with updated model..."
sudo systemctl daemon-reload
sudo systemctl start trading-bot

if [ $? -ne 0 ]; then
    echo "❌ ERROR: Failed to restart bot"
    exit 1
fi

echo "✓ Bot restarted successfully"
echo ""

# Step 5: Revalidate open positions with new model
echo "[5/5] Revalidating open positions with new model..."
echo "Checking for positions in profit that need evaluation..."
echo ""

# Wait for bot to fully start and load model
sleep 10

# Run position revalidation
python force_position_revalidation.py

if [ $? -eq 0 ]; then
    echo "✓ Position revalidation complete"
    echo ""
    echo "=============================================================================="
    echo "RETRAINING COMPLETE - $(date)"
    echo "=============================================================================="
    echo "Bot is now running with freshly trained model"
    echo "All profitable positions have been revalidated"
    echo "Check position_revalidation_log.json for recommendations"
    echo "=============================================================================="
else
    echo "⚠️  WARNING: Position revalidation failed (bot still running)"
    echo "Manual review recommended for open positions"
    echo ""
    echo "=============================================================================="
    echo "RETRAINING COMPLETE - $(date)"
    echo "Bot is running with new model but revalidation had issues"
    echo "=============================================================================="
fi
