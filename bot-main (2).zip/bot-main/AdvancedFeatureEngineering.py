"""
Advanced Feature Engineering Module - Professional Quant Strategy
Implements:
- Multi-timeframe analysis (1h, 4h trends)
- Price action patterns (Engulfing, Pinbars)
- RSI/MACD divergences
- Regime filtering (ADX, Kaufman Efficiency Ratio)
"""

import pandas as pd
import numpy as np
import talib as ta
from typing import Dict, Tuple, Optional
import logging

logger = logging.getLogger(__name__)


class AdvancedFeatureEngineering:
    """Professional feature engineering for ML-based trading"""

    def __init__(self):
        self.feature_columns = []

    @staticmethod
    def calculate_all_features(
        df_15m: pd.DataFrame,
        df_1h: Optional[pd.DataFrame] = None,
        df_4h: Optional[pd.DataFrame] = None
    ) -> pd.DataFrame:
        """
        Calculate comprehensive feature set

        Args:
            df_15m: Primary 15-minute timeframe data
            df_1h: Optional 1-hour data for higher timeframe context
            df_4h: Optional 4-hour data for higher timeframe context

        Returns:
            DataFrame with all engineered features
        """
        df = df_15m.copy()

        # === BASIC FEATURES ===
        df = AdvancedFeatureEngineering._calculate_basic_features(df)

        # === PRICE ACTION PATTERNS ===
        df = AdvancedFeatureEngineering._calculate_price_action_patterns(df)

        # === DIVERGENCES ===
        df = AdvancedFeatureEngineering._calculate_divergences(df)

        # === REGIME FILTERS ===
        df = AdvancedFeatureEngineering._calculate_regime_filters(df)

        # === MULTI-TIMEFRAME FEATURES ===
        if df_1h is not None:
            df = AdvancedFeatureEngineering._add_higher_timeframe_features(df, df_1h, '1h')

        if df_4h is not None:
            df = AdvancedFeatureEngineering._add_higher_timeframe_features(df, df_4h, '4h')

        return df

    @staticmethod
    def _calculate_basic_features(df: pd.DataFrame) -> pd.DataFrame:
        """Calculate foundational technical indicators"""

        # Price-based features
        df['returns'] = df['close'].pct_change()
        df['log_returns'] = np.log(df['close'] / df['close'].shift(1))

        # RSI (14-period)
        df['rsi'] = ta.RSI(df['close'].values, timeperiod=14)
        df['rsi_normalized'] = (df['rsi'] - 50) / 50  # [-1, 1]

        # RSI zones
        df['rsi_oversold'] = (df['rsi'] < 30).astype(int)
        df['rsi_overbought'] = (df['rsi'] > 70).astype(int)

        # MACD
        macd, signal, hist = ta.MACD(
            df['close'].values,
            fastperiod=12,
            slowperiod=26,
            signalperiod=9
        )
        df['macd'] = macd
        df['macd_signal'] = signal
        df['macd_hist'] = hist
        df['macd_cross'] = np.where(df['macd'] > df['macd_signal'], 1, -1)
        df['macd_hist_change'] = df['macd_hist'].diff()

        # Bollinger Bands
        upper, middle, lower = ta.BBANDS(
            df['close'].values,
            timeperiod=20,
            nbdevup=2,
            nbdevdn=2
        )
        df['bb_upper'] = upper
        df['bb_middle'] = middle
        df['bb_lower'] = lower
        df['bb_width'] = (upper - lower) / middle
        df['bb_position'] = (df['close'] - lower) / (upper - lower)

        # BB squeeze detection (low volatility)
        df['bb_squeeze'] = (df['bb_width'] < df['bb_width'].rolling(20).quantile(0.2)).astype(int)

        # Moving Averages
        df['ema_9'] = ta.EMA(df['close'].values, timeperiod=9)
        df['ema_21'] = ta.EMA(df['close'].values, timeperiod=21)
        df['ema_50'] = ta.EMA(df['close'].values, timeperiod=50)
        df['ema_200'] = ta.EMA(df['close'].values, timeperiod=200)

        # EMA slopes (trend direction)
        df['ema_9_slope'] = df['ema_9'].diff(5) / df['ema_9']
        df['ema_21_slope'] = df['ema_21'].diff(5) / df['ema_21']
        df['ema_200_slope'] = df['ema_200'].diff(5) / df['ema_200']

        # Price position relative to EMAs
        df['price_above_ema_9'] = (df['close'] > df['ema_9']).astype(int)
        df['price_above_ema_21'] = (df['close'] > df['ema_21']).astype(int)
        df['price_above_ema_200'] = (df['close'] > df['ema_200']).astype(int)

        # Volume features
        df['volume_sma'] = df['volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        df['volume_std'] = df['volume'].rolling(window=20).std()

        # Volume spikes
        df['volume_spike'] = (df['volume_ratio'] > 2.0).astype(int)

        # Momentum indicators
        df['momentum_5'] = df['close'] / df['close'].shift(5) - 1
        df['momentum_10'] = df['close'] / df['close'].shift(10) - 1
        df['momentum_20'] = df['close'] / df['close'].shift(20) - 1

        # Volatility
        df['volatility'] = df['returns'].rolling(window=20).std()
        df['atr'] = ta.ATR(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['atr_normalized'] = df['atr'] / df['close']

        # Price action
        df['high_low_ratio'] = (df['high'] - df['low']) / df['close']
        df['close_open_ratio'] = (df['close'] - df['open']) / df['open']

        return df

    @staticmethod
    def _calculate_price_action_patterns(df: pd.DataFrame) -> pd.DataFrame:
        """
        Detect price action patterns numerically

        Patterns:
        - Bullish/Bearish Engulfing
        - Pinbars (long wicks)
        - Inside/Outside bars
        """

        # Candle body and wicks
        df['body'] = abs(df['close'] - df['open'])
        df['upper_wick'] = df['high'] - df[['close', 'open']].max(axis=1)
        df['lower_wick'] = df[['close', 'open']].min(axis=1) - df['low']
        df['total_range'] = df['high'] - df['low']

        # Body ratio (strong candle if > 0.6)
        df['body_ratio'] = df['body'] / (df['total_range'] + 1e-10)

        # Wick dominance
        df['upper_wick_ratio'] = df['upper_wick'] / (df['total_range'] + 1e-10)
        df['lower_wick_ratio'] = df['lower_wick'] / (df['total_range'] + 1e-10)

        # === ENGULFING PATTERNS ===
        # Bullish Engulfing: current bullish candle engulfs previous bearish
        bullish_candle = df['close'] > df['open']
        bearish_candle = df['close'] < df['open']

        prev_bearish = bearish_candle.shift(1)
        curr_bullish = bullish_candle
        curr_open_below_prev_close = df['open'] < df['close'].shift(1)
        curr_close_above_prev_open = df['close'] > df['open'].shift(1)

        df['bullish_engulfing'] = (
            prev_bearish & curr_bullish &
            curr_open_below_prev_close & curr_close_above_prev_open
        ).astype(int)

        # Bearish Engulfing
        prev_bullish = bullish_candle.shift(1)
        curr_bearish = bearish_candle
        curr_open_above_prev_close = df['open'] > df['close'].shift(1)
        curr_close_below_prev_open = df['close'] < df['open'].shift(1)

        df['bearish_engulfing'] = (
            prev_bullish & curr_bearish &
            curr_open_above_prev_close & curr_close_below_prev_open
        ).astype(int)

        # === PINBARS (HAMMER/SHOOTING STAR) ===
        # Bullish Pinbar (Hammer): long lower wick, small body at top
        df['bullish_pinbar'] = (
            (df['lower_wick_ratio'] > 0.6) &  # Long lower wick
            (df['upper_wick_ratio'] < 0.1) &  # Small upper wick
            (df['body_ratio'] < 0.3)          # Small body
        ).astype(int)

        # Bearish Pinbar (Shooting Star): long upper wick, small body at bottom
        df['bearish_pinbar'] = (
            (df['upper_wick_ratio'] > 0.6) &  # Long upper wick
            (df['lower_wick_ratio'] < 0.1) &  # Small lower wick
            (df['body_ratio'] < 0.3)          # Small body
        ).astype(int)

        # === INSIDE/OUTSIDE BARS ===
        # Inside bar: high/low within previous candle range
        df['inside_bar'] = (
            (df['high'] <= df['high'].shift(1)) &
            (df['low'] >= df['low'].shift(1))
        ).astype(int)

        # Outside bar: high/low beyond previous candle range
        df['outside_bar'] = (
            (df['high'] > df['high'].shift(1)) &
            (df['low'] < df['low'].shift(1))
        ).astype(int)

        # Strong directional candles
        df['strong_bullish'] = ((df['close'] > df['open']) & (df['body_ratio'] > 0.7)).astype(int)
        df['strong_bearish'] = ((df['close'] < df['open']) & (df['body_ratio'] > 0.7)).astype(int)

        return df

    @staticmethod
    def _calculate_divergences(df: pd.DataFrame) -> pd.DataFrame:
        """
        Detect divergences between price and indicators

        Divergence logic:
        - Bullish: Price makes lower low, RSI makes higher low
        - Bearish: Price makes higher high, RSI makes lower high
        """

        lookback = 14

        # === RSI DIVERGENCE ===
        # Find local highs and lows in price
        df['price_local_high'] = (
            (df['high'] > df['high'].shift(1)) &
            (df['high'] > df['high'].shift(-1))
        )
        df['price_local_low'] = (
            (df['low'] < df['low'].shift(1)) &
            (df['low'] < df['low'].shift(-1))
        )

        # Rolling highs/lows for comparison
        df['price_rolling_high'] = df['high'].rolling(lookback).max()
        df['price_rolling_low'] = df['low'].rolling(lookback).min()

        df['rsi_rolling_high'] = df['rsi'].rolling(lookback).max()
        df['rsi_rolling_low'] = df['rsi'].rolling(lookback).min()

        # Bullish divergence: price lower low, RSI higher low
        price_lower_low = df['low'] < df['price_rolling_low'].shift(lookback)
        rsi_higher_low = df['rsi'] > df['rsi_rolling_low'].shift(lookback)
        df['rsi_bullish_divergence'] = (price_lower_low & rsi_higher_low).astype(int)

        # Bearish divergence: price higher high, RSI lower high
        price_higher_high = df['high'] > df['price_rolling_high'].shift(lookback)
        rsi_lower_high = df['rsi'] < df['rsi_rolling_high'].shift(lookback)
        df['rsi_bearish_divergence'] = (price_higher_high & rsi_lower_high).astype(int)

        # === MACD DIVERGENCE ===
        df['macd_rolling_high'] = df['macd'].rolling(lookback).max()
        df['macd_rolling_low'] = df['macd'].rolling(lookback).min()

        # Bullish divergence
        macd_higher_low = df['macd'] > df['macd_rolling_low'].shift(lookback)
        df['macd_bullish_divergence'] = (price_lower_low & macd_higher_low).astype(int)

        # Bearish divergence
        macd_lower_high = df['macd'] < df['macd_rolling_high'].shift(lookback)
        df['macd_bearish_divergence'] = (price_higher_high & macd_lower_high).astype(int)

        # Combined divergence signal
        df['divergence_score'] = (
            df['rsi_bullish_divergence'] - df['rsi_bearish_divergence'] +
            df['macd_bullish_divergence'] - df['macd_bearish_divergence']
        )

        return df

    @staticmethod
    def _calculate_regime_filters(df: pd.DataFrame) -> pd.DataFrame:
        """
        Detect market regime: Trending vs Ranging

        Uses:
        - ADX (Average Directional Index)
        - Kaufman Efficiency Ratio
        """

        # === ADX (Trend Strength) ===
        df['adx'] = ta.ADX(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['plus_di'] = ta.PLUS_DI(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)
        df['minus_di'] = ta.MINUS_DI(df['high'].values, df['low'].values, df['close'].values, timeperiod=14)

        # Regime classification based on ADX
        df['regime_strong_trend'] = (df['adx'] > 25).astype(int)  # Strong trend
        df['regime_ranging'] = (df['adx'] < 20).astype(int)       # Ranging market

        # Trend direction
        df['trend_bullish'] = (df['plus_di'] > df['minus_di']).astype(int)
        df['trend_bearish'] = (df['plus_di'] < df['minus_di']).astype(int)

        # === KAUFMAN EFFICIENCY RATIO ===
        # ER = |Price Change| / Sum(|Price Changes|)
        # High ER = trending, Low ER = choppy
        period = 10
        change = abs(df['close'] - df['close'].shift(period))
        volatility = df['close'].diff().abs().rolling(period).sum()
        df['efficiency_ratio'] = change / (volatility + 1e-10)

        # Normalized ER
        df['er_trending'] = (df['efficiency_ratio'] > 0.3).astype(int)

        # === VOLATILITY REGIME ===
        df['volatility_percentile'] = df['volatility'].rolling(100).apply(
            lambda x: pd.Series(x).rank(pct=True).iloc[-1]
        )
        df['high_volatility'] = (df['volatility_percentile'] > 0.8).astype(int)
        df['low_volatility'] = (df['volatility_percentile'] < 0.2).astype(int)

        return df

    @staticmethod
    def _add_higher_timeframe_features(
        df_15m: pd.DataFrame,
        df_htf: pd.DataFrame,
        timeframe: str
    ) -> pd.DataFrame:
        """
        Add higher timeframe features (1h or 4h)

        Args:
            df_15m: 15-minute dataframe
            df_htf: Higher timeframe dataframe
            timeframe: '1h' or '4h'
        """

        # Calculate EMA slope on higher timeframe
        # Use EMA 200 if enough data (need 200 + 5 for diff), otherwise use EMA 50
        df_htf = df_htf.copy()

        if len(df_htf) >= 210:  # Need extra candles for EMA 200 + diff(5)
            df_htf['ema_200'] = ta.EMA(df_htf['close'].values, timeperiod=200)
            df_htf['ema_200_slope'] = df_htf['ema_200'].diff(5) / df_htf['ema_200']
        else:
            # Fallback to EMA 50 if insufficient data
            logger.warning(f"{timeframe} data has only {len(df_htf)} candles, using EMA 50 instead of EMA 200")
            ema_period = min(50, max(10, len(df_htf)//4))  # Ensure reasonable period
            df_htf['ema_200'] = ta.EMA(df_htf['close'].values, timeperiod=ema_period)
            df_htf['ema_200_slope'] = df_htf['ema_200'].diff(3) / df_htf['ema_200']

        # CRITICAL: Fill NaN values from EMA and diff calculations
        # Backward fill first, then forward fill, then use close price as final fallback
        df_htf['ema_200'] = df_htf['ema_200'].bfill().ffill().fillna(df_htf['close'])
        df_htf['ema_200_slope'] = df_htf['ema_200_slope'].fillna(0)  # Neutral slope for NaN

        # Calculate RSI on higher timeframe
        df_htf['rsi'] = ta.RSI(df_htf['close'].values, timeperiod=14)
        df_htf['rsi'] = df_htf['rsi'].fillna(50)  # Neutral RSI for NaN

        # Calculate MACD on higher timeframe
        macd, signal, hist = ta.MACD(df_htf['close'].values, fastperiod=12, slowperiod=26, signalperiod=9)
        df_htf['macd'] = macd
        df_htf['macd_signal'] = signal
        df_htf['macd'] = df_htf['macd'].fillna(0)  # Neutral MACD for NaN
        df_htf['macd_signal'] = df_htf['macd_signal'].fillna(0)

        # Ensure timestamp alignment using merge_asof (more robust than reindex)
        if 'timestamp' in df_15m.columns and 'timestamp' in df_htf.columns:
            # Prepare HTF features
            df_htf_features = df_htf[['timestamp', 'ema_200_slope', 'rsi', 'macd', 'macd_signal']].copy()
            df_htf_features[f'{timeframe}_ema200_slope'] = df_htf_features['ema_200_slope']
            df_htf_features[f'{timeframe}_rsi'] = df_htf_features['rsi']
            df_htf_features[f'{timeframe}_macd_bullish'] = (
                df_htf_features['macd'] > df_htf_features['macd_signal']
            ).astype(int)
            df_htf_features[f'{timeframe}_trend_bullish'] = (
                df_htf_features['ema_200_slope'] > 0
            ).astype(int)

            # Keep only needed columns
            df_htf_features = df_htf_features[[
                'timestamp',
                f'{timeframe}_ema200_slope',
                f'{timeframe}_rsi',
                f'{timeframe}_macd_bullish',
                f'{timeframe}_trend_bullish'
            ]]

            # Merge using merge_asof (handles non-exact timestamps)
            df_15m = pd.merge_asof(
                df_15m.sort_values('timestamp'),
                df_htf_features.sort_values('timestamp'),
                on='timestamp',
                direction='backward'  # Use most recent HTF value
            )

            # CRITICAL: Fill any remaining NaN values after merge
            # This handles edge cases where merge_asof couldn't find matching timestamps
            if f'{timeframe}_ema200_slope' in df_15m.columns:
                df_15m[f'{timeframe}_ema200_slope'] = df_15m[f'{timeframe}_ema200_slope'].fillna(0)
            if f'{timeframe}_rsi' in df_15m.columns:
                df_15m[f'{timeframe}_rsi'] = df_15m[f'{timeframe}_rsi'].fillna(50)
            if f'{timeframe}_macd_bullish' in df_15m.columns:
                df_15m[f'{timeframe}_macd_bullish'] = df_15m[f'{timeframe}_macd_bullish'].fillna(0)
            if f'{timeframe}_trend_bullish' in df_15m.columns:
                df_15m[f'{timeframe}_trend_bullish'] = df_15m[f'{timeframe}_trend_bullish'].fillna(0)
        else:
            # Fallback: just replicate most recent value across all rows
            logger.warning(f"Timestamp column not found, using simple replication for {timeframe}")
            if len(df_htf) > 0:
                df_15m[f'{timeframe}_ema200_slope'] = df_htf['ema_200_slope'].iloc[-1] if not pd.isna(df_htf['ema_200_slope'].iloc[-1]) else 0
                df_15m[f'{timeframe}_rsi'] = df_htf['rsi'].iloc[-1] if not pd.isna(df_htf['rsi'].iloc[-1]) else 50
                df_15m[f'{timeframe}_macd_bullish'] = int(df_htf['macd'].iloc[-1] > df_htf['macd_signal'].iloc[-1]) if not pd.isna(df_htf['macd'].iloc[-1]) else 0
                df_15m[f'{timeframe}_trend_bullish'] = int(df_htf['ema_200_slope'].iloc[-1] > 0) if not pd.isna(df_htf['ema_200_slope'].iloc[-1]) else 0
            else:
                # No HTF data, use neutral values
                df_15m[f'{timeframe}_ema200_slope'] = 0
                df_15m[f'{timeframe}_rsi'] = 50
                df_15m[f'{timeframe}_macd_bullish'] = 0
                df_15m[f'{timeframe}_trend_bullish'] = 0

        return df_15m

    @staticmethod
    def get_feature_columns(include_mtf: bool = True) -> list:
        """
        Return list of feature column names for ML model
        Excludes OHLCV and intermediate calculations

        Args:
            include_mtf: Include multi-timeframe features (1h, 4h). Set to False if data not available.
        """
        # Base features (always available with 15m data only)
        base_features = [
            # Basic indicators
            'rsi_normalized', 'rsi_oversold', 'rsi_overbought',
            'macd', 'macd_signal', 'macd_hist', 'macd_cross', 'macd_hist_change',
            'bb_width', 'bb_position', 'bb_squeeze',
            'ema_9_slope', 'ema_21_slope', 'ema_200_slope',
            'price_above_ema_9', 'price_above_ema_21', 'price_above_ema_200',
            'volume_ratio', 'volume_spike',
            'momentum_5', 'momentum_10', 'momentum_20',
            'volatility', 'atr_normalized',
            'high_low_ratio', 'close_open_ratio',

            # Price action patterns
            'body_ratio', 'upper_wick_ratio', 'lower_wick_ratio',
            'bullish_engulfing', 'bearish_engulfing',
            'bullish_pinbar', 'bearish_pinbar',
            'inside_bar', 'outside_bar',
            'strong_bullish', 'strong_bearish',

            # Divergences
            'rsi_bullish_divergence', 'rsi_bearish_divergence',
            'macd_bullish_divergence', 'macd_bearish_divergence',
            'divergence_score',

            # Regime filters
            'adx', 'regime_strong_trend', 'regime_ranging',
            'trend_bullish', 'trend_bearish',
            'efficiency_ratio', 'er_trending',
            'high_volatility', 'low_volatility',
        ]

        # Multi-timeframe features (optional)
        if include_mtf:
            mtf_features = [
                # Higher timeframe (1h)
                '1h_ema200_slope', '1h_rsi', '1h_macd_bullish', '1h_trend_bullish',
                # Higher timeframe (4h)
                '4h_ema200_slope', '4h_rsi', '4h_macd_bullish', '4h_trend_bullish',
            ]
            return base_features + mtf_features

        return base_features

    @staticmethod
    def create_target(df: pd.DataFrame, periods_ahead: int = 4) -> pd.Series:
        """
        Create binary target: 1 if price increases in next N periods

        Args:
            df: DataFrame with OHLCV data
            periods_ahead: Lookforward window (default: 4 candles = 1 hour on 15m)

        Returns:
            Binary series (1 = bullish, 0 = bearish)
        """
        future_return = df['close'].shift(-periods_ahead) / df['close'] - 1

        # Require at least 0.3% movement to avoid noise
        threshold = 0.003
        target = (future_return > threshold).astype(int)

        return target


# ============================================================================
# USAGE EXAMPLE
# ============================================================================

if __name__ == '__main__':
    # Example: Generate sample data
    from datetime import datetime, timedelta, timezone

    dates_15m = pd.date_range(end=datetime.now(timezone.utc), periods=1000, freq='15min')
    dates_1h = pd.date_range(end=datetime.now(timezone.utc), periods=250, freq='1h')
    dates_4h = pd.date_range(end=datetime.now(timezone.utc), periods=60, freq='4h')

    np.random.seed(42)
    returns_15m = np.random.normal(0.0001, 0.01, 1000)
    returns_1h = np.random.normal(0.0001, 0.015, 250)
    returns_4h = np.random.normal(0.0001, 0.02, 60)

    close_15m = 50000 * (1 + returns_15m).cumprod()
    close_1h = 50000 * (1 + returns_1h).cumprod()
    close_4h = 50000 * (1 + returns_4h).cumprod()

    df_15m = pd.DataFrame({
        'timestamp': dates_15m,
        'open': close_15m * (1 + np.random.uniform(-0.002, 0.002, 1000)),
        'high': close_15m * (1 + np.random.uniform(0, 0.005, 1000)),
        'low': close_15m * (1 + np.random.uniform(-0.005, 0, 1000)),
        'close': close_15m,
        'volume': np.random.uniform(100, 1000, 1000)
    })

    df_1h = pd.DataFrame({
        'timestamp': dates_1h,
        'open': close_1h * (1 + np.random.uniform(-0.002, 0.002, 250)),
        'high': close_1h * (1 + np.random.uniform(0, 0.005, 250)),
        'low': close_1h * (1 + np.random.uniform(-0.005, 0, 250)),
        'close': close_1h,
        'volume': np.random.uniform(100, 1000, 250)
    })

    df_4h = pd.DataFrame({
        'timestamp': dates_4h,
        'open': close_4h * (1 + np.random.uniform(-0.002, 0.002, 60)),
        'high': close_4h * (1 + np.random.uniform(0, 0.005, 60)),
        'low': close_4h * (1 + np.random.uniform(-0.005, 0, 60)),
        'close': close_4h,
        'volume': np.random.uniform(100, 1000, 60)
    })

    # Calculate features
    print("Calculating advanced features...")
    df_features = AdvancedFeatureEngineering.calculate_all_features(df_15m, df_1h, df_4h)

    # Create target
    df_features['target'] = AdvancedFeatureEngineering.create_target(df_features)

    # Get feature columns
    feature_cols = AdvancedFeatureEngineering.get_feature_columns()

    print(f"\n[OK] Feature engineering complete!")
    print(f"Total features: {len(feature_cols)}")
    print(f"Dataframe shape: {df_features.shape}")
    print(f"\nFeature columns:\n{feature_cols}")

    # Check for NaN
    print(f"\nNaN count: {df_features[feature_cols].isna().sum().sum()}")
    print("\nFirst few rows of key features:")
    print(df_features[['close', 'rsi', 'adx', 'divergence_score', '1h_ema200_slope', 'target']].head(10))
